/* ==========================================================
   HNIM · 前端逻辑
   ========================================================== */
(function () {
  'use strict';

  var BOOT = JSON.parse(document.getElementById('boot').textContent);
  var BASE = BOOT.base || '';
  var API  = BOOT.api;
  var CSRF = BOOT.csrf;

  /* ---------------------------------------------------------
   *  基础工具
   * ------------------------------------------------------- */
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function url(p) { return BASE + '/' + String(p).replace(/^\//, ''); }
  function apiUrl(action, qs) {
    return API + '?action=' + encodeURIComponent(action) + (qs ? '&' + qs : '');
  }
  function avatarSrc(p) { return p ? url(p) : ''; }
  function colorOf(id) {
    var h = (37 * (Number(id) || 0) + 200) % 360;
    return 'hsl(' + h + ',58%,58%)';
  }
  function firstChar(s) {
    s = String(s || '?');
    return Array.from(s)[0] || '?';
  }
  function avaHtml(u, cls) {
    cls = cls || '';
    var name = (u && (u.display || u.nickname || u.username)) || '?';
    if (u && u.avatar) {
      return '<div class="ava ' + cls + '" style="background-image:url(' + JSON.stringify(avatarSrc(u.avatar)) + ')"></div>';
    }
    return '<div class="ava ' + cls + '" style="background:' + colorOf(u && u.id) + '">' + esc(firstChar(name)) + '</div>';
  }
  function fileSize(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(2) + ' MB';
  }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function timeText(ts) {
    var now = new Date(), d = new Date(ts * 1000);
    var sameDay = d.toDateString() === now.toDateString();
    if (sameDay) return pad(d.getHours()) + ':' + pad(d.getMinutes());
    var y = new Date(now.getTime() - 86400000);
    if (d.toDateString() === y.toDateString()) return '昨天 ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    if (now - d < 7 * 86400 * 1000) return (d.getMonth() + 1) + '-' + d.getDate();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function fullTime(ts) {
    var d = new Date(ts * 1000);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' +
           pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }
  function lastSeenText(ts) {
    if (!ts) return '离线';
    var s = Math.floor(Date.now() / 1000) - ts;
    if (s < 60) return '在线';
    if (s < 3600) return Math.floor(s / 60) + ' 分钟前在线';
    if (s < 86400) return Math.floor(s / 3600) + ' 小时前在线';
    if (s < 2592000) return Math.floor(s / 86400) + ' 天前在线';
    // 超过一个月再报天数就没人看得懂了（「365 天前在线」），
    // 直接给日期；想看精确到秒的时间，把鼠标悬停在上面就行。
    return timeText(ts) + ' 在线';
  }
  /** 「上一次在线」的精确时间，用来做悬停提示 */
  function lastSeenTitle(ts) {
    return ts ? '上次在线：' + fullTime(ts) : '从未上线过';
  }
  /**
   * 在线状态的展示片段（HTML）。
   * 离线时带上精确时间的悬停提示，这样看到「3 天前在线」也能立刻知道是哪天。
   */
  function lastSeenHtml(ts, isOnline) {
    if (isOnline) return '<span class="presence-txt on">在线</span>';
    return '<span class="presence-txt" title="' + esc(lastSeenTitle(ts)) + '">' +
           esc(lastSeenText(ts)) + '</span>';
  }
  function bytes(n) { return fileSize(n); }

  function toast(msg, type) {
    var wrap = $('toastWrap');
    if (!wrap) return;
    var el = document.createElement('div');
    el.className = 'toast' + (type ? ' ' + type : '');
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .25s';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 260);
    }, 2400);
  }

  /* ---------------------------------------------------------
   *  网络请求
   * ------------------------------------------------------- */
  function api(action, params, method) {
    method = method || 'GET';
    var opt = { method: method, credentials: 'same-origin', headers: {} };
    var qs = '';

    if (params instanceof FormData) {
      params.set('csrf', CSRF);
      opt.body = params;
      qs = 'action=' + encodeURIComponent(action);
    } else if (method === 'POST') {
      params = params || {};
      var sp = new URLSearchParams();
      sp.set('csrf', CSRF);
      Object.keys(params).forEach(function (k) {
        var v = params[k];
        // 数组必须编成 key[]=v，PHP 才收得到数组（建群选人靠这个）
        if (Array.isArray(v)) {
          v.forEach(function (item) { sp.append(k + '[]', item); });
        } else if (v !== null && v !== undefined) {
          // 对象（meta 等）必须自己序列化，否则 URLSearchParams 会写成 [object Object]
          sp.append(k, (typeof v === 'object') ? JSON.stringify(v) : v);
        }
      });
      opt.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
      opt.body = sp.toString();
      qs = 'action=' + encodeURIComponent(action);
    } else {
      var q = new URLSearchParams(params || {}).toString();
      qs = 'action=' + encodeURIComponent(action) + (q ? '&' + q : '');
    }

    return fetch(API + '?' + qs, opt).then(function (res) {
      return res.text().then(function (txt) {
        var j = null;
        try { j = JSON.parse(txt); } catch (e) { j = null; }
        if (!j) {
          if (res.status === 401) { location.reload(); }
          // 把服务器真正吐回来的东西带出来，不然只有一句「返回异常」根本没法查。
          // 常见两种：一是主机 php.ini 打开了 display_errors，warning 混进了响应体；
          //           二是某个改写规则把 api.php 重写成了 index.php（返回整页 HTML）。
          var seen = (txt || '').replace(/\s+/g, ' ').trim().slice(0, 200);
          var e = new Error('服务器返回异常（HTTP ' + res.status + '）：' + (seen || '（空响应）'));
          e.raw = txt;
          e.status = res.status;
          e.ct = res.headers.get('content-type') || '';
          throw e;
        }
        if (j.ok === false) {
          if (res.status === 401) { location.reload(); }
          var e2 = new Error(j.error || '操作失败');
          e2.data = j;
          throw e2;
        }
        return j;
      });
    });
  }

  /* =========================================================
   *  搜索框：3 秒不输入就变灰，聚焦 / 输入立刻恢复
   * ======================================================= */
  (function searchIdleGrey() {
    var IDLE_MS = 3000;
    var SEL = '.search input, input.search, .search-box input, #searchInput';

    function box(el) { return el && el.closest ? el.closest('.search') : null; }
    function wake(el) {
      clearTimeout(el.__hnimIdleT);
      el.__hnimIdleT = null;
      el.classList.remove('idle');
      var b = box(el);
      if (b) { b.classList.remove('idle'); }
    }
    function arm(el) {
      clearTimeout(el.__hnimIdleT);
      el.__hnimIdleT = setTimeout(function () {
        el.__hnimIdleT = null;
        // 不管有没有焦点，只要 3 秒没输入就变灰；聚焦或敲键盘会立刻恢复
        el.classList.add('idle');
        var b = box(el);
        if (b) { b.classList.add('idle'); }
      }, IDLE_MS);
    }
    function hit(t) { return t && t.matches && t.matches(SEL) ? t : null; }

    // 聚焦或敲键盘：立刻恢复正常，同时重新开始 3 秒倒计时
    document.addEventListener('input', function (e) { var t = hit(e.target); if (t) { wake(t); arm(t); } }, true);
    document.addEventListener('focusin', function (e) { var t = hit(e.target); if (t) { wake(t); arm(t); } }, true);
    document.addEventListener('focusout', function (e) { var t = hit(e.target); if (t) arm(t); }, true);

    // 先给页面上已有的搜索框上闹钟；弹窗里后来加的搜索框靠下面这个巡检兜底
    document.querySelectorAll(SEL).forEach(function (el) { arm(el); });
    setInterval(function () {
      document.querySelectorAll(SEL).forEach(function (el) {
        if (!el.__hnimIdleT && document.activeElement !== el && !el.classList.contains('idle')) { arm(el); }
      });
    }, 5000);
  })();

  /* =========================================================
   *  登录 / 注册
   * ======================================================= */
  if (!BOOT.logged_in) {
    var lgForm = $('loginForm'), rgForm = $('regForm');
    var lgErr = $('loginErr'), rgErr = $('regErr');

    $('lgEye').addEventListener('click', function () {
      var p = $('lgPass');
      p.type = p.type === 'password' ? 'text' : 'password';
    });
    $('rgEye').addEventListener('click', function () {
      var p = $('rgPass');
      p.type = p.type === 'password' ? 'text' : 'password';
    });

    $('lgToReg').addEventListener('click', function (e) {
      e.preventDefault();
      lgForm.classList.add('hidden'); rgForm.classList.remove('hidden'); rgErr.textContent = '';
      $('rgUser').focus();
    });
    $('rgToLogin').addEventListener('click', function (e) {
      e.preventDefault();
      rgForm.classList.add('hidden'); lgForm.classList.remove('hidden'); lgErr.textContent = '';
    });

    if ($('lgUser').value) { $('lgPass').focus(); } else { $('lgUser').focus(); }

    lgForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var u = $('lgUser').value.trim(), p = $('lgPass').value;
      if (!u || !p) { lgErr.textContent = '请输入账号和密码'; return; }
      $('lgBtn').disabled = true; $('lgBtn').textContent = '登录中…'; lgErr.textContent = '';
      api('login', { username: u, password: p }, 'POST').then(function () {
        if ($('lgRemember').checked) {
          document.cookie = 'hnim_last_user=' + encodeURIComponent(u) + ';path=' + (BASE || '/') + ';max-age=2592000';
        } else {
          document.cookie = 'hnim_last_user=;path=' + (BASE || '/') + ';max-age=0';
        }
        location.href = BASE + '/index.php';
      }).catch(function (err) {
        lgErr.textContent = err.message;
        $('lgBtn').disabled = false; $('lgBtn').textContent = '登 录';
      });
    });

    /* --------- 注册页：邮箱验证码 --------- */
    var codeTimer = null, codeLeft = 0;
    function codeTick() {
      var btn = $('rgCodeBtn');
      if (!btn) return;
      if (codeLeft > 0) {
        btn.disabled = true;
        btn.textContent = codeLeft + ' 秒后重发';
        codeLeft--;
        codeTimer = setTimeout(codeTick, 1000);
      } else {
        btn.disabled = false;
        btn.textContent = '获取验证码';
        codeTimer = null;
      }
    }
    if ($('rgCodeBtn')) {
      $('rgCodeBtn').addEventListener('click', function () {
        if (codeLeft > 0) return;
        var email = ($('rgEmail').value || '').trim();
        var tip = $('rgMailTip');
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(email)) {
          if (tip) { tip.textContent = '请先填写正确的邮箱'; tip.className = 'reg-tip err'; }
          $('rgEmail').focus();
          return;
        }
        if (tip) { tip.textContent = '发送中…'; tip.className = 'reg-tip'; }
        var btn = this;
        btn.disabled = true; btn.textContent = '发送中…';
        api('verify_send', { email: email }, 'POST').then(function () {
          if (tip) { tip.textContent = '验证码已发到邮箱，10 分钟内有效'; tip.className = 'reg-tip ok'; }
          codeLeft = 60;
          codeTick();
        }).catch(function (err) {
          if (tip) { tip.textContent = err.message; tip.className = 'reg-tip err'; }
          btn.disabled = false; btn.textContent = '获取验证码';
        });
      });
    }

    rgForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var u = $('rgUser').value.trim(), n = $('rgNick').value.trim(),
          p = $('rgPass').value, p2 = $('rgPass2').value,
          email = ($('rgEmail') ? $('rgEmail').value : '').trim(),
          code = ($('rgCode') ? $('rgCode').value : '').trim();
      rgErr.textContent = '';
      if (!/^[A-Za-z0-9_]{3,32}$/.test(u)) { rgErr.textContent = '账号需为 3-32 位字母、数字或下划线'; return; }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(email)) { rgErr.textContent = '请填写正确的邮箱地址'; return; }
      if (!/^\d{4,8}$/.test(code)) { rgErr.textContent = '请填写邮箱收到的验证码'; return; }
      if (p.length < 6) { rgErr.textContent = '密码至少 6 位'; return; }
      if (p !== p2) { rgErr.textContent = '两次输入的密码不一致'; return; }
      $('rgBtn').disabled = true; $('rgBtn').textContent = '注册中…';
      api('register', { username: u, password: p, password2: p2, nickname: n, email: email, code: code }, 'POST').then(function () {
        location.href = BASE + '/index.php';
      }).catch(function (err) {
        rgErr.textContent = err.message;
        $('rgBtn').disabled = false; $('rgBtn').textContent = '注 册 并 登 录';
      });
    });

    /* --------- 注册页：账号可用性实时检测 --------- */
    var uTimer = null, uSeq = 0;
    $('rgUser').addEventListener('input', function () {
      var v = this.value.trim();
      clearTimeout(uTimer);
      var tip = $('rgUserTip');
      if (!v) { tip.textContent = ''; tip.className = 'reg-tip'; return; }
      if (!/^[A-Za-z0-9_]{3,32}$/.test(v)) {
        tip.textContent = '3-32 位字母、数字或下划线';
        tip.className = 'reg-tip err';
        return;
      }
      var my = ++uSeq;
      uTimer = setTimeout(function () {
        api('check_username', { username: v }, 'GET').then(function (r) {
          if (my !== uSeq) return;          // 输得快就丢掉过期结果
          if (r.available) {
            tip.textContent = '账号可用';
            tip.className = 'reg-tip ok';
          } else {
            tip.textContent = r.reason || '该账号已被注册';
            tip.className = 'reg-tip err';
          }
        }).catch(function () {});
      }, 300);
    });

    /* --------- 注册页：密码强度 --------- */
    function strength(p) {
      var s = 0;
      if (p.length >= 6) s++;
      if (p.length >= 10) s++;
      if (/[A-Za-z]/.test(p) && /\d/.test(p)) s++;
      if (/[^A-Za-z0-9]/.test(p)) s++;
      return s;
    }
    $('rgPass').addEventListener('input', function () {
      var p = this.value, tip = $('rgPwTip');
      if (!p) { tip.textContent = ''; tip.className = 'reg-tip'; return; }
      var names = ['太弱', '较弱', '一般', '不错', '很强'];
      var s = strength(p);
      tip.textContent = p.length < 6 ? '密码强度：至少 6 位' : '密码强度：' + names[Math.min(s, 4)];
      tip.className = 'reg-tip ' + (p.length < 6 ? 'err' : ['err', 'warn', 'ok', 'ok', 'ok'][Math.min(s, 4)]);
    });
    return;
  }

  /* =========================================================
   *  聊天主程序
   * ======================================================= */
  var S = {
    me: BOOT.user,
    convs: BOOT.conversations || [],
    friends: BOOT.friends || [],
    requests: BOOT.requests || [],
    fgroups: BOOT.fgroups || [],
    blocks: BOOT.blocks || [],
    view: 'chat',
    list: 'convs',
    cid: 0,
    msgs: {},          // cid -> array
    since: 0,
    online: {},
    members: {},
    polling: false,
    retryMs: 350,
    searchKw: '',
    filter: '',
    lock: '',          // 非空表示我不能发言，值是原因
    fgOpen: {},        // 好友分组 id -> true 表示展开
    oldest: {},        // cid -> 当前已加载的最老一条消息 id，用来判断「没有更多了」
    noMore: {},        // cid -> true 表示历史已经翻到顶
    favs: BOOT.favs || [],          // 收藏过的消息 id
    favList: [],                    // 收藏列表（favorites 接口的完整数据）
    grequests: BOOT.grequests || [],// 我发出的、还在等审批的入群申请
    phrases: BOOT.phrases || [],    // 快捷短语
    reply: null,        // 正在引用的消息
    mentions: {},       // cid -> [userId] 手动 @ 过的人
    mentionPick: -1,    // @ 候选列表当前高亮项
    mentionAt: -1       // 输入框里 @ 关键字的起始位置
  };

  (function initOnline() {
    (S.friends || []).forEach(function (f) { S.online[f.id] = !!f.online; });
    var me = S.me; if (me) S.online[me.id] = true;
  })();

  function convById(cid) {
    for (var i = 0; i < S.convs.length; i++) if (S.convs[i].id === cid) return S.convs[i];
    return null;
  }
  function peerOf(c) { return c ? c.peer : null; }

  /* ---------------- 表情 ---------------- */
  var EMOJI = ('😀😃😄😁😆😅🤣😂🙂🙃😉😊😇🥰😍🤩😘😗😚😙😋😛😜🤪😝🤗🤭🤔🤐😐😑😶😏😒🙄😬😔😪😴😷🤒🤕🤢🤮🥵🥶😵🤯🤠🥳😎🤓🧐😕😟🙁😮😯😲😳🥺😦😧😨😰😥😢😭😱😖😣😞😓😩😫🥱😤😡😠🤬😈👿💀💩🤡👻👽👾🤖🎃😺😸😹😻😼😽🙀😿😾👋🤚🖐✋🖖👌🤌✌️🤞🤟🤘🤙👈👉👆👇☝️👍👎✊👊👏🙌🙏💪🦾👀👁🧠🫶❤️🧡💛💚💙💜🖤🤍🤎💔💯🔥✨🎉🎊⭐🌟💫💥☀️🌙🎁🎈🍀🍎🍉🍊🍋🍑🥂🍻☕🍵').match(/./gu);
  var FACES = {
    '撇嘴': '😖', '抓狂': '😫', '流泪': '😢', '大哭': '😭', '尴尬': '😅', '发怒': '😠',
    '调皮': '😜', '呲牙': '😁', '笑哭': '😂', '无语': '😑', '惊喜': '😲', '难过': '😞',
    '酷': '😎', '晕': '😵', '吐舌': '😝', '困': '😪', '饥饿': '🍔', '恐惧': '😨',
    '衰': '😞', '闭嘴': '🤐', '转圈': '😵', '强': '👍', '弱': '👎', '握手': '🤝',
    '胜利': '✌️', '抱拳': '🙏', '跳跳': '🕺', '庆祝': '🎉', '礼物': '🎁', '红包': '🧧',
    '心': '❤️', '心碎': '💔', '玫瑰': '🌹', '凋谢': '🥀', '凋': '🥀', '菜刀': '🔪',
    '啤酒': '🍺', '咖啡': '☕', '西瓜': '🍉', '太阳': '☀️', '月亮': '🌙', '彩虹': '🌈',
    '钱': '💰', '疑问': '❓', '闪电': '⚡', '炸弹': '💣', '便便': '💩', '骷髅': '💀'
  };
  function renderFaces(text) {
    return text.replace(/\[([^\[\]\/]{1,6})\]/g, function (all, name) {
      var k = name.trim();
      return FACES[k] ? '<span class="emoji-in">' + FACES[k] + '</span>' : all;
    });
  }
  function linkify(text) {
    return text.replace(/(https?:\/\/[^\s<]{4,})/g, function (u) {
      return '<a href="' + u + '" target="_blank" rel="noopener noreferrer">' + u + '</a>';
    });
  }

  /* =========================================================
   *  侧边列表渲染
   * ======================================================= */
  function renderSide() {
    var box = $('sideList');
    if (!box) return;
    var kw = (S.filter || '').trim().toLowerCase();
    var html = '';

    if (S.list === 'convs') {
      var convs = S.convs.slice();
      if (kw) {
        convs = convs.filter(function (c) {
          return (c.title || '').toLowerCase().indexOf(kw) >= 0;
        });
      }
      if (!convs.length) {
        html = emptyBox(kw ? '没有匹配的会话' : '还没有会话', kw ? '' : '去「联系人」添加好友开始聊天');
      } else {
        html = convs.map(function (c) {
          var who = c.type === 'single' ? (c.peer || {}) : null;
          var prev = c.last ? previewOf(c, c.last) : '';
          var time = c.time ? timeText(c.time) : '';
          var badge = (!c.muted && c.unread > 0) ? '<span class="badge-unread">' + (c.unread > 99 ? '99+' : c.unread) + '</span>' : '';
          var dot = '';
          if (who) {
            dot = '<i class="presence' + (S.online[who.id] ? ' on' : '') + '" title="' +
                  esc(S.online[who.id] ? '当前在线' : lastSeenTitle(who.last_seen)) + '"></i>';
          }
          return '<div class="conv' + (S.cid === c.id ? ' on' : '') + '" data-cid="' + c.id + '">' +
                   avaHtml(who || { id: c.id, display: c.title }, 'rnd') + dot +
                   '<div class="c-main">' +
                     '<div class="c-top"><span class="c-name">' + esc(c.title) + '</span>' +
                     '<span class="c-time">' + esc(time) + '</span></div>' +
                     '<div class="c-bot"><span class="c-prev">' + prev + '</span>' + badge + '</div>' +
                   '</div>' +
                 '</div>';
        }).join('');
      }
    } else if (S.list === 'friends' || S.list === 'groups') {
      var wantGroup = S.list === 'groups';
      var arr = wantGroup
        ? S.convs.filter(function (c) { return c.type === 'group'; })
        : S.friends.slice();
      if (kw) {
        arr = arr.filter(function (x) {
          return (x.title || x.display || x.nickname || '').toLowerCase().indexOf(kw) >= 0;
        });
      }
      if (!arr.length) {
        html = emptyBox(kw ? '没有匹配的结果' : (wantGroup ? '还没有群聊' : '还没有好友'),
          kw ? '' : '在「联系人」里搜索添加');
      } else {
        html = arr.map(function (x) {
          if (wantGroup) {
            return '<div class="conv' + (S.cid === x.id ? ' on' : '') + '" data-cid="' + x.id + '">' +
                     avaHtml({ id: x.id, display: x.title, avatar: x.avatar }, 'rnd') +
                     '<div class="c-main"><div class="c-top">' +
                     '<span class="c-name">' + esc(x.title) + '</span>' +
                     '<span class="c-time">' + (x.member_count || 0) + ' 人</span></div>' +
                     '<div class="c-bot"><span class="c-prev">' + (x.last ? previewOf(x, x.last) : '暂无消息') + '</span>' +
                     (!x.muted && x.unread > 0 ? '<span class="badge-unread">' + x.unread + '</span>' : '') +
                     '</div></div></div>';
          }
          var f = x;
          var cid = findConvId(f.id);
          return '<div class="person" data-uid="' + f.id + '"' + (cid ? ' data-cid="' + cid + '"' : '') + '>' +
                   avaHtml(f, 'rnd') +
                   '<i class="presence' + (S.online[f.id] ? ' on' : '') + '"></i>' +
                   '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(f.display) + '</span></div>' +
                   '<div class="c-bot"><span class="c-prev">' + lastSeenHtml(f.last_seen, S.online[f.id]) + '</span>' +
                   (f.friend_status === 0 ? '<span class="pill warn">待通过</span>' : '') +
                   '</div></div></div>';
        }).join('');
      }
    }
    box.innerHTML = html;

    // 角标
    var total = S.convs.reduce(function (a, c) { return a + (c.muted ? 0 : c.unread); }, 0);
    var railBadge = $('railUnread');
    if (total > 0) { railBadge.classList.remove('hidden'); railBadge.textContent = total > 99 ? '99+' : total; }
    else { railBadge.classList.add('hidden'); }

    var fb = $('friendBadge');
    if (S.requests.length) { fb.classList.remove('hidden'); fb.textContent = S.requests.length; }
    else { fb.classList.add('hidden'); }

    document.title = total > 0 ? '(' + total + ') ' + BOOT.title : BOOT.title;
  }

  function emptyBox(a, b) {
    return '<div class="list-empty"><b>' + esc(a) + '</b>' + esc(b || '') + '</div>';
  }
  function findConvId(uid) {
    for (var i = 0; i < S.convs.length; i++) {
      var c = S.convs[i];
      if (c.type === 'single' && c.peer && c.peer.id === uid) return c.id;
    }
    return 0;
  }
  function previewOf(c, m) {
    if (m.type === 'recalled') {
      return '<span style="color:#c0c0c0">' +
        (c.type === 'group' ? (m.mine ? '我' : (m.nickname || '某人')) + ': ' : '') +
        '撤回了一条消息</span>';
    }
    var body;
    if (m.type === 'image') body = '[图片]';
    else if (m.type === 'file') body = '[文件] ' + esc((m.meta && m.meta.name) || '');
    else body = esc(m.content);
    // 私聊和系统提示只显示内容；群聊才加「谁: 」前缀，且只出现一次
    var who = '';
    if (c.type === 'group' && m.type !== 'system') {
      who = (m.mine ? '我' : (m.nickname || '某人')) + ': ';
    }
    return '<span style="color:#c0c0c0">' + who + '</span>' + body;
  }

  /* =========================================================
   *  消息区渲染
   * ======================================================= */
  function renderMsgs(cid) {
    var list = $('msgList');
    var arr = S.msgs[cid] || [];
    if (!arr.length) {
      list.innerHTML = '<div class="sys">没有消息，发一句开始聊天吧</div>';
      return;
    }
    var c = convById(cid);
    var isGroup = c && c.type === 'group';
    var html = '', lastTs = 0;

    arr.forEach(function (m) {
      if (m.time - lastTs > 300) {
        html += '<div class="time-sep">' + esc(fullTime(m.time)) + '</div>';
        lastTs = m.time;
      }
      if (m.type === 'system') {
        html += '<div class="sys"><b>' + esc(m.content) + '</b></div>';
        return;
      }
      if (m.type === 'recalled') {
        // 群里撤回时后端另有一条系统提示写明是谁撤的，这里只占位不重复
        html += '<div class="msg-recalled">' +
          (isGroup ? '该消息已被撤回' : '你撤回了一条消息') +
        '</div>';
        return;
      }
      var mine = !!m.mine;
      var user = mine ? S.me : { id: m.sender, display: m.nickname, avatar: m.avatar };
      var dl = apiUrl('download', 'm=' + m.id);
      var body = '';

      if (m.type === 'image') {
        body = '<a href="' + dl + '" target="_blank" rel="noopener"><img class="msg-img" loading="lazy" src="' + dl + '" alt="图片"></a>';
      } else if (m.type === 'file') {
        var nm = (m.meta && m.meta.name) || '文件';
        var ext = (nm.split('.').pop() || '').toUpperCase().slice(0, 4);
        var icon = '<div class="file-ico">' + esc(ext) + '</div>';
        if (m.meta && m.meta.path && /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(nm)) {
          icon = '<div class="file-ico"><img src="' + dl + '" alt=""></div>';
        }
        body = '<div class="msg-file" data-dl="' + dl + '">' + icon +
               '<div class="file-info"><div class="file-name">' + esc(nm) + '</div>' +
               '<div class="file-size">' + esc(fileSize((m.meta && m.meta.size) || 0)) + ' · 点击下载</div></div></div>';
      } else {
        body = '';   // 纯文本的最终 HTML 在下面算好（要带 @ 高亮）
      }

      var showName = (isGroup && !mine) ? '<div class="bubble-name">' + esc(m.nickname || '用户') + '</div>' : '';

      // 引用块：点一下跳到被引用的那条
      var quoteHtml = '';
      if (m.quote && (m.quote.content !== undefined || m.quote.name)) {
        var qText = m.quote.content;
        if (m.quote.type === 'image') qText = '[图片]';
        else if (m.quote.type === 'file') qText = '[文件]';
        if (qText === undefined || qText === null) qText = '';
        quoteHtml = '<div class="quote" data-jump="' + (m.reply_to || 0) + '">' +
                      '<span class="q-name">' + esc(m.quote.nickname || '') + '</span>' +
                      '<span class="q-text">' + esc(String(qText).slice(0, 80)) + '</span>' +
                    '</div>';
      }

      // @ 高亮：把 @ 到的人名做成标签（昵称取群成员列表，群里才有意义）
      var contentHtml = renderFaces(linkify(m.content));
      if (m.mentions && m.mentions.length && isGroup) {
        var mmap = memberNameMap();
        m.mentions.forEach(function (uid) {
          var nm = mmap[uid];
          if (!nm) return;
          contentHtml = contentHtml.split(esc('@' + nm)).join('<span class="at-mention">@' + esc(nm) + '</span>');
        });
      }

      if (!body) body = contentHtml;

      var atMe = m.at_me ? ' at-me' : '';
      var isFav = isFavMsg(m.id) ? ' starred' : '';

      html += '<div class="msg' + (mine ? ' mine' : '') + atMe + isFav + '" data-mid="' + m.id + '">' +
                avaHtml(user) +
                '<div class="bubble-wrap">' + showName + quoteHtml +
                  '<div class="bubble">' + body + '</div>' +
                '</div>' +
                (isFavMsg(m.id) ? '<span class="msg-star" title="已收藏">★</span>' : '') +
              '</div>';
    });

    list.innerHTML = html;
    scrollBottom(true);
  }

  function isFavMsg(id) {
    return (S.favs || []).indexOf(id) >= 0;
  }

  /** 当前群成员 id -> 展示名，用来把 @昵称 还原成真实的人 */
  function memberNameMap() {
    var map = {};
    (S.members[S.cid] || []).forEach(function (x) {
      map[x.id] = x.display || x.card || x.nickname || '';
    });
    return map;
  }

  function scrollBottom(force) {
    var box = $('msgScroll');
    if (!box) return;
    if (force || box.scrollHeight - box.scrollTop - box.clientHeight < 120) {
      box.scrollTop = box.scrollHeight;
    }
  }
  function nearBottom() {
    var box = $('msgScroll');
    return box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  }

  /**
   * 应用「我不能发言」状态：禁言 / 全员禁言 / 被踢出群。
   * 服务端 send 也会拦一道，这里只是提前告诉用户为什么发不出去。
   */
  function applyLock(reason) {
    if (S.lock === reason) return;
    S.lock = reason || '';
    var bar = $('sendLock'), ed = document.querySelector('.editor');
    if (reason) {
      bar.innerHTML = '<svg class="sl-icon" viewBox="0 0 24 24"><path d="M12 2a8 8 0 018 8v5l2 3H2l2-3v-5a8 8 0 018-8zm-4 18h8a4 4 0 01-8 0z"/></svg>' +
                     '<span>' + esc(reason) + '</span>';
      bar.classList.remove('hidden');
      ed.classList.add('locked');
      $('input').placeholder = reason;
    } else {
      bar.classList.add('hidden');
      bar.textContent = '';
      ed.classList.remove('locked');
      $('input').placeholder = '输入消息，Enter 发送';
    }
  }

  function mergeMsgs(cid, arr) {
    var cur = S.msgs[cid] || (S.msgs[cid] = []);
    var seen = {};
    cur.forEach(function (m) { seen[m.id] = 1; });
    arr.forEach(function (m) {
      if (!seen[m.id]) {
        cur.push(m);
        seen[m.id] = 1;
        if (m.id > S.since) S.since = m.id;
      }
    });
    cur.sort(function (a, b) { return a.id - b.id; });
    if (cur.length > 400) cur.splice(0, cur.length - 400);
  }

  /* =========================================================
   *  主区域切换
   * ======================================================= */

  /* 手机端是「单页」：列表页和主区不能同时占屏，390px 宽挤不下。
   * 所以给 <body> 挂一个 peek 类，由 CSS 决定此刻显示哪一半。

   * 什么时候算「看主区」：
   *   联系人 / 收藏 / 设置        -> 看主区
   *   消息，且已经选了某个会话      -> 看主区
   *   消息，但一个会话都没选        -> 看列表（#mainEmpty 那个
   *                                  「选择一个会话开始聊天」在手机上是
   *                                  废话，不该顶掉整个列表）
   *
   * peek = 看主区。
   */
  function syncPeek() {
    var showMain = S.view !== 'chat' || !!convById(S.cid);
    document.body.classList.toggle('peek', showMain);
  }

  function renderMain() {
    $('mainEmpty').classList.add('hidden');
    $('chatPanel').classList.add('hidden');
    $('contactsPanel').classList.add('hidden');
    $('favoritesPanel').classList.add('hidden');
    $('settingsPanel').classList.add('hidden');

    if (S.view === 'favorites') {
      $('favoritesPanel').classList.remove('hidden');
      renderFavs();
      updateFavBadge();
      return;
    }
    if (S.view === 'chat') {
      var c = convById(S.cid);
      if (!c) {
        $('mainEmpty').classList.remove('hidden');
        return;
      }
      $('chatPanel').classList.remove('hidden');
      $('chatName').textContent = c.title;
      var sub;
      var subTitle = '';
      if (c.type === 'group') {
        sub = c.member_count + ' 名群成员';
        if (c.announcement) {
          sub += ' · ' + (c.announcement.length > 18 ? c.announcement.slice(0, 18) + '…' : c.announcement);
        }
      } else {
        var p = peerOf(c);
        sub = p ? (S.online[p.id] ? '在线' : lastSeenText(p.last_seen)) : '';
        if (p && p.signature) sub += ' · ' + p.signature;
        // chatSub 是 textContent，塞不了悬停提示，这里把精确时间挂到 title 上
        if (p) subTitle = S.online[p.id] ? '当前在线' : lastSeenTitle(p.last_seen);
      }
      $('chatSub').textContent = sub;
      $('chatSub').title = subTitle;
      $('btnMute').classList.toggle('on', !!c.muted);
      renderMsgs(S.cid);
    } else if (S.view === 'contacts') {
      $('contactsPanel').classList.remove('hidden');
      renderContacts();
    } else {
      $('settingsPanel').classList.remove('hidden');
    }
  }

  function setView(v) {
    S.view = v;
    var btns = document.querySelectorAll('.rail-btn[data-view]');
    for (var i = 0; i < btns.length; i++) {
      btns[i].classList.toggle('on', btns[i].getAttribute('data-view') === v);
    }
    if (v === 'groups') { S.list = 'groups'; setListTab('groups'); }
    if (v === 'contacts') { S.list = 'friends'; setListTab('friends'); }
    if (v === 'settings') { S.list = 'convs'; setListTab('convs'); }
    if (v === 'favorites') { S.list = 'convs'; setListTab('convs'); }
    renderMain();
    renderSide();
    syncPeek();
  }
  function setListTab(name) {
    S.list = name;
    var tabs = document.querySelectorAll('#sideTabs button');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.toggle('on', tabs[i].getAttribute('data-list') === name);
    }
  }

  function openConv(cid) {
    var c = convById(cid);
    if (!c) return;
    S.cid = cid;
    S.list = 'convs';
    setListTab('convs');
    setView('chat');
    renderSide();
    $('btnMore').classList.add('hidden');
    // 群成员要提前拉好：@ 候选和 @高亮都要用，点了群资料再拉就晚了
    if (c.type === 'group' && !S.members[cid]) {
      api('group_members', { cid: cid }).then(function (r) {
        S.members[cid] = r.members || [];
      }).catch(function () {});
    }
    loadHistory(cid, 0).then(function () {
      renderMsgs(cid);
      markRead(cid);
    });
    $('input').focus();
  }

  function loadHistory(cid, before) {
    return api('history', { cid: cid, before: before, limit: 30 }).then(function (r) {
      var got = r.messages || [];
      mergeMsgs(cid, got);
      if (before === 0) {
        S.msgs[cid] = (S.msgs[cid] || []).slice(-300);
        $('btnMore').classList.toggle('hidden', got.length < 30);
        S.noMore[cid] = got.length < 30;
        S.oldest[cid] = got.length ? got[0].id : 0;
        if (r.send_lock !== undefined) applyLock(r.send_lock || '');
      } else if (got.length) {
        S.oldest[cid] = got[0].id;
        S.noMore[cid] = got.length < 30;
      }
      return r;
    });
  }

  function markRead(cid) {
    if (!cid) return;
    api('mark_read', { cid: cid }, 'POST').then(function (r) {
      if (r.conversations) S.convs = r.conversations;
      renderSide();
    }).catch(function () {});
  }

  /* =========================================================
   *  发送消息
   * ======================================================= */
  var typingTimer = null, typingSent = 0;

  function sendMessage() {
    var box = $('input');
    var text = box.value.replace(/\s+$/, '');
    if (!S.cid || !text) return;
    if (text.length > 2000) { toast('消息过长，请分段发送', 'err'); return; }

    var mentions = collectMentions(text);
    doSend({
      type: 'text', content: text, meta: {},
      reply_to: S.reply ? S.reply.id : 0,
      mentions: mentions
    }).then(function () {
      box.value = ''; updateCount();
      setReply(null);
      box.focus();
    });
  }

  /**
   * 从正文里捞出被 @ 到的人。
   * 两种来源：候选项选人时记进 S.mentions[cid]，以及用户自己手打 @昵称。
   */
  function collectMentions(text) {
    var out = {};
    (S.mentions[S.cid] || []).forEach(function (id) { out[id] = 1; });
    var c = convById(S.cid);
    if (c && c.type === 'group') {
      (S.members[S.cid] || []).forEach(function (mm) {
        var nm = mm.display || mm.card || mm.nickname || '';
        if (nm && text.indexOf('@' + nm) >= 0) out[mm.id] = 1;
      });
    }
    // 自己 @ 自己没意义，还会让「@我」误亮
    delete out[S.me.id];
    return Object.keys(out).map(Number);
  }

  function doSend(payload) {
    if (!S.cid) { toast('请先选择会话', 'err'); return Promise.resolve(); }
    var body = {
      cid: S.cid,
      type: payload.type,
      content: payload.content || '',
      meta: payload.meta || {}
    };
    if (payload.reply_to) body.reply_to = payload.reply_to;
    if (payload.mentions && payload.mentions.length) body.mentions = payload.mentions;

    return api('send', body, 'POST').then(function (r) {
      // 本地先渲染，轮询会补齐
      // reply_to / mentions 用服务端返回的（服务端会校验，别信前端）
      var fake = {
        id: r.id, conv: S.cid, sender: S.me.id, type: payload.type,
        content: payload.content || '', meta: payload.meta || {},
        reply_to: r.reply_to || 0, mentions: r.mentions || [],
        time: r.time, nickname: S.me.nickname, avatar: S.me.avatar, mine: true
      };
      if (r.reply_to) fake.quote = findMsg(r.reply_to);
      mergeMsgs(S.cid, [fake]);
      if (r.id > S.since) S.since = r.id;
      renderMsgs(S.cid);
      return r;
    }).catch(function (err) {
      toast(err.message, 'err');
      throw err;
    });
  }

  function findMsg(mid) {
    var arr = S.msgs[S.cid] || [];
    for (var i = 0; i < arr.length; i++) if (arr[i].id === mid) return arr[i];
    return null;
  }

  /* =========================================================
   *  上传
   * ======================================================= */
  function uploadFile(file, kind) {
    if (!file) return Promise.resolve(null);
    if (file.size > BOOT.max_mb * 1024 * 1024) {
      toast('文件超过 ' + BOOT.max_mb + 'MB 限制', 'err');
      return Promise.resolve(null);
    }
    var fd = new FormData();
    fd.append('file', file);
    fd.append('kind', kind);
    return api('upload', fd, 'POST').then(function (r) {
      return r;
    }).catch(function (err) {
      toast(err.message, 'err');
      return null;
    });
  }

  function pickAndSend(kind) {
    var input = document.createElement('input');
    input.type = 'file';
    if (kind === 'image') input.accept = 'image/*'; else input.multiple = true;
    input.onchange = function () {
      var files = Array.prototype.slice.call(input.files || []);
      files.forEach(function (f) {
        uploadFile(f, kind).then(function (r) {
          if (!r) return;
          if (kind === 'image') doSend({ type: 'image', content: r.path, meta: r });
          else doSend({ type: 'file', content: r.path, meta: r });
        });
      });
    };
    input.click();
  }

  /* =========================================================
   *  表情面板
   * ======================================================= */
  function buildEmoji() {
    var p = $('emojiPanel');
    if (!p) return;
    if (p.dataset.built) return;
    p.dataset.built = '1';
    p.innerHTML = EMOJI.map(function (e) {
      return '<button type="button">' + e + '</button>';
    }).join('');
    p.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b) return;
      var box = $('input');
      var s = box.value;
      box.value = s + b.textContent;
      box.focus();
      updateCount();
    });
  }
  function toggleEmoji() {
    var p = $('emojiPanel');
    buildEmoji();
    p.classList.toggle('hidden');
  }

  function updateCount() {
    var n = $('input').value.length;
    var el = $('charCount');
    if (el) el.textContent = n + '/2000';
  }

  /* =========================================================
   *  引用回复
   * ======================================================= */
  function setReply(m) {
    S.reply = m || null;
    var bar = $('replyBar');
    if (!bar) return;
    if (!m) {
      bar.classList.add('hidden');
      return;
    }
    var who = m.mine ? '我' : (m.nickname || '某人');
    var txt = m.content || '';
    if (m.type === 'image') txt = '[图片]';
    else if (m.type === 'file') txt = '[文件] ' + ((m.meta && m.meta.name) || '');
    $('replyTitle').textContent = '引用 ' + who + ' 的消息';
    $('replyText').textContent = txt.length > 90 ? txt.slice(0, 90) + '…' : txt;
    bar.classList.remove('hidden');
  }

  /* =========================================================
   *  @ 某人：输入框内候选列表
   * ======================================================= */
  function hideMention() {
    var p = $('mentionPop');
    if (p) p.classList.add('hidden');
    S.mentionPick = -1;
    S.mentionAt = -1;
  }

  function mentionCandidates(kw) {
    var c = convById(S.cid);
    if (!c || c.type !== 'group') return [];
    kw = kw.toLowerCase();
    return (S.members[S.cid] || []).filter(function (m) {
      if (m.id === S.me.id) return false;
      var nm = (m.display || m.card || m.nickname || '').toLowerCase();
      return nm.indexOf(kw) >= 0;
    }).slice(0, 20);
  }

  function updateMention() {
    var box = $('input');
    var pop = $('mentionPop');
    if (!pop) return;
    var pos = box.selectionStart || 0;
    var before = box.value.slice(0, pos);
    var at = before.lastIndexOf('@');
    if (at < 0) { hideMention(); return; }
    // @ 后面只能是昵称字符，出现别的就当普通文本
    var kw = before.slice(at + 1);
    if (kw.length > 20 || /[\s,.:;!?，。！？]/.test(kw)) { hideMention(); return; }

    var list = mentionCandidates(kw);
    if (!list.length) { hideMention(); return; }

    S.mentionAt = at;
    S.mentionPick = 0;
    pop.innerHTML = list.map(function (m, i) {
      var nm = m.display || m.card || m.nickname || '';
      return '<button type="button" class="mitem' + (i === 0 ? ' on' : '') +
             '" data-uid="' + m.id + '" data-name="' + esc(nm) + '">' +
             avaHtml(m) + '<span class="mname">' + esc(nm) + '</span>' +
             (m.role_name ? '<span class="mrole">' + esc(m.role_name) + '</span>' : '') +
             '</button>';
    }).join('');
    pop.classList.remove('hidden');
  }

  function applyMention(btn) {
    var box = $('input');
    var uid = parseInt(btn.getAttribute('data-uid'), 10);
    var nm = btn.getAttribute('data-name');
    if (!uid || !nm) return;
    var at = S.mentionAt;
    var pos = box.selectionStart || box.value.length;
    var head = box.value.slice(0, at);
    var tail = box.value.slice(pos);
    var ins = '@' + nm + ' ';
    box.value = head + ins + tail;
    var next = head.length + ins.length;
    box.focus();
    try { box.setSelectionRange(next, next); } catch (e) {}

    if (!S.mentions[S.cid]) S.mentions[S.cid] = [];
    if (S.mentions[S.cid].indexOf(uid) < 0) S.mentions[S.cid].push(uid);
    hideMention();
    updateCount();
  }

  /* =========================================================
   *  快捷短语
   * ======================================================= */
  function buildPhrases() {
    var p = $('phrasePanel');
    if (!p) return;
    if (p.dataset.built) return;
    p.dataset.built = '1';
    var list = S.phrases || [];
    p.innerHTML = list.map(function (x) {
      return '<button type="button" class="ph-item">' + esc(x) + '</button>';
    }).join('') || '<div class="ph-empty">还没有快捷短语</div>';
    p.addEventListener('click', function (e) {
      var b = e.target.closest('.ph-item');
      if (!b) return;
      var box = $('input');
      box.value = (box.value ? box.value.replace(/\s+$/, '') + ' ' : '') + b.textContent;
      p.classList.add('hidden');
      box.focus();
      updateCount();
    });
  }
  function togglePhrases() {
    var p = $('phrasePanel');
    if (!p) return;
    buildPhrases();
    p.classList.toggle('hidden');
  }

  /* =========================================================
   *  搜群号加群
   * ======================================================= */
  function joinGroupModal() {
    openModal('搜群号加群',
      '<div class="join-hint">输入群号（纯数字）或群名称搜索，找到后点「申请入群」。</div>' +
      '<input class="inp" id="joinKw" maxlength="32" placeholder="例如 123456789" autocomplete="off">' +
      '<div class="join-list" id="joinList"></div>',
      function () {}, '关闭');

    var box = $('joinKw');
    var list = $('joinList');
    box.addEventListener('input', function () {
      var kw = box.value.trim();
      if (!kw) { list.innerHTML = ''; return; }
      api('group_search', { kw: kw, limit: 20 }).then(function (r) {
        var arr = r.groups || [];
        if (!arr.length) {
          list.innerHTML = '<div class="muted" style="padding:14px 4px">没找到群，换个群号试试</div>';
          return;
        }
        list.innerHTML = arr.map(function (g) {
          return '<div class="pick" data-gno="' + esc(g.gno) + '">' +
            avaHtml({ id: g.id, display: g.title, avatar: g.avatar }, 'rnd') +
            '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(g.title) + '</span></div>' +
            '<div class="c-bot"><span class="c-prev">群号 ' + esc(g.gno) + ' · ' + g.member_count + ' 人</span></div></div>' +
            '<div class="gacts"><button class="btn-primary sm" data-join="' + esc(g.gno) + '">申请入群</button></div>' +
            '</div>';
        }).join('');
      }).catch(function (e) { toast(e.message, 'err'); });
    });
    list.addEventListener('click', function (e) {
      var b = e.target.closest('[data-join]');
      if (!b) return;
      doJoin(b.getAttribute('data-join'));
    });
    box.focus();
  }

  function doJoin(gno) {
    api('group_join', { gno: gno }, 'POST').then(function (r) {
      S.grequests = r.grequests || S.grequests;
      renderSide();
      if (r.joined) toast('已加入群聊', 'ok');
      else if (r.requested) toast('申请已发出，等群主或管理员同意', 'ok');
      else toast('无法加入该群', 'err');
      clearJoin();
    }).catch(function (e) { toast(e.message, 'err'); });
  }
  function clearJoin() {
    var list = $('joinList');
    if (list) list.innerHTML = '';
    var kw = $('joinKw');
    if (kw) kw.value = '';
  }

  /* =========================================================
   *  群文件
   * ======================================================= */
  function groupFilesModal(cid) {
    var c = convById(cid);
    api('conv_files', { cid: cid, limit: 200 }).then(function (r) {
      var arr = r.files || [];
      var rows = arr.map(function (f) {
        var dl = apiUrl('download', 'm=' + f.id);
        return '<div class="pick" style="cursor:default">' +
          '<div class="file-ico">' + esc((String(f.name || '').split('.').pop() || '').toUpperCase().slice(0, 4)) + '</div>' +
          '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(f.name || '文件') + '</span></div>' +
          '<div class="c-bot"><span class="c-prev">' + esc(f.sender_name || '') + ' · ' +
            esc(fullTime(f.time)) + ' · ' + esc(fileSize(f.size || 0)) + '</span></div></div>' +
          '<div class="gacts"><a class="btn-ghost sm" href="' + dl + '">下载</a></div></div>';
      }).join('');
      openModal((c ? c.title : '群聊') + ' · 群文件（' + arr.length + '）',
        rows || '<div class="muted" style="padding:14px 4px">还没有人发过文件</div>',
        function () {}, '关闭');
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  /* =========================================================
   *  收藏面板
   * ======================================================= */
  function renderFavs() {
    api('favorites', { limit: 200 }).then(function (r) {
      S.favList = r.favorites || [];
      var box = $('favoritesBody');
      if (!box) return;
      $('favCount').textContent = S.favList.length + ' 条';
      if (!S.favList.length) {
        box.innerHTML = emptyBox('★', '还没有收藏', '在聊天里右键任意消息，选「收藏」就会出现在这里');
        return;
      }
      box.innerHTML = S.favList.map(function (f) {
        var body;
        if (f.type === 'image') body = '[图片]';
        else if (f.type === 'file') body = '[文件] ' + ((f.meta && f.meta.name) || '');
        else body = esc(f.content || '');
        return '<div class="fav-item" data-cid="' + (f.conv || 0) + '" data-mid="' + f.id + '">' +
          '<div class="fav-hd"><span class="fav-conv">' + esc(f.conv_title || '') + '</span>' +
            '<span class="fav-time">' + esc(fullTime(f.time)) + '</span></div>' +
          '<div class="fav-body">' + body + '</div>' +
          '<div class="fav-fx"><button class="linkbtn" data-favgo="' + (f.conv || 0) + '">回到会话</button>' +
          '<button class="linkbtn danger" data-favdel="' + f.id + '">取消收藏</button></div>' +
          '</div>';
      }).join('');
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  function notifyTyping() {
    if (!S.cid) return;
    var now = Date.now();
    if (now - typingSent < 2500) return;
    typingSent = now;
    api('typing', { cid: S.cid }, 'POST').catch(function () {});
  }

  /* =========================================================
   *  长轮询
   * ======================================================= */
  function pollLoop() {
    if (S.polling) return;
    S.polling = true;
    var activeBefore = S.cid;
    var stick = nearBottom();

    api('poll', { since: S.since, cid: S.cid, wait: 20 }).then(function (r) {
      S.retryMs = r.retry_ms || 350;
      if (r.max_id && r.max_id > S.since) S.since = r.max_id;
      if (r.conversations && r.conversations.length) S.convs = r.conversations;
      if (r.online) {
        r.online.forEach(function (o) { S.online[o.id] = !!o.online; });
      }
      if (r.messages && r.messages.length) {
        mergeMsgs(S.cid, r.messages);
        if (activeBefore === S.cid) {
          renderMsgs(S.cid);
          if (!stick) markRead(S.cid);
        }
      }
      // 禁言状态由服务端推，不用等用户点开群才发现
      if (r.send_lock !== undefined) applyLock(r.send_lock || '');
      // 当前会话可能已经被踢掉 / 群被解散了
      if (activeBefore && !convById(activeBefore)) {
        applyLock('你已不在该群聊中');
        var gone = S.cid;
        delete S.msgs[gone];
        S.cid = 0;
        S.view = 'chat';
        renderSide();
        renderMain();
      }
      showTyping(r.typing || []);
      renderSide();
      if (S.view === 'contacts') renderContacts();
    }).catch(function (e) {
      if (e && e.data && e.data.error && /登录/.test(e.data.error)) return;
    }).then(function () {
      S.polling = false;
      setTimeout(pollLoop, S.retryMs || 350);
    });
  }

  var typingMap = {};
  function showTyping(list) {
    var box = $('typingTip');
    if (!box) return;
    typingMap = {};
    list.forEach(function (t) { if (t.conv === S.cid) typingMap[t.user] = t.nick; });
    var names = Object.keys(typingMap).map(function (k) { return typingMap[k]; });
    if (names.length) {
      box.innerHTML = names.map(function (n) { return '<i>' + esc(n) + '</i>'; }).join('、') + ' 正在输入…';
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
  }

  /* =========================================================
   *  联系人面板
   * ======================================================= */

  /** 好友分组折叠状态，存在内存里，切换面板不丢 */
  function fgClosed(gid, def) {
    if (S.fgOpen[gid] === undefined) S.fgOpen[gid] = def;
    return !S.fgOpen[gid];
  }

  function renderContacts() {
    var box = $('contactsBody');
    if (!box) return;
    var html = '';

    // 我发出去、还在等审批的入群申请，让用户知道自己还要等
    if ((S.grequests || []).length) {
      html += '<div class="sub-head"><b>我的入群申请</b><span>' + S.grequests.length + ' 个待处理</span></div>';
      html += S.grequests.map(function (q) {
        return '<div class="req-item">' + avaHtml({ id: q.cid, display: q.title }, 'sm rnd') +
          '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(q.title) + '</span></div>' +
          '<div class="c-bot"><span class="c-prev">群号 ' + esc(q.gno || '-') + ' · ' + esc(timeText(q.time)) + ' 申请</span></div></div>' +
          '<span class="pill warn">等待审核</span></div>';
      }).join('');
    }

    if (S.requests.length) {
      html += '<div class="sub-head"><b>新的朋友</b><span>' + S.requests.length + ' 条申请</span></div>';
      html += S.requests.map(function (r) {
        return '<div class="req-item">' + avaHtml(r, 'sm rnd') +
          '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(r.nickname) + '</span></div>' +
          '<div class="c-bot"><span class="c-prev">账号：' + esc(r.username) + '</span>' +
          (r.verify_msg ? '</div><div class="c-bot"><span class="c-prev">留言：' + esc(r.verify_msg) + '</span>' : '') +
          '</div></div>' +
          '<button class="btn-primary sm" data-acc="' + r.id + '">接受</button>' +
          '<button class="btn-ghost sm" data-rej="' + r.id + '">拒绝</button></div>';
      }).join('');
    }

    // 搜索添加
    html += '<div class="sub-head"><b>添加好友</b></div>' +
      '<div class="search-result">' +
        '<div class="search" style="flex:1"><svg viewBox="0 0 24 24"><path d="M10 4a6 6 0 104.2 10.3l4.5 4.5 1.4-1.4-4.5-4.5A6 6 0 0010 4zm0 2a4 4 0 110 8 4 4 0 010-8z"/></svg>' +
        '<input type="text" id="addKw" placeholder="输入账号或昵称"></div>' +
        '<button class="btn-primary sm" id="btnDoSearch">搜索</button>' +
      '</div>' +
      '<div id="searchOut"></div>';

    /* ---- 我的好友（按分组折叠） ---- */
    html += '<div class="sub-head"><b>我的好友</b><span>' + S.friends.length + ' 人</span></div>';
    if (!S.friends.length) {
      html += emptyBox('还没有好友', '用上面的搜索框找到你的伙伴');
    } else {
      var groups = S.fgroups || [];
      var ungrouped = S.friends.filter(function (f) { return !f.group_id; });

      function personHtml(f) {
        return '<div class="person" data-uid="' + f.id + '">' + avaHtml(f, 'sm rnd') +
          '<i class="presence' + (S.online[f.id] ? ' on' : '') + '"></i>' +
          '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(f.display) + '</span></div>' +
          '<div class="c-bot"><span class="c-prev">' +
          lastSeenHtml(f.last_seen, S.online[f.id]) + '</span></div></div></div>';
      }

      groups.forEach(function (g, gi) {
        var list = S.friends.filter(function (f) { return f.group_id === g.id; });
        var closed = fgClosed(g.id, gi > 1);
        html +=
          '<div class="fgrp-hd' + (closed ? ' closed' : '') + '" data-fg="' + g.id + '">' +
            '<span class="fgrp-arrow">▼</span>' +
            '<span class="fgrp-name">' + esc(g.name) + '</span>' +
            '<span class="muted" style="font-size:11.5px">' + list.length + '</span>' +
          '</div>' +
          '<div class="fgrp-body' + (closed ? ' closed' : '') + '" data-fgb="' + g.id + '">' +
            (list.length
              ? '<div class="people-grid">' + list.map(personHtml).join('') + '</div>'
              : '<div class="muted" style="padding:6px 10px 10px;font-size:12px">这个分组还没有人，右键好友可以把他移进来</div>') +
          '</div>';
      });

      if (ungrouped.length) {
        var uc = fgClosed(0, false);
        html +=
          '<div class="fgrp-hd' + (uc ? ' closed' : '') + '" data-fg="0">' +
            '<span class="fgrp-arrow">▼</span>' +
            '<span class="fgrp-name">未分组</span>' +
            '<span class="muted" style="font-size:11.5px">' + ungrouped.length + '</span>' +
          '</div>' +
          '<div class="fgrp-body' + (uc ? ' closed' : '') + '" data-fgb="0">' +
            '<div class="people-grid">' + ungrouped.map(personHtml).join('') + '</div>' +
          '</div>';
      }
    }
    box.innerHTML = html;

    var kw = $('addKw');
    if (kw) {
      kw.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); doSearch(kw.value); }
      });
    }

    // 折叠
    Array.prototype.forEach.call(box.querySelectorAll('[data-fg]'), function (hd) {
      hd.addEventListener('click', function () {
        var gid = Number(hd.getAttribute('data-fg'));
        S.fgOpen[gid] = fgClosed(gid, false);
        renderContacts();
      });
    });

    // 右键：移动到分组
    Array.prototype.forEach.call(box.querySelectorAll('.person'), function (p) {
      p.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        var uid = Number(p.getAttribute('data-uid'));
        showCtx(e.clientX, e.clientY, [
          { key: 'msg', label: '发消息', run: function () { openChatWith(uid); } },
          { key: 'card', label: '查看资料', run: function () { friendCard(uid); } },
          { key: 'move', label: '移动到分组…', hint: '右键', run: function () { moveFriendModal(uid); } },
          { key: 'del', label: '删除好友', danger: true, run: function () { delFriend(uid); } }
        ]);
      });
    });
  }

  function renderBlockCount() {
    var el = $('blockCount');
    if (el) el.textContent = (S.blocks || []).length + ' 人';
  }

  /* ---------------- 黑名单管理 ---------------- */
  function blockModal() {
    var list = (S.blocks || []).map(function (u) {
      return '<div class="sr-item">' + avaHtml(u, 'sm rnd') +
        '<div class="sr-main"><div class="c-top"><span class="c-name">' + esc(u.nickname) + '</span></div>' +
        '<div class="c-bot"><span class="c-prev">' + esc(u.username) + ' · 拉黑于 ' + esc(fullTime(u.time)) + '</span></div></div>' +
        '<button class="btn-ghost sm" data-unblock="' + u.id + '">移出黑名单</button></div>';
    }).join('');
    openModal('黑名单',
      '<div class="set-note" style="padding-top:0">黑名单里的用户无法给你发消息，你也不能给他们发消息。</div>' +
      (S.blocks && S.blocks.length
        ? '<div id="blkList">' + list + '</div>'
        : emptyBox('黑名单是空的', '在聊天信息里可以拉黑对方')),
      function () {}, '关闭');

    Array.prototype.forEach.call($('blkList') ? $('blkList').querySelectorAll('[data-unblock]') : [],
      function (b) {
        b.addEventListener('click', function () {
          var uid = Number(b.getAttribute('data-unblock'));
          api('block_remove', { uid: uid }, 'POST').then(function (r) {
            S.blocks = r.blocks || [];
            renderBlockCount();
            blockModal();
            toast('已移出黑名单', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      });
  }

  /* ---------------- 好友分组管理 ---------------- */
  function fgroupModal() {
    var body =
      '<div class="set-note" style="padding-top:0">分组只影响你自己这边的好友列表显示。</div>' +
      '<div class="card-row" style="margin-bottom:10px">' +
        '<input class="card-input" id="fgNew" maxlength="32" placeholder="新分组名称，例如「同事」">' +
        '<button class="btn-primary sm" id="fgAdd">新建</button>' +
      '</div>' +
      '<div id="fgList">' + fgroupRows() + '</div>';

    openModal('好友分组管理', body, function () {}, '关闭');
    bindFgroupRows();

    $('fgAdd').addEventListener('click', function () {
      var v = $('fgNew').value.trim();
      if (!v) { toast('请输入分组名称', 'err'); return; }
      api('group_friend_create', { name: v }, 'POST').then(function (r) {
        S.fgroups = r.groups || [];
        $('fgNew').value = '';
        $('fgList').innerHTML = fgroupRows();
        bindFgroupRows();
        renderContacts();
      }).catch(function (e) { toast(e.message, 'err'); });
    });
  }

  function fgroupRows() {
    var gs = S.fgroups || [];
    if (!gs.length) return emptyBox('还没有分组', '在上面输入名字新建一个');
    var mine = function (gid) {
      return (S.friends || []).filter(function (f) { return f.group_id === gid; }).length;
    };
    return gs.map(function (g) {
      return '<div class="sr-item">' +
        '<span style="flex:1"><input class="card-input" data-fgname="' + g.id + '" maxlength="32" value="' + esc(g.name) + '"></span>' +
        '<span class="muted" style="font-size:12px">' + mine(g.id) + ' 人</span>' +
        '<button class="btn-primary sm" data-fgsave="' + g.id + '">保存</button>' +
        '<button class="btn-danger sm" data-fgdel="' + g.id + '">删除</button>' +
        '</div>';
    }).join('');
  }

  function bindFgroupRows() {
    Array.prototype.forEach.call($('fgList').querySelectorAll('[data-fgsave]'), function (b) {
      b.addEventListener('click', function () {
        var gid = Number(b.getAttribute('data-fgsave'));
        var inp = $('fgList').querySelector('[data-fgname="' + gid + '"]');
        var v = inp.value.trim();
        if (!v) { toast('分组名称不能为空', 'err'); return; }
        api('group_friend_rename', { gid: gid, name: v }, 'POST').then(function (r) {
          S.fgroups = r.groups || [];
          $('fgList').innerHTML = fgroupRows();
          bindFgroupRows();
          renderContacts();
          toast('分组已重命名', 'ok');
        }).catch(function (e) { toast(e.message, 'err'); });
      });
    });
    Array.prototype.forEach.call($('fgList').querySelectorAll('[data-fgdel]'), function (b) {
      b.addEventListener('click', function () {
        var gid = Number(b.getAttribute('data-fgdel'));
        var g = (S.fgroups || []).filter(function (x) { return x.id === gid; })[0];
        var n = (S.friends || []).filter(function (f) { return f.group_id === gid; }).length;
        if (!confirm('删除分组「' + (g ? g.name : '') + '」？\n' +
                     (n ? '组里的 ' + n + ' 位好友会回到「未分组」，好友关系不会丢。' : '这个分组是空的。'))) return;
        api('group_friend_delete', { gid: gid }, 'POST').then(function (r) {
          S.fgroups = r.groups || [];
          S.friends = r.friends || S.friends;
          $('fgList').innerHTML = fgroupRows();
          bindFgroupRows();
          renderContacts();
          renderSide();
          toast('分组已删除', 'ok');
        }).catch(function (e) { toast(e.message, 'err'); });
      });
    });
  }

  function moveFriendModal(uid) {
    var f = (S.friends || []).filter(function (x) { return x.id === uid; })[0];
    if (!f) { toast('对方已经不是你的好友了', 'err'); return; }
    var opts = [{ id: 0, name: '未分组' }].concat(S.fgroups || []);
    openModal('移动到分组',
      '<div class="muted" style="margin-bottom:10px">选择「' + esc(f.display) + '」要放进哪个分组。</div>' +
      '<div class="pick-list">' + opts.map(function (g, i) {
        return '<label class="pick"><input type="radio" name="fgm" value="' + g.id + '"' +
               (g.id === f.group_id ? ' checked' : (i === 0 && !f.group_id ? ' checked' : '')) +
               '><span>' + esc(g.name) + '</span></label>';
      }).join('') + '</div>',
      function () {
        var sel = $('modalBody').querySelector('input:checked');
        var gid = sel ? Number(sel.value) : 0;
        api('group_friend_move', { uid: uid, gid: gid }, 'POST').then(function (r) {
          S.friends = r.friends || S.friends;
          S.fgroups = r.groups || S.fgroups;
          S.fgOpen[f.group_id] = false;
          S.fgOpen[gid] = true;
          closeModal();
          renderContacts();
          renderSide();
          toast('已移动', 'ok');
        }).catch(function (e) { toast(e.message, 'err'); });
      }, '移动');
  }

  /* ---------------- 聊天记录搜索 ---------------- */
  function searchMsgModal() {
    var c = S.cur;
    if (!c) { toast('请先打开一个会话', 'err'); return; }
    var kw = '';
    openModal('聊天记录',
      '<div class="search" style="margin-top:0"><svg viewBox="0 0 24 24"><path d="M10 4a6 6 0 104.2 10.3l4.5 4.5 1.4-1.4-4.5-4.5A6 6 0 0010 4zm0 2a4 4 0 110 8 4 4 0 010-8z"/></svg>' +
      '<input type="text" id="srKw" placeholder="在本会话里搜索"></div>' +
      '<div id="srOut" style="margin-top:10px"><div class="muted" style="padding:8px 2px">输入关键词开始搜索，只搜索当前会话。</div></div>',
      function () {}, '关闭');

    var box = $('srKw');
    function run() {
      kw = box.value.trim();
      if (!kw) { $('srOut').innerHTML = '<div class="muted" style="padding:8px 2px">输入关键词开始搜索，只搜索当前会话。</div>'; return; }
      $('srOut').innerHTML = '<div class="muted" style="padding:8px 2px">搜索中…</div>';
      api('search_messages', { cid: c.id, kw: kw }).then(function (r) {
        var list = r.results || [];
        if (!list.length) {
          $('srOut').innerHTML = emptyBox('没有找到', '换个关键词试试');
          return;
        }
        $('srOut').innerHTML =
          '<div class="muted" style="padding:4px 2px 6px;font-size:11.5px">找到 ' + list.length + ' 条，点一下跳到那条消息</div>' +
          list.map(function (m) {
            var hit = esc(m.content).split(esc(kw)).join('<span class="sr-hit">' + esc(kw) + '</span>');
            var who = m.sender === S.me.id ? '我' : esc(m.nickname || '');
            return '<div class="sr-item" data-jump="' + m.id + '">' +
              '<div class="sr-main"><div class="c-top"><span class="c-name" style="font-size:12.5px">' + who + '</span>' +
              '<span class="c-prev">' + hit + '</span></div>' +
              '<div class="c-bot"><span class="c-prev">' + esc(fullTime(m.time)) + '</span></div></div>' +
              '<span class="sr-time">跳转</span></div>';
          }).join('');
        Array.prototype.forEach.call($('srOut').querySelectorAll('[data-jump]'), function (it) {
          it.addEventListener('click', function () {
            var mid = Number(it.getAttribute('data-jump'));
            closeModal();
            jumpToMessage(mid);
          });
        });
      }).catch(function (e) {
        $('srOut').innerHTML = '<div class="muted" style="padding:8px 2px">' + esc(e.message) + '</div>';
      });
    }
    box.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); run(); } });
    box.addEventListener('input', function () { if (box.value.trim()) run(); });
    run();
  }

  /** 跳到指定消息：先往历史里翻到它，再高亮 */
  function jumpToMessage(mid) {
    var cid = S.cid;
    function tryScroll() {
      var el = $('msgList').querySelector('.msg[data-mid="' + mid + '"]');
      if (!el) return false;
      el.scrollIntoView({ block: 'center' });
      el.classList.add('flash');
      setTimeout(function () { el.classList.remove('flash'); }, 1800);
      return true;
    }
    if (tryScroll()) return;

    // 往上翻历史，每翻一页再找一次，最多 15 页，还找不到就老实说
    var tries = 0;
    (function load() {
      if (tries++ > 15 || S.noMore[cid] || !S.oldest[cid]) {
        toast('这条消息比较早，往上多翻一点就能看到', 'err');
        return;
      }
      loadHistory(cid, S.oldest[cid]).then(function () {
        if (tryScroll()) return;
        load();
      }).catch(function (e) { toast(e.message, 'err'); });
    })();
  }

  /** 从联系人面板直接开聊：已有会话就打开，没有就调 open_conv 建一个 */
  function openChatWith(uid) {
    var cid = findConvId(uid);
    if (cid) { openConv(cid); return; }
    api('open_conv', { uid: uid }, 'POST').then(function (r) {
      S.convs = r.conversations || S.convs;
      openConv(r.cid);
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  /** 好友资料卡（联系人面板用，不打扰会话） */
  function friendCard(uid) {
    var f = (S.friends || []).filter(function (x) { return x.id === uid; })[0];
    if (!f) { toast('对方不是你的好友', 'err'); return; }
    var g = (S.fgroups || []).filter(function (x) { return x.id === f.group_id; })[0];
    openModal('好友资料',
      '<div style="display:flex;gap:12px;align-items:center;margin-bottom:14px">' +
        avaHtml(f, 'rnd') +
        '<div><div style="font-size:15px;font-weight:600">' + esc(f.display) + '</div>' +
        '<div class="muted">账号：' + esc(f.username) + '</div>' +
        (f.remark ? '<div class="muted">备注名：' + esc(f.remark) + '</div>' : '') +
        (g ? '<div class="muted">分组：' + esc(g.name) + '</div>' : '') + '</div></div>' +
      '<div class="muted" style="margin-bottom:10px">个性签名：' + esc(f.signature || '（未填写）') + '</div>' +
      '<div class="muted" style="margin-bottom:10px">状态：' +
        (S.online[f.id] ? '当前在线' : lastSeenTitle(f.last_seen)) + '</div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
        '<button class="btn-primary sm" id="fcMsg">发消息</button>' +
        '<button class="btn-ghost sm" id="fcMove">移动分组</button>' +
        '<button class="btn-ghost sm" id="fcBlock">加入黑名单</button>' +
        '<button class="btn-danger sm" id="fcDel">删除好友</button>' +
      '</div>',
      function () {}, '关闭');

    $('fcMsg').addEventListener('click', function () { closeModal(); openChatWith(uid); });
    $('fcMove').addEventListener('click', function () { moveFriendModal(uid); });
    $('fcBlock').addEventListener('click', function () {
      if (!confirm('把「' + f.display + '」加入黑名单？\n\n之后你们不能再互发消息，好友关系会自动解除。')) return;
      api('block_add', { uid: uid }, 'POST').then(function (r) {
        S.blocks = r.blocks || [];
        S.convs = r.conversations || S.convs;
        S.friends = S.friends.filter(function (x) { return x.id !== uid; });
        renderBlockCount(); renderContacts(); renderSide();
        closeModal();
        toast('已加入黑名单', 'ok');
      }).catch(function (e) { toast(e.message, 'err'); });
    });
    $('fcDel').addEventListener('click', function () { closeModal(); delFriend(uid, f.display); });
  }

  function doSearch(kw) {
    kw = String(kw || '').trim();
    if (!kw) { toast('请输入搜索关键词', 'err'); return; }
    var out = $('searchOut');
    if (!out) return;
    out.innerHTML = '<div class="muted" style="padding:8px 2px">搜索中…</div>';
    api('search', { kw: kw }).then(function (r) {
      if (!r.users.length) { out.innerHTML = emptyBox('没有找到用户', '换个关键词试试'); return; }
      out.innerHTML = r.users.map(function (u) {
        var act;
        if (u.friend_status === 1) act = '<span class="pill ok">已是好友</span>';
        else if (u.incoming && u.friend_status === 0) act = '<button class="btn-primary sm" data-acc="' + u.id + '">接受</button>';
        else if (u.friend_status === 0) act = '<span class="pill warn">等待通过</span>';
        else act = '<button class="btn-ghost sm" data-add="' + u.id + '">加好友</button>';
        return '<div class="search-result">' + avaHtml(u, 'sm rnd') +
          '<i class="presence' + (u.online ? ' on' : '') + '"></i>' +
          '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(u.nickname) + '</span></div>' +
          '<div class="c-bot"><span class="c-prev">' + esc(u.username) + ' · ' +
          lastSeenHtml(u.last_seen, u.online) + '</span></div></div>' +
          act + '</div>';
      }).join('');
    }).catch(function (e) {
      out.innerHTML = '<div class="muted" style="padding:8px 2px">' + esc(e.message) + '</div>';
    });
  }

  function refreshContacts(data) {
    if (data.friends) S.friends = data.friends;
    if (data.requests) S.requests = data.requests;
    if (data.conversations) S.convs = data.conversations;
    if (data.online) data.online.forEach(function (o) { S.online[o.id] = !!o.online; });
    renderSide();
    if (S.view === 'contacts') renderContacts();
  }

  /* =========================================================
   *  弹窗
   * ======================================================= */
  var modalOk = null;
  function openModal(title, bodyHtml, onOk, okText) {
    $('modalTitle').textContent = title;
    $('modalBody').innerHTML = bodyHtml;
    $('modalOk').textContent = okText || '确定';
    $('modal').classList.remove('hidden');
    modalOk = onOk || null;
    var first = $('modalBody').querySelector('input,textarea,select');
    if (first) setTimeout(function () { first.focus(); }, 30);
  }
  function closeModal() { $('modal').classList.add('hidden'); modalOk = null; }

  $('modalX').addEventListener('click', closeModal);
  $('modalCancel').addEventListener('click', closeModal);
  $('modal').querySelector('.modal-mask').addEventListener('click', closeModal);
  $('modalOk').addEventListener('click', function () {
    if (modalOk) modalOk();
    else closeModal();
  });

  function convInfo(cid) {
    var c = convById(cid);
    if (!c) return;
    if (c.type === 'group') { groupInfo(cid); return; }
    var p = peerOf(c) || {};
    var body =
      '<div style="display:flex;gap:12px;align-items:center;margin-bottom:14px">' +
        avaHtml({ id: p.id, display: p.display || p.nickname, avatar: p.avatar }, 'rnd') +
        '<div><div style="font-size:15px;font-weight:600">' + esc(p.display || '') + '</div>' +
        '<div class="muted">账号：' + esc(p.username || '') + '</div></div></div>' +
      '<div class="muted" style="margin-bottom:10px">个性签名：' + esc(p.signature || '（未填写）') + '</div>' +
      '<div class="muted" style="margin-bottom:10px">状态：' + lastSeenHtml(p.last_seen, S.online[p.id]) + '</div>' +
      '<label>备注名<input type="text" id="remarkIn" maxlength="32" value="' + esc(p.remark || '') + '" placeholder="仅自己可见"></label>' +
      '<div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">' +
        '<button class="btn-primary sm" id="btnSaveRemark">保存备注</button>' +
        '<button class="btn-ghost sm" id="btnBlock">' + (p.blocked ? '移出黑名单' : '加入黑名单') + '</button>' +
        '<button class="btn-danger sm" id="btnDelFriend">删除好友</button>' +
      '</div>';

    openModal('聊天信息', body, function () {}, '关闭');

    $('btnBlock').addEventListener('click', function () {
      var on = !p.blocked;
      if (on && !confirm('把「' + (p.display || '') + '」加入黑名单？\n\n之后你们不能再互发消息，好友关系会自动解除。')) return;
      api(on ? 'block_add' : 'block_remove', { uid: p.id }, 'POST').then(function (r) {
        S.blocks = r.blocks || [];
        renderBlockCount();
        if (on) { S.friends = S.friends.filter(function (f) { return f.id !== p.id; }); renderSide(); }
        closeModal();
        toast(on ? '已加入黑名单' : '已移出黑名单', 'ok');
      }).catch(function (e) { toast(e.message, 'err'); });
    });

    $('btnSaveRemark').addEventListener('click', function () {
      var v = $('remarkIn').value;
      api('friend_remark', { uid: p.id, remark: v }, 'POST').then(function (r) {
        refreshContacts(r);
        renderMain();
        closeModal();
        toast('备注已保存', 'ok');
      }).catch(function (e) { toast(e.message, 'err'); });
    });
    $('btnDelFriend').addEventListener('click', function () {
      if (!confirm('确定删除好友「' + (p.display || '') + '」？聊天记录会保留。')) return;
      api('friend_remove', { uid: p.id }, 'POST').then(function (r) {
        refreshContacts(r);
        closeModal();
        toast('已删除好友');
      }).catch(function (e) { toast(e.message, 'err'); });
    });
  }

  function groupInfo(cid) {
    api('group_info', { cid: cid }).then(function (r) {
      S.members[cid] = r.members;
      var g = r.group;
      var c = convById(cid) || { title: '群聊' };
      var me = S.me.id;

      var noticeHtml = g.announcement
        ? '<div class="gnotice">' + esc(g.announcement) + '</div>'
        : '<div class="muted" style="margin-bottom:12px">暂无群公告</div>';

      // 群主 / 管理员的可操作项由服务端 can_manage 决定
      var can = g.can_manage || {};

      // 入群申请：只有能审批的人才看得到（普通成员服务端根本不给这个字段）
      var reqs = g.requests || [];
      var reqHtml = '';
      if (can.approve) {
        reqHtml = '<div class="gsec"><div class="gsec-hd"><span>入群申请（' +
          reqs.length + '）</span></div>' +
          (reqs.length
            ? '<div class="pick-list" id="gReqs">' + reqs.map(function (q) {
                var why = q.reason ? '<span class="gno-tip">申请理由：' + esc(q.reason) + '</span>' : '';
                return '<div class="pick" data-req="' + q.req_id + '">' + avaHtml(q, '') +
                  '<div class="c-main"><div class="c-top"><span class="c-name">' +
                    esc(q.display || q.nickname) + '</span></div>' +
                  '<div class="c-bot"><span class="c-prev">' +
                    esc(fullTime(q.time)) + '</span>' + why + '</div></div>' +
                  '<div class="gacts">' +
                    '<button class="btn-primary sm" data-reqok="' + q.req_id + '">同意</button>' +
                    '<button class="btn-ghost sm" data-reqno="' + q.req_id + '">拒绝</button>' +
                  '</div></div>';
              }).join('') + '</div>'
            : '<div class="muted">暂无待处理的入群申请</div>') +
          '</div>';
      }

      var rows = r.members.map(function (m) {
        var mine = m.id === me;
        var roleTag = m.group_role === 'owner' ? ' <span class="pill owner">群主</span>'
                   : m.group_role === 'admin' ? ' <span class="pill blue">管理员</span>' : '';
        var mutedTag = m.mute_until
          ? ' <span class="pill warn">禁言至 ' + esc(timeText(m.mute_until)) + '</span>' : '';

        var acts = '';
        if (g.is_manager && !mine && m.group_role === 'member') {
          acts =
            '<button class="gmute' + (m.mute_until ? ' on' : '') + '" data-mute="' + m.id + '">' +
              (m.mute_until ? '解除禁言' : '禁言') + '</button>';
        }
        if (g.is_owner && !mine) {
          acts += '<button class="linkbtn" data-admin="' + m.id + '">' +
                  (m.group_role === 'admin' ? '取消管理员' : '设为管理员') + '</button>';
          acts += '<button class="linkbtn" data-transfer="' + m.id + '">转让</button>';
        }
        if (can.kick && !mine && m.group_role !== 'owner' &&
            !(g.is_admin && m.group_role === 'admin')) {
          acts += '<button class="linkbtn danger" data-kick="' + m.id + '">踢出</button>';
        }

        // 自己的那行放群名片输入框
        var main;
        if (mine) {
          main = '<div class="card-row" style="margin-top:2px">' +
            '<input class="card-input" id="myCard" maxlength="32" placeholder="设置群内昵称" value="' + esc(m.card || '') + '">' +
            '<button class="btn-ghost sm" id="btnSaveCard">保存</button></div>' +
            '<div class="c-bot"><span class="c-prev">仅本群可见，留空则用昵称</span></div>';
        } else {
          main = '<div class="c-top"><span class="c-name">' + esc(m.display || m.nickname) + roleTag + mutedTag + '</span></div>' +
                 '<div class="c-bot"><span class="c-prev">' +
                 lastSeenHtml(m.last_seen, S.online[m.id]) +
                 (m.card ? ' · 群昵称：' + esc(m.card) : '') + '</span></div>';
        }

        return '<div class="pick" style="cursor:default">' + avaHtml(m, '') +
               '<div class="c-main">' + main + '</div>' +
               (acts ? '<div class="gacts">' + acts + '</div>' : '') +
               '</div>';
      }).join('');

      var body =
        '<div class="ghead">' +
          '<div id="gAvaBox" style="position:relative">' +
            avaHtml({ id: cid, display: g.title, avatar: g.avatar }, 'rnd lg') +
            (g.is_owner ? '<span class="gava-edit">换</span>' : '') +
          '</div>' +
          '<div><div style="font-size:15px;font-weight:600">' + esc(g.title) + '</div>' +
          '<div class="muted">' + g.member_count + ' 名成员' +
          (g.my_role === 'admin' ? ' · 你是管理员' : '') + '</div></div>' +
        '</div>' +
        '<div class="gsec"><div class="gsec-hd"><span>群号</span>' +
          '<button class="btn-ghost sm" id="btnCopyGno" data-gno="' + esc(g.gno || '') + '">复制</button>' +
        '</div>' +
          '<div class="gno-box"><span class="gno-val">' + esc(g.gno || '未生成') + '</span>' +
          '<span class="gno-tip">在「搜群号加群」里输入这个号码就能找到本群</span></div>' +
        '</div>' +
        (reqHtml) +
        '<div class="gsec"><div class="gsec-hd"><span>群公告</span>' +
          (can.notice ? '<button class="btn-ghost sm" id="btnNotice">编辑</button>' : '') +
        '</div>' + noticeHtml + '</div>' +
        '<div class="gsec"><div class="gsec-hd"><span>群成员（' + g.member_count + '）</span>' +
          (g.all_muted ? '<span class="pill warn">全员禁言中</span>' : '') + '</div>' +
        '<div class="pick-list" id="gMembers">' + rows + '</div></div>' +
        '<div class="gbtns">' +
          '<button class="btn-primary sm" id="btnInvite">邀请好友</button>' +
          (can.rename ? '<button class="btn-ghost sm" id="btnRename">修改群名</button>' : '') +
          (can.all_muted
            ? '<button class="btn-ghost sm" id="btnAllMute">' +
              (g.all_muted ? '关闭全员禁言' : '开启全员禁言') + '</button>' : '') +
          (can.disband
            ? '<button class="btn-danger sm" id="btnDisband">解散群聊</button>'
            : (can.leave ? '<button class="btn-danger sm" id="btnLeave">退出群聊</button>' : '')) +
        '</div>';

      openModal('群聊信息', body, function () {}, '关闭');

      /* ---- 复制群号 ---- */
      var btnGno = $('btnCopyGno');
      if (btnGno) {
        btnGno.addEventListener('click', function () {
          var gno = this.getAttribute('data-gno');
          if (!gno) { toast('本群还没有群号', 'err'); return; }
          copyText(gno);
        });
      }

      /* ---- 入群申请：通过 / 拒绝 ---- */
      function handleReq(rid, accept) {
        api('group_request_handle', { rid: rid, accept: accept ? 1 : 0 }, 'POST')
          .then(function (rr) {
            S.grequests = rr.grequests || S.grequests;
            S.convs = rr.conversations || S.convs;
            groupInfo(cid);
            renderSide();
            toast(accept ? '已同意入群' : '已拒绝入群', 'ok');
          })
          .catch(function (e) { toast(e.message, 'err'); });
      }
      var box2 = $('gReqs');
      if (box2) {
        box2.addEventListener('click', function (e) {
          var ok = e.target.closest('[data-reqok]');
          var no = e.target.closest('[data-reqno]');
          if (ok) handleReq(parseInt(ok.getAttribute('data-reqok'), 10), true);
          else if (no) handleReq(parseInt(no.getAttribute('data-reqno'), 10), false);
        });
      }

      /* ---- 群名片（改自己的） ---- */
      var btnCard = $('btnSaveCard');
      if (btnCard) {
        btnCard.addEventListener('click', function () {
          var v = $('myCard').value.trim();
          api('group_card', { cid: cid, card: v }, 'POST').then(function () {
            groupInfo(cid);
            toast(v ? '群昵称已更新为「' + v + '」' : '群昵称已清除', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      }

      /* ---- 群头像 ---- */
      if (g.is_owner) {
        $('gAvaBox').addEventListener('click', function () { $('gAvaFile').click(); });
      }
      $('gAvaFile').onchange = function () {
        var f = this.files && this.files[0];
        if (!f) return;
        var fd = new FormData();
        fd.append('file', f);
        fd.append('kind', 'image');
        api('upload', fd, 'POST').then(function (up) {
          return api('group_avatar', { cid: cid, path: up.path }, 'POST');
        }).then(function (rr) {
          S.convs = rr.conversations || S.convs;
          groupInfo(cid);
          renderSide();
          renderMain();
          toast('群头像已更新', 'ok');
        }).catch(function (e) { toast(e.message, 'err'); });
        this.value = '';
      };

      /* ---- 全员禁言 ---- */
      var btnAll = $('btnAllMute');
      if (btnAll) {
        btnAll.addEventListener('click', function () {
          var on = !g.all_muted;
          if (on && !confirm('开启后，除了群主和管理员，其他人都不能发言。\n确定开启全员禁言吗？')) return;
          api('group_all_mute', { cid: cid, on: on ? 1 : 0 }, 'POST').then(function (rr) {
            S.convs = rr.conversations || S.convs;
            groupInfo(cid);
            renderMain();
            toast(on ? '已开启全员禁言' : '已关闭全员禁言', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      }

      /* ---- 禁言 / 解除禁言 ---- */
      Array.prototype.forEach.call($('gMembers').querySelectorAll('[data-mute]'), function (b) {
        b.addEventListener('click', function () {
          var tid = Number(b.getAttribute('data-mute'));
          var m = r.members.filter(function (x) { return x.id === tid; })[0];
          if (!m) return;
          if (m.mute_until) {
            if (!confirm('解除对「' + m.display + '」的禁言？')) return;
            doMute(cid, tid, 0);
            return;
          }
          mutePicker(cid, m);
        });
      });

      /* ---- 设为 / 取消管理员 ---- */
      Array.prototype.forEach.call($('gMembers').querySelectorAll('[data-admin]'), function (b) {
        b.addEventListener('click', function () {
          var tid = Number(b.getAttribute('data-admin'));
          var m = r.members.filter(function (x) { return x.id === tid; })[0];
          if (!m) return;
          var on = m.group_role !== 'admin';
          if (!confirm(on
            ? '把「' + m.display + '」设为管理员？\n管理员可以踢人、禁言、拉人，不能改群名和公告。'
            : '取消「' + m.display + '」的管理员身份？')) return;
          api('group_set_admin', { cid: cid, uid: tid, on: on ? 1 : 0 }, 'POST').then(function () {
            groupInfo(cid);
            toast(on ? '已设为管理员' : '已取消管理员', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      });
          /* ---- 群公告 ---- */
      if (can.notice) {
        $('btnNotice').addEventListener('click', function () {
          openModal('编辑群公告',
            '<label>群公告<input type="text" id="gNotice" maxlength="200" value="' + esc(g.announcement) + '" placeholder="写点什么，所有群成员都能看到"></label>',
            function () {
              var txt = $('gNotice').value.trim();
              api('group_notice', { cid: cid, text: txt }, 'POST').then(function (rr) {
                S.convs = rr.conversations || S.convs;
                closeModal();
                groupInfo(cid);
                renderMain();
                toast(txt ? '群公告已更新' : '群公告已清除', 'ok');
              }).catch(function (e) { toast(e.message, 'err'); });
            }, '保存');
        });
      }

      /* ---- 修改群名 ---- */
      if (g.is_owner) {
        $('btnRename').addEventListener('click', function () {
          openModal('修改群名称',
            '<label>群名称<input type="text" id="gName2" maxlength="32" value="' + esc(g.title) + '"></label>',
            function () {
              var v = $('gName2').value.trim();
              if (!v) { toast('群名称不能为空', 'err'); return; }
              api('group_rename', { cid: cid, title: v }, 'POST').then(function (rr) {
                S.convs = rr.conversations || S.convs;
                closeModal();
                groupInfo(cid);
                renderSide();
                renderMain();
                toast('群名称已修改', 'ok');
              }).catch(function (e) { toast(e.message, 'err'); });
            }, '保存');
        });
      }

      /* ---- 转让 / 踢出 ---- */
      Array.prototype.forEach.call($('gMembers').querySelectorAll('[data-transfer]'), function (b) {
        b.addEventListener('click', function () {
          var tid = b.getAttribute('data-transfer');
          var who = r.members.filter(function (m) { return String(m.id) === tid; })[0];
          if (!confirm('确定把群主转让给「' + (who ? (who.display || who.nickname) : '') + '」吗？转让后你将变成普通成员。')) return;
          api('group_transfer', { cid: cid, uid: tid }, 'POST').then(function () {
            groupInfo(cid);
            toast('已转让群主', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      });
      Array.prototype.forEach.call($('gMembers').querySelectorAll('[data-kick]'), function (b) {
        b.addEventListener('click', function () {
          var tid = b.getAttribute('data-kick');
          var who = r.members.filter(function (m) { return String(m.id) === tid; })[0];
          var nm = who ? (who.display || who.nickname) : '';
          if (!confirm('确定把「' + nm + '」移出群聊吗？\n对方会看到一条系统提示，并且无法再发消息。')) return;
          api('group_kick', { cid: cid, uid: tid }, 'POST').then(function () {
            groupInfo(cid);
            toast('已移出群聊', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      });

      /* ---- 退出 / 解散 ---- */
      var btnLeave = $('btnLeave');
      if (btnLeave) {
        btnLeave.addEventListener('click', function () {
          if (!confirm('确定退出群聊「' + g.title + '」吗？')) return;
          api('group_leave', { cid: cid }, 'POST').then(function (rr) {
            S.convs = rr.conversations || [];
            delete S.msgs[cid];
            closeModal();
            S.cid = 0;
            renderSide();
            renderMain();
            toast('已退出群聊', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      }
      var btnDisband = $('btnDisband');
      if (btnDisband) {
        btnDisband.addEventListener('click', function () {
          if (!confirm('解散后所有成员都会被移出群聊，且无法恢复。确定解散「' + g.title + '」吗？')) return;
          api('group_disband', { cid: cid }, 'POST').then(function (rr) {
            S.convs = rr.conversations || [];
            delete S.msgs[cid];
            closeModal();
            S.cid = 0;
            renderSide();
            renderMain();
            toast('群聊已解散', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        });
      }

      /* ---- 邀请好友 ---- */
      $('btnInvite').addEventListener('click', function () {
        openInvite(cid);
      });
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  /** 拉人进群：勾选好友加入当前群（聊天信息里的按钮和顶栏的「拉人」都走这里） */
  function openInvite(cid) {
    var c = convById(cid);
    if (!c || c.type !== 'group') { toast('只有群聊才能拉人', 'err'); return; }
    api('group_members', { cid: cid }, 'GET').then(function (r) {
      var members = r.members || [];
      var inGroup = {};
      members.forEach(function (m) { inGroup[m.id] = 1; });
      var cand = S.friends.filter(function (f) { return !inGroup[f.id] && f.friend_status === 1; });
      if (!cand.length) { toast('你的好友都已在群中', 'err'); return; }
      openModal('邀请好友（' + members.length + '/' + (r.member_count || members.length) + '）',
        '<div class="muted" style="margin-bottom:8px">勾选要邀请的好友</div>' +
        '<div class="pick-list">' + cand.map(function (f) {
          return '<label class="pick"><input type="checkbox" value="' + f.id + '">' + avaHtml(f, '') +
                 '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(f.display) + '</span></div></div></label>';
        }).join('') + '</div>',
        function () {
          var ids = [].slice.call($('modalBody').querySelectorAll('input:checked')).map(function (i) { return i.value; });
          if (!ids.length) { toast('请选择要邀请的好友', 'err'); return; }
          Promise.all(ids.map(function (id) {
            return api('group_add', { cid: cid, uid: id }, 'POST');
          })).then(function () {
            closeModal();
            groupInfo(cid);
            toast('已邀请 ' + ids.length + ' 位好友', 'ok');
          }).catch(function (e) { toast(e.message, 'err'); });
        }, '加入群聊');
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  /** 禁言时长选择。minutes = 0 表示解除禁言 */
  function mutePicker(cid, member) {
    var opts = [
      { m: 10,    t: '10 分钟' },
      { m: 60,    t: '1 小时' },
      { m: 360,   t: '6 小时' },
      { m: 1440,  t: '1 天' },
      { m: 10080, t: '7 天' }
    ];
    var nm = member.display || member.nickname;
    openModal('禁言「' + nm + '」',
      '<div class="muted" style="margin-bottom:10px">选择禁言时长，被禁言期间对方不能发言，管理员和群主不受影响。</div>' +
      '<div class="pick-list" id="mutePick">' + opts.map(function (o, i) {
        return '<label class="pick"><input type="radio" name="mm" value="' + o.m + '"' +
               (i === 1 ? ' checked' : '') + '><span>' + o.t + '</span></label>';
      }).join('') + '</div>',
      function () {
        var sel = $('mutePick').querySelector('input:checked');
        if (!sel) { toast('请选择时长', 'err'); return; }
        doMute(cid, member.id, Number(sel.value));
      }, '禁言');
  }

  function doMute(cid, uid, minutes) {
    return api('group_mute', { cid: cid, uid: uid, minutes: minutes }, 'POST').then(function (rr) {
      S.members[cid] = rr.members || S.members[cid];
      if (uid === S.me.id) {
        applyLock(rr.group && rr.group.send_lock ? rr.group.send_lock : '');
      }
      groupInfo(cid);
      renderMain();
      toast(minutes === 0 ? '已解除禁言' : '已禁言 ' + minutes + ' 分钟', 'ok');
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  function addFriendModal() {
    openModal('添加好友', '<div class="search" style="margin-top:0"><svg viewBox="0 0 24 24"><path d="M10 4a6 6 0 104.2 10.3l4.5 4.5 1.4-1.4-4.5-4.5A6 6 0 0010 4zm0 2a4 4 0 110 8 4 4 0 010-8z"/></svg>' +
      '<input type="text" id="mKw" placeholder="账号或昵称"></div>' +
      '<div id="mOut" style="margin-top:10px"></div>', function () {}, '关闭');

    var kw = $('mKw');
    kw.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); mSearch(kw.value); }
    });
    function mSearch(v) {
      v = String(v || '').trim();
      if (!v) return;
      var out = $('mOut');
      out.innerHTML = '<div class="muted">搜索中…</div>';
      api('search', { kw: v }).then(function (r) {
        if (!r.users.length) { out.innerHTML = emptyBox('没有找到用户'); return; }
        out.innerHTML = r.users.map(function (u) {
          var act = u.friend_status === 1 ? '<span class="pill ok">已是好友</span>'
            : u.incoming ? '<button class="btn-primary sm" data-acc2="' + u.id + '">接受</button>'
            : u.friend_status === 0 ? '<span class="pill warn">等待通过</span>'
            : '<button class="btn-ghost sm" data-add2="' + u.id + '">加好友</button>';
          return '<div class="search-result">' + avaHtml(u, 'sm rnd') +
            '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(u.nickname) + '</span></div>' +
            '<div class="c-bot"><span class="c-prev">' + esc(u.username) + '</span></div></div>' + act + '</div>';
        }).join('');
      });
    }
  }

  function createGroupModal() {
    var friends = S.friends.filter(function (f) { return f.friend_status === 1; });
    if (!friends.length) { toast('先添加好友再建群', 'err'); return; }
    openModal('创建群聊',
      '<label>群名称' +
        '<input type="text" id="gName" maxlength="32" placeholder="例如：项目讨论组">' +
      '</label>' +
      '<div class="gsec" style="margin:16px 0 8px">' +
        '<div class="gsec-hd"><span>选择成员（' + friends.length + ' 位好友）</span>' +
          '<span><button class="linkbtn" id="gAll">全选</button>' +
          '<button class="linkbtn" id="gNone">清空</button>' +
          '<span class="muted" id="gCount">已选 0 人</span></span>' +
        '</div>' +
        '<div class="pick-list" id="gPick">' + friends.map(function (f) {
          return '<label class="pick"><input type="checkbox" value="' + f.id + '">' + avaHtml(f, '') +
                 '<div class="c-main"><div class="c-top"><span class="c-name">' + esc(f.display) + '</span></div></div></label>';
        }).join('') + '</div>' +
      '</div>',
      function () {
        var name = $('gName').value.trim();
        if (!name) { toast('请填写群名称', 'err'); return; }
        var ids = [].slice.call($('modalBody').querySelectorAll('#gPick input:checked')).map(function (i) { return i.value; });
        api('group_create', { title: name, members: ids }, 'POST').then(function (r) {
          S.convs = r.conversations || S.convs;
          closeModal();
          setListTab('convs');
          openConv(r.cid);
          toast('群聊已创建' + (ids.length ? '，已邀请 ' + ids.length + ' 位好友' : ''), 'ok');
        }).catch(function (e) { toast(e.message, 'err'); });
      }, '创建');

    // 全选 / 清空 / 实时人数
    function syncCount() {
      var n = $('gPick').querySelectorAll('input:checked').length;
      $('gCount').textContent = '已选 ' + n + ' 人';
    }
    $('gPick').addEventListener('change', syncCount);
    $('gAll').addEventListener('click', function () {
      $('gPick').querySelectorAll('input').forEach(function (i) { i.checked = true; });
      syncCount();
    });
    $('gNone').addEventListener('click', function () {
      $('gPick').querySelectorAll('input').forEach(function (i) { i.checked = false; });
      syncCount();
    });
  }

  /* =========================================================
   *  右键菜单
   * ======================================================= */
  function showCtx(x, y, items) {
    var m = $('ctxMenu');
    m.innerHTML = items.map(function (it) {
      return '<button class="ctx-item' + (it.danger ? ' danger' : '') + '" data-ctx="' + esc(it.key) + '"' +
             (it.disabled ? ' disabled' : '') + '><span>' + esc(it.label) + '</span>' +
             (it.hint ? '<span class="muted">' + esc(it.hint) + '</span>' : '') + '</button>';
    }).join('');
    m.classList.remove('hidden');
    var w = m.offsetWidth, h = m.offsetHeight;
    m.style.left = Math.min(x, window.innerWidth - w - 8) + 'px';
    m.style.top = Math.min(y, window.innerHeight - h - 8) + 'px';
    m.onclick = function (e) {
      var b = e.target.closest('[data-ctx]');
      if (!b || b.disabled) return;
      var key = b.getAttribute('data-ctx');
      m.classList.add('hidden');
      var fn = items.filter(function (i) { return i.key === key; })[0];
      if (fn && fn.run) fn.run();
    };
  }
  document.addEventListener('click', function () { $('ctxMenu').classList.add('hidden'); });
  document.addEventListener('contextmenu', function (e) {
    var conv = e.target.closest('.conv');
    if (!conv) return;
    e.preventDefault();
    var cid = Number(conv.getAttribute('data-cid'));
    var c = convById(cid);
    if (!c) return;
    var items = [
      { key: 'info', label: c.type === 'group' ? '群聊信息' : '聊天信息', run: function () { convInfo(cid); } },
      { key: 'mute', label: c.muted ? '开启消息提醒' : '消息免打扰', run: function () { toggleMute(cid); } },
      { key: 'read', label: '标记为已读', run: function () { markRead(cid); } }
    ];
    if (c.type === 'single' && c.peer) {
      items.push({ key: 'del', label: '删除好友', danger: true, run: function () { delFriend(c.peer.id, c.peer.display); } });
    }
    if (c.type === 'group') {
      var isOwner = (c.owner_id || 0) === S.me.id;
      if (isOwner) {
        items.push({ key: 'notice', label: c.announcement ? '修改群公告' : '发布群公告', run: function () { groupInfo(cid); setTimeout(function () { $('btnNotice') && $('btnNotice').click(); }, 260); } });
      }
      items.push({
        key: 'leave', label: isOwner ? '解散群聊' : '退出群聊', danger: true,
        run: function () { groupInfo(cid); setTimeout(function () { var b = isOwner ? $('btnDisband') : $('btnLeave'); b && b.click(); }, 260); }
      });
    }
    showCtx(e.clientX, e.clientY, items);
  });

  function toggleMute(cid) {
    var c = convById(cid);
    api('mute', { cid: cid, mute: c && c.muted ? 0 : 1 }, 'POST').then(function (r) {
      S.convs = r.conversations || S.convs;
      renderSide(); renderMain();
      toast(c && c.muted ? '已开启消息提醒' : '已设置消息免打扰', 'ok');
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  function delFriend(uid, name) {
    var f = (S.friends || []).filter(function (x) { return x.id === uid; })[0];
    var nm = name || (f ? f.display : '该好友');
    if (!confirm('确定删除好友「' + nm + '」？\n聊天记录会保留，以后重新加回好友还能接着聊。')) return;
    api('friend_remove', { uid: uid }, 'POST').then(function (r) {
      refreshContacts(r);
      toast('已删除好友');
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  /* =========================================================
   *  事件绑定
   * ======================================================= */

  // 左侧导航
  document.querySelectorAll('.rail-btn[data-view]').forEach(function (b) {
    b.addEventListener('click', function () { setView(b.getAttribute('data-view')); });
  });
  $('railAvatar').addEventListener('click', function () { setView('settings'); });

  // 手机端：聊天页左上角返回会话列表。
  // 直接摘 peek 就行 —— 别走 setView()，那会把整个列表重画一遍，
  // 而这里要的只是「把屏幕让回列表」这一件事。
  // 桌面上这个按钮是 display:none，但还是要绑：
  // 免得平板竖屏、桌面拖窄之类的窄窗口里按钮能看见却没反应。
  var mobBack = $('mobBack');
  if (mobBack) {
    mobBack.addEventListener('click', function () {
      document.body.classList.remove('peek');
    });
  }

  // 侧栏标签
  $('sideTabs').addEventListener('click', function (e) {
    var b = e.target.closest('button');
    if (!b) return;
    setListTab(b.getAttribute('data-list'));
    renderSide();
  });

  // 侧栏搜索
  $('sideSearch').addEventListener('input', function (e) {
    S.filter = e.target.value;
    renderSide();
  });

  // 会话 / 好友点击
  $('sideList').addEventListener('click', function (e) {
    var person = e.target.closest('.person');
    var cidEl = e.target.closest('[data-cid]');
    if (cidEl) {
      openConv(Number(cidEl.getAttribute('data-cid')));
      return;
    }
    if (person) {
      openChatWith(Number(person.getAttribute('data-uid')));
    }
  });

  // 顶栏：聊天记录搜索
  $('btnSearchMsg').addEventListener('click', searchMsgModal);
  // 联系人面板：好友分组管理
  $('btnManageGroups').addEventListener('click', fgroupModal);
  // 设置面板：黑名单管理
  $('btnBlocks').addEventListener('click', blockModal);

  // 收藏面板：回到会话 / 取消收藏
  $('favoritesBody').addEventListener('click', function (e) {
    var go = e.target.closest('[data-favgo]');
    var del = e.target.closest('[data-favdel]');
    if (go) {
      var cid = Number(go.getAttribute('data-favgo'));
      closeModal();
      if (cid) { setView('chat'); openConv(cid); }
    } else if (del) {
      toggleFav(Number(del.getAttribute('data-favdel')));
      renderFavs();
    }
  });

  /* =========================================================
   *  外观设置（存在本机浏览器里）
   * ---------------------------------------------------------
   *  主题   hnim.theme  = sky | sakura
   *  明暗   hnim.scheme = auto | light | dark
   *  紧凑   hnim.compact = 1 | 0
   *
   *  dark 这个 class 挂在 <html> 上，不是 <body>。
   *  因为 <head> 里那段防闪白脚本要在 CSS 载入前就把深色定下来，
   *  那时候 <body> 还不存在，只能挂 <html>。
   *  （旧版挂在 body 上，主题色在第一帧之前完全生效不了。）
   *
   *  hnim.dark 是老版本的键。留着读一下，老用户升级后不会突然变白。
   * ======================================================= */
  var root = document.documentElement;

  function getScheme() {
    var s = localStorage.getItem('hnim.scheme');
    if (s === 'light' || s === 'dark' || s === 'auto') { return s; }
    /* 老版本只有 hnim.dark：1 = 深色，0 = 浅色 */
    var old = localStorage.getItem('hnim.dark');
    if (old === '1') { return 'dark'; }
    if (old === '0') { return 'light'; }
    return 'auto';
  }
  function getTheme() {
    var t = localStorage.getItem('hnim.theme');
    return (t === 'sky' || t === 'sakura') ? t : 'sky';
  }
  function systemDark() {
    return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme:dark)').matches);
  }
  /* auto 时深浅跟着系统走，所以系统一变就得重新算一次 */
  function schemeIsDark() {
    var s = getScheme();
    return s === 'dark' || (s === 'auto' && systemDark());
  }

  function applyScheme() {
    root.classList.toggle('dark', schemeIsDark());
    markSeg($('setScheme'), 'scheme', getScheme());
  }
  function applyTheme() {
    root.setAttribute('data-theme', getTheme());
    markSeg($('setTheme'), 'theme', getTheme());
  }

  /* 把选中态画到分段按钮上 */
  function markSeg(box, attr, val) {
    if (!box) { return; }
    var bs = box.querySelectorAll('.seg-b');
    for (var i = 0; i < bs.length; i++) {
      var on = bs[i].getAttribute('data-' + attr) === val;
      bs[i].classList.toggle('on', on);
      bs[i].setAttribute('aria-checked', on ? 'true' : 'false');
    }
  }

  function loadPrefs() {
    var compact = localStorage.getItem('hnim.compact') === '1';
    root.classList.toggle('compact', compact);
    applyTheme();
    applyScheme();
    var sc = $('setCompact');
    if (sc) { sc.checked = compact; }
  }

  var themeBox = $('setTheme');
  if (themeBox) {
    themeBox.addEventListener('click', function (e) {
      var b = e.target.closest('.seg-b');
      if (!b) { return; }
      var v = b.getAttribute('data-theme');
      if (v !== 'sky' && v !== 'sakura') { return; }
      try { localStorage.setItem('hnim.theme', v); } catch (err) {}
      applyTheme();
    });
  }
  var schemeBox = $('setScheme');
  if (schemeBox) {
    schemeBox.addEventListener('click', function (e) {
      var b = e.target.closest('.seg-b');
      if (!b) { return; }
      var v = b.getAttribute('data-scheme');
      if (v !== 'auto' && v !== 'light' && v !== 'dark') { return; }
      try { localStorage.setItem('hnim.scheme', v); } catch (err) {}
      applyScheme();
    });
    /* 用户在系统里改了深浅设置，正在用「跟随系统」的话这边要跟上 */
    if (window.matchMedia) {
      var mq = window.matchMedia('(prefers-color-scheme:dark)');
      var onMq = function () { if (getScheme() === 'auto') { applyScheme(); } };
      if (mq.addEventListener) { mq.addEventListener('change', onMq); }
      else if (mq.addListener) { mq.addListener(onMq); }   /* 老 Safari */
    }
  }
  var sc2 = $('setCompact');
  if (sc2) {
    sc2.addEventListener('change', function () {
      root.classList.toggle('compact', sc2.checked);
      try { localStorage.setItem('hnim.compact', sc2.checked ? '1' : '0'); } catch (e) {}
    });
  }

  // 消息区：下载 / 图片查看
  $('msgList').addEventListener('click', function (e) {
    var file = e.target.closest('.msg-file');
    if (file) { location.href = file.getAttribute('data-dl'); return; }
    var img = e.target.closest('.msg-img');
    if (img) { $('viewerImg').src = img.getAttribute('src'); $('viewer').classList.remove('hidden'); }
  });
  $('viewer').addEventListener('click', function () { $('viewer').classList.add('hidden'); });

  // 消息左键：点引用块跳到被引用的那条
  $('msgList').addEventListener('click', function (e) {
    var q = e.target.closest('.quote[data-jump]');
    if (!q) return;
    var target = Number(q.getAttribute('data-jump'));
    if (!target) return;
    var node = $('msgList').querySelector('.msg[data-mid="' + target + '"]');
    if (!node) { toast('被引用的消息不在当前已加载的记录里', 'err'); return; }
    node.scrollIntoView({ block: 'center', behavior: 'smooth' });
    node.classList.add('flash');
    setTimeout(function () { node.classList.remove('flash'); }, 1400);
  });

  // 消息右键：引用 / 收藏 / 撤回 / 复制
  $('msgList').addEventListener('contextmenu', function (e) {
    var el = e.target.closest('.msg[data-mid]');
    if (!el) return;
    var mid = Number(el.getAttribute('data-mid'));
    var m = (S.msgs[S.cid] || []).filter(function (x) { return x.id === mid; })[0];
    if (!m || m.type === 'system' || m.type === 'recalled') return;
    e.preventDefault();
    e.stopPropagation();

    var items = [];
    items.push({
      key: 'quote', label: '引用', hint: '回复这条',
      run: function () {
        setReply(m);
        $('input').focus();
        toast('已引用，发送后对方能看到原文');
      }
    });
    items.push({
      key: 'fav', label: isFavMsg(mid) ? '取消收藏' : '收藏',
      run: function () { toggleFav(mid); }
    });
    if (m.can_recall) {
      items.push({ key: 'recall', label: '撤回', run: function () { doRecall(mid); } });
    }
    if (m.type === 'text' && m.content) {
      items.push({
        key: 'copy', label: '复制文字',
        run: function () { copyText(m.content, '已复制'); }
      });
    }
    if (items.length) showCtx(e.clientX, e.clientY, items);
  });

  /** 统一的复制：优先剪贴板 API，失败退回老办法 */
  function copyText(text, okMsg) {
    var done = function () { toast(okMsg || '已复制', 'ok'); };
    if (!text) { toast('没有可复制的内容', 'err'); return; }
    if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, function () { legacyCopy(text, done); });
    } else {
      legacyCopy(text, done);
    }
  }

  function toggleFav(mid) {
    var on = isFavMsg(mid);
    api(on ? 'favorite_remove' : 'favorite_add', { mid: mid }, 'POST')
      .then(function (r) {
        S.favs = r.ids || [];
        renderMsgs(S.cid);
        updateFavBadge();
        toast(on ? '已取消收藏' : '已收藏，可在左下角「收藏」里查看', 'ok');
      })
      .catch(function (e) { toast(e.message, 'err'); });
  }

  function updateFavBadge() {
    var el = $('railFavCount');
    if (!el) return;
    var n = (S.favs || []).length;
    if (!n) { el.classList.add('hidden'); return; }
    el.classList.remove('hidden');
    el.textContent = n > 99 ? '99+' : String(n);
  }

  function legacyCopy(text, cb) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); cb(); } catch (err) { toast('复制失败', 'err'); }
    document.body.removeChild(ta);
  }

  function doRecall(mid) {
    api('recall', { id: mid }, 'POST').then(function (r) {
      S.msgs[S.cid] = r.messages || [];
      S.since = Math.max(S.since, mid);
      renderMsgs(S.cid);
      renderSide();
      toast('消息已撤回', 'ok');
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  // 加载更多历史
  $('btnMore').addEventListener('click', function () {
    var arr = S.msgs[S.cid] || [];
    if (!arr.length) return;
    loadHistory(S.cid, arr[0].id).then(function () {
      var box = $('msgScroll');
      var keep = box.scrollHeight;
      renderMsgs(S.cid);
      box.scrollTop = box.scrollHeight - keep;
    });
  });

  // 聊天头部
  $('btnInfo').addEventListener('click', function () { convInfo(S.cid); });
  $('btnMute').addEventListener('click', function () { toggleMute(S.cid); });
  var btnGF = $('btnGroupFiles');
  if (btnGF) {
    btnGF.addEventListener('click', function () {
      var c = convById(S.cid);
      if (!c || c.type !== 'group') { toast('只有群聊才有群文件', 'err'); return; }
      groupFilesModal(S.cid);
    });
  }
  // 顶栏「拉人」：让群成员不用先点聊天信息就能直接拉好友进群
  var btnIH = $('btnInviteHd');
  if (btnIH) {
    btnIH.addEventListener('click', function () { openInvite(S.cid); });
  }

  // 联系人面板：搜群号加群
  var btnJG = $('btnJoinGroup');
  if (btnJG) btnJG.addEventListener('click', joinGroupModal);

  // 工具栏
  document.querySelectorAll('.tool[data-tool]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.getAttribute('data-tool');
      if (t === 'emoji') toggleEmoji();
      else if (t === 'phrase') togglePhrases();
      else if (t === 'image') pickAndSend('image');
      else if (t === 'file') pickAndSend('file');
    });
  });
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.emoji-panel') && !e.target.closest('.tool[data-tool="emoji"]')) {
      $('emojiPanel').classList.add('hidden');
    }
    if (!e.target.closest('.phrase-panel') && !e.target.closest('.tool[data-tool="phrase"]')) {
      $('phrasePanel').classList.add('hidden');
    }
  });

  // 引用条
  $('replyX').addEventListener('click', function () { setReply(null); });

  // 输入框
  var input = $('input');
  input.addEventListener('keydown', function (e) {
    // @ 候选列表开着时，上下键选人、回车确认
    var pop = $('mentionPop');
    var open = pop && !pop.classList.contains('hidden');
    if (open) {
      var items = pop.querySelectorAll('.mitem');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        S.mentionPick += (e.key === 'ArrowDown' ? 1 : -1);
        if (S.mentionPick < 0) S.mentionPick = items.length - 1;
        if (S.mentionPick >= items.length) S.mentionPick = 0;
        for (var i = 0; i < items.length; i++) {
          items[i].classList.toggle('on', i === S.mentionPick);
        }
        return;
      }
      if (e.key === 'Escape') { hideMention(); return; }
      if (e.key === 'Enter' && items[S.mentionPick]) {
        e.preventDefault();
        applyMention(items[S.mentionPick]);
        return;
      }
    }
    if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey) {
      e.preventDefault();
      sendMessage();
    } else if (e.key === 'Enter' && e.ctrlKey) {
      e.preventDefault();
      sendMessage();
    }
  });
  input.addEventListener('input', function () { updateCount(); notifyTyping(); updateMention(); });
  input.addEventListener('click', updateMention);
  input.addEventListener('blur', function () {
    // 点候选项时不能让 blur 先把列表关掉
    setTimeout(function () { hideMention(); }, 160);
  });
  $('mentionPop').addEventListener('mousedown', function (e) {
    var b = e.target.closest('.mitem');
    if (!b) return;
    e.preventDefault();
    applyMention(b);
  });
  $('btnSend').addEventListener('click', sendMessage);
  $('btnClear').addEventListener('click', function () {
    input.value = ''; updateCount(); input.focus(); hideMention();
  });

  // 粘贴图片
  input.addEventListener('paste', function (e) {
    var items = (e.clipboardData || {}).items || [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].type && items[i].type.indexOf('image') === 0) {
        var f = items[i].getAsFile();
        if (f) {
          e.preventDefault();
          uploadFile(f, 'image').then(function (r) {
            if (r) doSend({ type: 'image', content: r.path, meta: r });
          });
        }
        return;
      }
    }
  });

  // 拖拽上传
  var scroll = $('msgScroll');
  ['dragenter', 'dragover'].forEach(function (ev) {
    scroll.addEventListener(ev, function (e) { e.preventDefault(); e.stopPropagation(); });
  });
  scroll.addEventListener('drop', function (e) {
    e.preventDefault();
    var files = Array.prototype.slice.call((e.dataTransfer || {}).files || []);
    files.forEach(function (f) {
      var kind = /^image\//.test(f.type) ? 'image' : 'file';
      uploadFile(f, kind).then(function (r) {
        if (!r) return;
        if (kind === 'image') doSend({ type: 'image', content: r.path, meta: r });
        else doSend({ type: 'file', content: r.path, meta: r });
      });
    });
  });

  // 联系人面板事件（动态内容）
  $('contactsBody').addEventListener('click', function (e) {
    var s = e.target.closest('#btnDoSearch');
    if (s) { doSearch($('addKw').value); return; }
    var acc = e.target.closest('[data-acc]');
    if (acc) {
      api('friend_accept', { uid: acc.getAttribute('data-acc') }, 'POST').then(function (r) {
        refreshContacts(r); toast('已添加为好友', 'ok');
      }).catch(function (err) { toast(err.message, 'err'); });
      return;
    }
    var rej = e.target.closest('[data-rej]');
    if (rej) {
      api('friend_reject', { uid: rej.getAttribute('data-rej') }, 'POST').then(function (r) {
        refreshContacts(r); toast('已拒绝');
      }).catch(function (err) { toast(err.message, 'err'); });
      return;
    }
    var add = e.target.closest('[data-add]');
    if (add) {
      api('friend_add', { uid: add.getAttribute('data-add') }, 'POST').then(function (r) {
        refreshContacts(r); toast('好友申请已发送', 'ok');
      }).catch(function (err) { toast(err.message, 'err'); });
      return;
    }
  });
  $('btnAddFriend').addEventListener('click', addFriendModal);
  $('btnCreateGroup').addEventListener('click', createGroupModal);

  // 弹窗内动态按钮
  $('modalBody').addEventListener('click', function (e) {
    var a2 = e.target.closest('[data-add2]');
    if (a2) {
      api('friend_add', { uid: a2.getAttribute('data-add2') }, 'POST').then(function (r) {
        refreshContacts(r); a2.outerHTML = '<span class="pill warn">等待通过</span>'; toast('好友申请已发送', 'ok');
      }).catch(function (err) { toast(err.message, 'err'); });
      return;
    }
    var c2 = e.target.closest('[data-acc2]');
    if (c2) {
      api('friend_accept', { uid: c2.getAttribute('data-acc2') }, 'POST').then(function (r) {
        refreshContacts(r); c2.outerHTML = '<span class="pill ok">已是好友</span>'; toast('已添加为好友', 'ok');
      }).catch(function (err) { toast(err.message, 'err'); });
    }
  });

  // 设置
  $('setAccount').textContent = S.me.username;
  $('setNick').value = S.me.nickname;
  $('setSign').value = S.me.signature || '';
  $('avaPick').style.backgroundImage = S.me.avatar ? 'url(' + avatarSrc(S.me.avatar) + ')' : '';
  if (!S.me.avatar) $('avaPick').textContent = firstChar(S.me.nickname);
  $('railAvatar').style.backgroundImage = S.me.avatar ? 'url(' + avatarSrc(S.me.avatar) + ')' : '';
  if (!S.me.avatar) $('railAvatar').textContent = firstChar(S.me.nickname);

  $('btnSaveProfile').addEventListener('click', function () {
    api('profile', { nickname: $('setNick').value, signature: $('setSign').value }, 'POST').then(function (r) {
      S.me = r.user;
      S.convs = r.conversations || S.convs;
      $('profileTip').classList.remove('hidden');
      setTimeout(function () { $('profileTip').classList.add('hidden'); }, 1800);
      $('avaPick').style.backgroundImage = r.user.avatar ? 'url(' + avatarSrc(r.user.avatar) + ')' : '';
      $('railAvatar').style.backgroundImage = r.user.avatar ? 'url(' + avatarSrc(r.user.avatar) + ')' : '';
      renderSide(); renderMain();
      toast('资料已保存', 'ok');
    }).catch(function (e) { toast(e.message, 'err'); });
  });

  $('btnChangeAva').addEventListener('click', function () { $('avaFile').click(); });

  /* 设置页「常用功能」导航：把容易找不到的入口集中到一处 */
  (function nav() {
    function needGroup(msg) {
      var c = convById(S.cid);
      if (!c || c.type !== 'group') { toast('请先在左侧选中一个群聊', 'err'); return false; }
      return true;
    }
    var map = {
      navContacts:    function () { setView('contacts'); },
      navAddFriend:   function () { setView('contacts'); if ($('btnAddFriend')) $('btnAddFriend').click(); },
      navCreateGroup: function () { setView('contacts'); if ($('btnCreateGroup')) $('btnCreateGroup').click(); },
      navJoinGroup:   function () { setView('contacts'); if ($('btnJoinGroup')) $('btnJoinGroup').click(); },
      navGroupFiles:  function () { if (needGroup()) groupFilesModal(S.cid); },
      navInvite:      function () { if (needGroup()) openInvite(S.cid); },
      navAvatar:      function () { $('avaFile').click(); }
    };
    for (var k in map) {
      (function (id, fn) {
        var el = $(id);
        if (el) { el.addEventListener('click', function () { fn(); }); }
      })(k, map[k]);
    }
  })();
  $('avaFile').addEventListener('change', function () {
    var f = this.files && this.files[0];
    if (!f) return;
    var fd = new FormData();
    fd.append('file', f);
    api('avatar', fd, 'POST').then(function (r) {
      S.me = r.user;
      S.convs = r.conversations || S.convs;
      $('avaPick').style.backgroundImage = 'url(' + avatarSrc(r.user.avatar) + ')';
      $('railAvatar').style.backgroundImage = 'url(' + avatarSrc(r.user.avatar) + ')';
      this.value = '';
      renderSide(); renderMain();
      toast('头像已更新', 'ok');
    }.bind(this)).catch(function (e) { toast(e.message, 'err'); });
  });

  $('btnSavePw').addEventListener('click', function () {
    var o = $('pwOld').value, n = $('pwNew').value;
    if (!o || !n) { toast('请填写原密码和新密码', 'err'); return; }
    api('password', { old: o, new: n }, 'POST').then(function () {
      $('pwOld').value = ''; $('pwNew').value = '';
      $('pwTip').classList.remove('hidden');
      setTimeout(function () { $('pwTip').classList.add('hidden'); }, 1800);
      toast('密码已修改', 'ok');
    }).catch(function (e) { toast(e.message, 'err'); });
  });

  $('btnLogout').addEventListener('click', function () {
    if (!confirm('确定退出登录？')) return;
    api('logout', {}, 'POST').catch(function () {}).then(function () {
      location.href = BASE + '/index.php';
    });
  });

  // 窗口按钮
  document.querySelectorAll('.tb-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      var act = b.getAttribute('data-act');
      if (act === 'max') {
        if (document.fullscreenElement) document.exitFullscreen();
        else document.documentElement.requestFullscreen().catch(function () {});
      } else if (act === 'close') {
        api('logout', {}, 'POST').catch(function () {}).then(function () { window.close(); });
      }
    });
  });

  // 快捷键
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      if (!$('viewer').classList.contains('hidden')) $('viewer').classList.add('hidden');
      closeModal();
      $('ctxMenu').classList.add('hidden');
      $('emojiPanel').classList.add('hidden');
      $('phrasePanel').classList.add('hidden');
      hideMention();
      setReply(null);
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      $('sideSearch').focus();
    }
  });

  /* =========================================================
   *  启动
   * ======================================================= */
  // 在线状态依赖服务端心跳（60 秒有效），关闭页面会自动显示离线，无需额外上报
  renderSide();
  renderMain();
  updateCount();
  renderBlockCount();
  loadPrefs();
  updateFavBadge();
  setView('chat');
  if (S.convs.length) {
    openConv(S.convs[0].id);
  }
  setTimeout(pollLoop, 800);
  window.HNIM = { S: S, api: api, toast: toast };
})();
