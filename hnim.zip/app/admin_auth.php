<?php
/**
 * HNIM 后台（admin.php）登录与权限
 * ------------------------------------------------------------------
 * 后台是独立于聊天账号的一套账号体系，只有这里放行的账号才能进后台。
 * 账号密码存在 config/admin.php（安装时自动生成，可在后台里改），
 * 不存在于任何程序源码里，也就不存在“写死的后门密码”。
 */
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/** 后台默认账号（安装程序会按这个生成 config/admin.php） */
const HNIM_ADMIN_DEFAULT_USER = 'huinao';
/** 后台默认密码（同上，仅用于“第一次安装”时写入配置文件） */
const HNIM_ADMIN_DEFAULT_PASS = 'hn112233';

/**
 * 读取后台账号配置。
 * 配置文件不存在时按默认值返回，方便老版本升级上来后也能进后台。
 */
function hnim_admin_conf(): array
{
    $conf = hnim_config('admin', null);
    if (!is_array($conf)) {
        $conf = [];
    }
    return [
        'user'      => (string) ($conf['user'] ?? HNIM_ADMIN_DEFAULT_USER),
        'pass'      => (string) ($conf['pass'] ?? ''),
        'pass_hash' => (string) ($conf['pass_hash'] ?? ''),
        'updated_at' => (string) ($conf['updated_at'] ?? ''),
    ];
}

/**
 * 确保 config/admin.php 存在。
 * 安装时调用；老部署第一次打开后台时也会顺手补一份。
 */
function hnim_admin_ensure(): void
{
    $file = HNIM_CONFIG . '/admin.php';
    if (is_file($file)) {
        return;
    }
    $user = HNIM_ADMIN_DEFAULT_USER;
    $pass = HNIM_ADMIN_DEFAULT_PASS;
    // 老部署里如果已经有同名聊天账号，优先沿用它的密码，避免又冒出一个新密码
    try {
        $u = hnim_user_by_name($user, hnim_db());
        if ($u) {
            // 不沿用聊天账号密码（两者本就该分开），但仍然保留默认提示
        }
    } catch (Throwable $e) {
        // 数据库还没好也照样写默认配置
    }
    hnim_admin_write($user, $pass);
}

/** 写入后台账号配置 */
function hnim_admin_write(string $user, string $pass, bool $plain = true): void
{
    if (!is_dir(HNIM_CONFIG)) {
        @mkdir(HNIM_CONFIG, 0700, true);
    }
    $data = [
        'admin' => [
            'user'       => $user,
            'pass_hash'  => $plain ? password_hash($pass, PASSWORD_DEFAULT) : $pass,
            'updated_at' => date('Y-m-d H:i:s'),
        ],
    ];
    $body = "<?php\n/**\n * HNIM 后台账号（安装程序生成，可在此手动修改；请勿泄露）\n */\ndeclare(strict_types=1);\n\nreturn "
        . var_export($data, true) . ";\n";
    @file_put_contents(HNIM_CONFIG . '/admin.php', $body, LOCK_EX);
    @chmod(HNIM_CONFIG . '/admin.php', 0600);
}

/**
 * 校验后台账号密码。
 */
function hnim_admin_verify(string $user, string $pass): bool
{
    $c = hnim_admin_conf();
    if (!hash_equals($c['user'], $user)) {
        return false;
    }
    if ($c['pass_hash'] !== '') {
        return password_verify($pass, $c['pass_hash']);
    }
    // 兼容旧配置里直接存明文的情况
    return $c['pass'] !== '' && hash_equals($c['pass'], $pass);
}

/** 当前是否已登录后台 */
function hnim_admin_logged(): bool
{
    hnim_session_start();
    return !empty($_SESSION['admin_user'])
        && hash_equals(hnim_admin_conf()['user'], (string) $_SESSION['admin_user']);
}

/** 登录后台 */
function hnim_admin_login(string $user, string $pass): bool
{
    if (!hnim_admin_verify($user, $pass)) {
        return false;
    }
    hnim_session_start();
    session_regenerate_id(true);
    $_SESSION['admin_user'] = hnim_admin_conf()['user'];
    $_SESSION['admin_at']   = time();
    return true;
}

/** 退出后台 */
function hnim_admin_logout(): void
{
    hnim_session_start();
    unset($_SESSION['admin_user'], $_SESSION['admin_at']);
}

/** 后台操作写日志 */
function hnim_admin_log(string $action, string $detail = ''): void
{
    try {
        $st = hnim_db()->prepare(
            'INSERT INTO admin_log (admin, action, detail, ip, created_at) VALUES (?,?,?,?,?)'
        );
        $st->execute([
            (string) ($_SESSION['admin_user'] ?? ''),
            mb_substr($action, 0, 64),
            mb_substr($detail, 0, 255),
            mb_substr(hnim_client_ip(), 0, 64),
            time(),
        ]);
    } catch (Throwable $e) {
        // 日志失败不能影响主流程
    }
}

/** 后台登录失败次数限制用的键 */
function hnim_admin_try_key(): string
{
    return 'hnim_admin_try_' . md5(hnim_client_ip());
}
