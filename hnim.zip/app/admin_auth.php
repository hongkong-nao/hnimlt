<?php
/**
 * HNIM 后台（admin.php）登录与权限
 * ------------------------------------------------------------------
 * 后台是独立于聊天账号的一套账号体系，只有这里放行的账号才能进后台。
 * 账号密码存在 config/admin.php（安装时生成，可在后台里改）。
 * 源码里**不含任何默认账号或默认密码**：配置文件缺失就直接报错，
 * 不做兜底创建——否则漏传一次文件就等于凭空多一个密码公开的超管。
 */
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * 读取后台账号配置。
 *
 * 这里刻意**不提供任何默认账号**：配置缺失时返回空字符串，由调用方自己处理。
 * 以前这里兜底过一组写死在源码里的账号密码，配置文件一旦缺失（比如漏上传），
 * 就会凭空长出一个谁都知道密码的超管——那等于在源码里留了后门。
 */
function hnim_admin_conf(): array
{
    $conf = hnim_config('admin', null);
    if (!is_array($conf)) {
        $conf = [];
    }
    return [
        'user'      => (string) ($conf['user'] ?? ''),
        'pass'      => (string) ($conf['pass'] ?? ''),
        'pass_hash' => (string) ($conf['pass_hash'] ?? ''),
        'updated_at' => (string) ($conf['updated_at'] ?? ''),
    ];
}

/** 后台账号配置是否可用 */
function hnim_admin_ready(): bool
{
    $c = hnim_admin_conf();
    return $c['user'] !== '' && ($c['pass_hash'] !== '' || $c['pass'] !== '');
}

/**
 * 检查后台账号配置是否在位。
 *
 * 只检查、不创建。以前这里是「文件不存在就按源码里的默认账号密码写一份」，
 * 看着很贴心，实际后果是：漏传 config/admin.php 时会静默生成一个公开密码的超管。
 * 宁可直接报错让人来处理，也不替运维做这个决定。
 *
 * @throws RuntimeException 配置缺失时抛出，消息里带上该怎么处理
 */
function hnim_admin_ensure(): void
{
    if (hnim_admin_ready()) {
        return;
    }
    $file = HNIM_CONFIG . '/admin.php';
    if (!is_file($file)) {
        throw new RuntimeException(
            '后台账号配置文件不存在（' . $file . '）。'
            . '请运行 install.php 重新安装，或把备份的 config/admin.php 放回 config/ 目录。'
            . '注意：程序不会自动生成默认密码账号，必须由你自己设置一个。'
        );
    }
    throw new RuntimeException(
        '后台账号配置文件存在但内容不完整（缺少账号或密码）：' . $file . '。'
        . '请删除该文件后运行 install.php 重新生成，或手动补齐 user 与 pass_hash。'
    );
}

/** 写入后台账号配置 */
function hnim_admin_write(string $user, string $pass, bool $plain = true): void
{
    if (!is_dir(HNIM_CONFIG)) {
        @mkdir(HNIM_CONFIG, 0700, true);
    }
    $data = [
        'admin' => [
            'user'       => $user,
            'pass_hash'  => $plain ? password_hash($pass, PASSWORD_DEFAULT) : $pass,
            'updated_at' => date('Y-m-d H:i:s'),
        ],
    ];
    $body = "<?php\n/**\n * HNIM 后台账号（安装程序生成，可在此手动修改；请勿泄露）\n */\ndeclare(strict_types=1);\n\nreturn "
        . var_export($data, true) . ";\n";
    @file_put_contents(HNIM_CONFIG . '/admin.php', $body, LOCK_EX);
    @chmod(HNIM_CONFIG . '/admin.php', 0600);
}

/**
 * 校验后台账号密码。
 */
function hnim_admin_verify(string $user, string $pass): bool
{
    $c = hnim_admin_conf();
    if (!hash_equals($c['user'], $user)) {
        return false;
    }
    if ($c['pass_hash'] !== '') {
        return password_verify($pass, $c['pass_hash']);
    }
    // 兼容旧配置里直接存明文的情况
    return $c['pass'] !== '' && hash_equals($c['pass'], $pass);
}

/** 当前是否已登录后台 */
function hnim_admin_logged(): bool
{
    hnim_session_start();
    return !empty($_SESSION['admin_user'])
        && hash_equals(hnim_admin_conf()['user'], (string) $_SESSION['admin_user']);
}

/** 登录后台 */
function hnim_admin_login(string $user, string $pass): bool
{
    if (!hnim_admin_verify($user, $pass)) {
        return false;
    }
    hnim_session_start();
    session_regenerate_id(true);
    $_SESSION['admin_user'] = hnim_admin_conf()['user'];
    $_SESSION['admin_at']   = time();
    return true;
}

/** 退出后台 */
function hnim_admin_logout(): void
{
    hnim_session_start();
    unset($_SESSION['admin_user'], $_SESSION['admin_at']);
}

/** 后台操作写日志 */
function hnim_admin_log(string $action, string $detail = ''): void
{
    try {
        $st = hnim_db()->prepare(
            'INSERT INTO admin_log (admin, action, detail, ip, created_at) VALUES (?,?,?,?,?)'
        );
        $st->execute([
            (string) ($_SESSION['admin_user'] ?? ''),
            mb_substr($action, 0, 64),
            mb_substr($detail, 0, 255),
            mb_substr(hnim_client_ip(), 0, 64),
            time(),
        ]);
    } catch (Throwable $e) {
        // 日志失败不能影响主流程
    }
}

/** 后台登录失败次数限制用的键 */
function hnim_admin_try_key(): string
{
    return 'hnim_admin_try_' . md5(hnim_client_ip());
}
