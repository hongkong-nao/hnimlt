<?php
/**
 * HNIM 业务核心：用户 / 会话 / 消息 / 好友 / 在线状态
 */
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/mail.php';

/* ================================================================== *
 *  通用输出
 * ------------------------------------------------------------------
 *  接口必须吐出「干净」的 JSON：前面多一个空格、一个 BOM、一句
 *  PHP Warning，前端 JSON.parse 就直接失败，只能看到
 *  「服务器返回异常（HTTP 200）」这种没法排查的提示。
 *
 *  共享主机上特别容易踩：很多主机的 php.ini 是 display_errors=On，
 *  任意一条 Notice / Deprecated 都会被打到响应体最前面。所以这里
 *  从入口就开始把输出管起来 —— 见 hnim_output_guard()。
 * ================================================================== */

/**
 * 把「已经漏出去的东西」全部收回来，并保证之后的输出只有 JSON。
 *
 * 由 api.php / admin.php 在最开头调用，必须在 require 业务代码之前，
 * 否则 require 期间的 warning 早就打印出去了。
 */
function hnim_output_guard(): void
{
    // 自己开一个缓冲，后面 hnim_json() 会先清空它再吐 JSON
    ob_start();

    // 报错一律走服务器错误日志，不进响应体
    @ini_set('display_errors', '0');
    @ini_set('html_errors', '0');

    register_shutdown_function(function () {
        // 正常路径：hnim_json() 已经 exit 了，走不到这里。
        // 走到这里说明是致命错误 / 白屏 —— 补一个能看懂的 JSON，
        // 总比浏览器里一堆 HTML 报错页强。
        $err = error_get_last();
        $fatal = $err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true);
        if (!$fatal || headers_sent()) {
            return;
        }
        while (ob_get_level() > 0) {
            @ob_end_clean();
        }
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            header('X-Content-Type-Options: nosniff');
            header('Cache-Control: no-store');
        }
        echo json_encode([
            'ok'    => false,
            'error' => '服务器内部错误：' . $err['message'] . '（' . basename((string) $err['file']) . ':' . $err['line'] . '）',
            'file'  => basename((string) $err['file']),
            'line'  => (int) $err['line'],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    });
}

function hnim_json($data, int $code = 200): void
{
    // 把入口缓冲里可能已经攒下的杂音（warning、BOM 后的空行…）全丢掉，
    // 保证响应体第一个字节就是 '{'
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function hnim_fail(string $msg, int $code = 400, array $extra = []): void
{
    hnim_json(array_merge(['ok' => false, 'error' => $msg], $extra), $code);
}

/* ================================================================== *
 *  页脚服务商信息
 * ------------------------------------------------------------------
 *  整句文字都可以点，链接到 config/config.php 里 site.credit.url 配的地址。
 *  想换文案或干脆不显示，把 text 改成空字符串就行（不用改代码）。
 * ================================================================== */

/**
 * 生成页脚那行小字，返回可直接插入的 HTML（已经转义）。
 * 没配 / 文案为空时返回空串，调用方原样输出即可。
 */
function hnim_credit_html(): string
{
    $c = hnim_config('site.credit', null);
    if (!is_array($c)) {
        $c = ['text' => '本站由令星云计算提供技术服务', 'url' => 'https://cloud.lxoffice.cn'];
    }
    $text = trim((string) ($c['text'] ?? ''));
    $url  = trim((string) ($c['url'] ?? ''));

    if ($text === '') {
        return '';
    }
    $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    // 没配地址、或者地址不是 http(s)，就只出纯文字，绝不生成可点的假链接
    if ($url === '' || !preg_match('#^https?://#i', $url)) {
        return '<div class="credit">' . $text . '</div>';
    }
    $url = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    return '<div class="credit"><a href="' . $url . '" target="_blank" rel="noopener nofollow">'
         . $text . '</a></div>';
}

/* ================================================================== *
 *  双库桥接
 * ------------------------------------------------------------------
 *  账号表（users/friends/blocks/...）在账号库，聊天表在聊天库，
 *  两个库之间不能 JOIN，所以跨库的查询统一走“先查聊天、再批量补用户”。
 * ================================================================== */

/**
 * 批量取用户行，返回 id => 数组 的映射。
 * @param int[] $ids
 */
function hnim_users_map(array $ids, ?PDO $pdo = null): array
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    if (!$ids) {
        return [];
    }
    $pdo = $pdo ?: hnim_db();
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT * FROM users WHERE id IN ({$in})");
    $st->execute($ids);
    $map = [];
    foreach ($st->fetchAll() as $r) {
        $map[(int) $r['id']] = $r;
    }
    return $map;
}

/**
 * 往一批聊天记录行上补齐发送者信息（昵称/头像/群名片）。
 * @param array[] $rows 直接修改引用
 * @param string   $pk  行里发送者 id 的字段名
 */
function hnim_attach_senders(array &$rows, string $pk = 'sender_id', ?PDO $pdo = null): void
{
    $ids = [];
    foreach ($rows as $r) {
        $ids[] = (int) ($r[$pk] ?? 0);
    }
    $map = hnim_users_map($ids, $pdo);
    foreach ($rows as $i => $r) {
        $uid = (int) ($r[$pk] ?? 0);
        $u = $map[$uid] ?? null;
        $rows[$i]['nickname'] = $u['nickname'] ?? '';
        $rows[$i]['username'] = $u['username'] ?? '';
        $rows[$i]['avatar']   = $u['avatar'] ?? '';
        // 老代码用 uavatar 这个别名，这里两个都给上
        $rows[$i]['uavatar']  = $u['avatar'] ?? '';
        $rows[$i]['signature'] = $u['signature'] ?? '';
        $rows[$i]['sender_banned'] = (int) ($u['banned'] ?? 0);
        // 成员列表要显示在线状态和身份，一并带上（id 不能动，那是聊天记录自己的主键）
        $rows[$i]['last_seen'] = (int) ($u['last_seen'] ?? 0);
        $rows[$i]['role']      = (string) ($u['role'] ?? 'user');
    }
}

/**
 * 往一批群成员行上补齐用户信息。
 * @param array[] $rows 直接修改引用
 */
function hnim_attach_users(array &$rows, string $pk = 'user_id', ?PDO $pdo = null): void
{
    hnim_attach_senders($rows, $pk, $pdo);
}

/**
 * 成员关系行（只有 user_id）转成公开资料。
 * 聊天表和账号表分库之后，成员行里没有 users.id，得自己补上。
 */
function hnim_public_member(array $r): array
{
    $r['id'] = (int) ($r['user_id'] ?? 0);
    return hnim_user_public($r);
}

function hnim_ok(array $data = []): void
{
    hnim_json(array_merge(['ok' => true], $data));
}

/* ================================================================== *
 *  用户
 * ================================================================== */

function hnim_user_by_id(int $id, ?PDO $pdo = null): ?array
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

function hnim_user_by_name(string $username, ?PDO $pdo = null): ?array
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
    $st->execute([$username]);
    $row = $st->fetch();
    return $row ?: null;
}

function hnim_user_create(string $username, string $password, string $nickname, string $role = 'user', ?PDO $pdo = null): int
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('INSERT INTO users (username, password, nickname, role, created_at, last_seen) VALUES (?,?,?,?,?,0)');
    $st->execute([$username, password_hash($password, PASSWORD_DEFAULT), $nickname, $role, time()]);
    return (int) $pdo->lastInsertId();
}

/** 对外暴露的用户信息（绝不含密码） */
function hnim_user_public(?array $u, ?array $ctx = null): array
{
    if (!$u) {
        return [];
    }
    $id = (int) $u['id'];
    $online = hnim_is_online($u);
    $out = [
        'id'         => $id,
        'username'   => (string) $u['username'],
        'nickname'   => (string) $u['nickname'],
        'avatar'     => (string) ($u['avatar'] ?? ''),
        'signature'  => (string) ($u['signature'] ?? ''),
        'online'     => $online,
        'last_seen'  => (int) ($u['last_seen'] ?? 0),
        'role'       => (string) ($u['role'] ?? 'user'),
    ];
    if ($ctx !== null) {
        $out['remark'] = (string) ($ctx['remark'] ?? '');
        $out['display'] = $out['remark'] !== '' ? $out['remark'] : $out['nickname'];
    } else {
        $out['display'] = $out['nickname'];
    }
    return $out;
}

function hnim_is_online(array $u, ?int $now = null): bool
{
    // 只依据 last_seen 判断：60 秒内有心跳即为在线，关闭页面后自动离线
    $now = $now ?: time();
    return ($now - (int) ($u['last_seen'] ?? 0)) < 60;
}

function hnim_current_user(): ?array
{
    static $cached = false;
    static $user = null;
    if ($cached === true) {
        return $user;
    }
    $cached = true;
    hnim_session_start();
    $uid = (int) ($_SESSION['uid'] ?? 0);
    if ($uid > 0) {
        $user = hnim_user_by_id($uid);
        if (!$user) {
            unset($_SESSION['uid']);
            $user = null;
        }
    }
    return $user;
}

function hnim_require_login(): array
{
    $u = hnim_current_user();
    if (!$u) {
        if (hnim_is_api()) {
            hnim_fail('登录状态已失效，请重新登录', 401);
        }
        header('Location: ' . hnim_url('index.php') . '?view=login');
        exit;
    }
    return $u;
}

function hnim_touch_online(int $userId, ?PDO $pdo = null): void
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('UPDATE users SET online = 1, last_seen = ? WHERE id = ?');
    $st->execute([time(), $userId]);
}

function hnim_touch_offline(int $userId, ?PDO $pdo = null): void
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('UPDATE users SET online = 0, last_seen = ? WHERE id = ?');
    $st->execute([time(), $userId]);
}

/* ================================================================== *
 *  会话
 * ================================================================== */

/** 单聊会话：按 (小id,大id) 复用同一条记录 */
function hnim_single_conversation(int $a, int $b, ?PDO $pdo = null): array
{
    $pdo = hnim_chat_pdo($pdo);
    $key = $a < $b ? "{$a}:{$b}" : "{$b}:{$a}";

    $st = $pdo->prepare('SELECT * FROM conversations WHERE type = ? AND title = ? LIMIT 1');
    $st->execute(['single', $key]);
    $conv = $st->fetch();

    if (!$conv) {
        $st = $pdo->prepare('INSERT INTO conversations (type, title, created_at) VALUES (?,?,?)');
        $st->execute(['single', $key, time()]);
        $cid = (int) $pdo->lastInsertId();

        $ignore = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite' ? 'INSERT OR IGNORE' : 'INSERT IGNORE';
        $add = $pdo->prepare($ignore . ' INTO conversation_members (conversation_id, user_id, joined_at) VALUES (?,?,?)');
        $add->execute([$cid, $a, time()]);
        $add->execute([$cid, $b, time()]);
        $conv = hnim_conv_by_id($cid, $pdo) ?: ['id' => $cid, 'type' => 'single', 'title' => $key];
    }
    return $conv;
}

function hnim_conv_by_id(int $id, ?PDO $pdo = null): ?array
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT * FROM conversations WHERE id = ? LIMIT 1');
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ?: null;
}

/** 我是否在该会话中 */
function hnim_is_member(int $convId, int $userId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT 1 FROM conversation_members WHERE conversation_id = ? AND user_id = ? LIMIT 1');
    $st->execute([$convId, $userId]);
    return (bool) $st->fetchColumn();
}

/** 群会话成员 id 列表 */
function hnim_conv_member_ids(int $convId, ?PDO $pdo = null): array
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT user_id FROM conversation_members WHERE conversation_id = ?');
    $st->execute([$convId]);
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

/** 群会话成员数量 */
function hnim_conv_member_count(int $convId, ?PDO $pdo = null): int
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT COUNT(*) FROM conversation_members WHERE conversation_id = ?');
    $st->execute([$convId]);
    return (int) $st->fetchColumn();
}

/**
 * 生成会话列表（含最后一条消息、对方资料、未读数）
 */
function hnim_conversation_list(int $userId, ?PDO $pdo = null): array
{
    $acc  = $pdo ?: hnim_db();          // 账号库
    $chat = hnim_chat_db();             // 聊天库

    $sql = 'SELECT c.id, c.type, c.title, c.avatar, c.owner_id, c.announcement, c.gno,
                   m.unread, m.muted, m.last_read_id
            FROM conversation_members m
            JOIN conversations c ON c.id = m.conversation_id
            WHERE m.user_id = ?
            ORDER BY c.id ASC';
    $st = $chat->prepare($sql);
    $st->execute([$userId]);
    $rows = $st->fetchAll();
    if (!$rows) {
        return [];
    }

    // 消息在聊天库、昵称在账号库，所以这里不 JOIN，取到行后再补发送者
    $st = $chat->prepare(
        'SELECT * FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 1'
    );
    $st2 = $chat->prepare(
        'SELECT COUNT(*) FROM messages WHERE conversation_id = ? AND id > ? AND sender_id <> ?'
    );

    $list = [];
    foreach ($rows as $c) {
        $cid = (int) $c['id'];
        $st->execute([$cid]);
        $last = $st->fetch() ?: null;
        if ($last) {
            $one = [$last];
            hnim_attach_senders($one, 'sender_id', $acc);
            $last = $one[0];
        }

        $st2->execute([$cid, (int) $c['last_read_id'], $userId]);
        $unread = (int) $st2->fetchColumn();

        $item = [
            'id'         => $cid,
            'type'       => (string) $c['type'],
            'unread'     => $unread,
            'muted'      => (int) $c['muted'] === 1,
            'last_read'  => (int) $c['last_read_id'],
            'peer'       => null,
            'members'    => [],
            'member_count' => 0,
            'last'       => null,
        ];

        if ($c['type'] === 'single') {
            [$a, $b] = array_map('intval', explode(':', (string) $c['title']));
            $peerId  = ($a === $userId) ? $b : $a;
            $peer    = hnim_user_by_id($peerId, $acc);
            if ($peer) {
                $item['peer'] = hnim_user_public($peer, hnim_friend_ctx($userId, $peerId, $acc));
                $item['peer']['blocked'] = hnim_is_blocked($userId, $peerId, $acc);
            }
            $item['title'] = $item['peer']['display'] ?? ('用户' . $peerId);
            $item['avatar'] = $item['peer']['avatar'] ?? '';
        } else {
            $item['title'] = (string) $c['title'];
            $item['avatar'] = (string) $c['avatar'];
            $item['gno']    = $c['gno'] === null ? '' : (string) $c['gno'];
            $ids = hnim_conv_member_ids($cid, $chat);
            $item['members'] = $ids;
            $item['member_count'] = count($ids);
            $item['owner_id'] = (int) $c['owner_id'];
            $item['announcement'] = (string) ($c['announcement'] ?? '');
            $item['all_muted'] = (int) ($c['all_muted'] ?? 0) === 1;
        }

        if ($last) {
            $item['last'] = hnim_message_public($last, $userId);
            $item['time'] = (int) $last['created_at'];
        } else {
            $item['time'] = 0;
        }

        $list[] = $item;
    }

    usort($list, static function ($a, $b) {
        return $b['time'] <=> $a['time'];
    });
    return $list;
}

/**
 * 消息对外结构
 * @param bool $withActions 是否计算 can_recall（多查库，只有历史/轮询需要）
 */
function hnim_message_public(array $m, int $viewerId = 0, bool $withActions = false): array
{
    $meta = $m['meta'] ?? '';
    $meta = is_string($meta) ? json_decode($meta, true) : (is_array($meta) ? $meta : []);
    $recalled = (int) ($m['recalled_at'] ?? 0) > 0;
    // 群昵称优先于昵称
    $nick = trim((string) ($m['sender_card'] ?? ''));
    if ($nick === '') {
        $nick = (string) ($m['nickname'] ?? '');
    }

    // @ 列表
    $mentions = [];
    $raw = $m['mentions'] ?? '';
    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $mentions = array_values(array_filter(array_map('intval', $decoded)));
        }
    }

    // 引用：把被引用的那条摘要一起带上，前端不用再发一次请求
    $quote = null;
    $replyTo = (int) ($m['reply_to'] ?? 0);
    if ($replyTo > 0 && isset($m['quote_content'])) {
        $qc = (string) $m['quote_content'];
        $quote = [
            'id'       => $replyTo,
            'sender'   => (int) ($m['quote_sender'] ?? 0),
            'nickname' => (string) ($m['quote_nick'] ?? ''),
            'type'     => (string) ($m['quote_type'] ?? 'text'),
            // 图片/文件只说「[图片]」「[文件]」，不把大段内容塞进引用条
            'content'  => mb_substr($qc, 0, 120, 'UTF-8'),
            'recalled' => (int) ($m['quote_recalled'] ?? 0) > 0,
        ];
    }

    return [
        'id'         => (int) $m['id'],
        'conv'       => (int) $m['conversation_id'],
        'sender'     => (int) $m['sender_id'],
        'type'       => $recalled ? 'recalled' : (string) $m['type'],
        'content'    => $recalled ? '' : (string) ($m['content'] ?? ''),
        'meta'       => $recalled ? [] : (is_array($meta) ? $meta : []),
        'time'       => (int) $m['created_at'],
        'nickname'   => $nick,
        'avatar'     => (string) ($m['uavatar'] ?? ''),
        'mine'       => $viewerId > 0 && (int) $m['sender_id'] === $viewerId,
        'recalled'   => $recalled,
        'reply_to'   => $replyTo,
        'quote'      => $quote,
        'mentions'   => $mentions,
        'at_me'      => $viewerId > 0 && in_array($viewerId, $mentions, true),
        'can_recall' => $withActions && $viewerId > 0 && !$recalled && hnim_can_recall($m, $viewerId),
    ];
}

/* ================================================================== *
 *  消息
 * ================================================================== */

/**
 * 发送消息
 * @param array $meta 图片/文件附加信息
 * @param int   $replyTo 引用回复的消息 id，0 表示不引用
 * @param array $mentions 被 @ 到的用户 id 列表
 */
function hnim_send_message(
    int $convId,
    int $senderId,
    string $type,
    string $content,
    array $meta = [],
    ?PDO $pdo = null,
    int $replyTo = 0,
    array $mentions = []
): int {
    $pdo = hnim_chat_pdo($pdo);
    $type = in_array($type, ['text', 'image', 'file', 'system'], true) ? $type : 'text';

    // 只能引用同一个会话里、且还在的消息，防止伪造别的群的 id
    $replyTo  = $replyTo > 0 ? hnim_real_reply_id($convId, $replyTo, $pdo) : 0;
    // @ 列表只保留本会话的真实成员
    $mentions = hnim_clean_mentions($convId, $mentions, $pdo);

    $st = $pdo->prepare(
        'INSERT INTO messages (conversation_id, sender_id, type, content, meta, reply_to, mentions, created_at)
         VALUES (?,?,?,?,?,?,?,?)'
    );
    $st->execute([
        $convId,
        $senderId,
        $type,
        $content,
        $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE) : '',
        $replyTo,
        $mentions ? json_encode(array_values($mentions)) : '',
        time(),
    ]);
    $id = (int) $pdo->lastInsertId();

    // 发送者自己标记为已读
    $up = $pdo->prepare('UPDATE conversation_members SET last_read_id = ?, unread = 0 WHERE conversation_id = ? AND user_id = ?');
    $up->execute([$id, $convId, $senderId]);

    // 其余成员未读 +1（真实值在拉取时按 last_read_id 重算，这里先做乐观累加）
    $up2 = $pdo->prepare('UPDATE conversation_members SET unread = unread + 1 WHERE conversation_id = ? AND user_id <> ?');
    $up2->execute([$convId, $senderId]);

    // 被 @ 到的人即使开了免打扰，也要看到这条 @ 提醒
    if ($mentions) {
        $ph = implode(',', array_fill(0, count($mentions), '?'));
        $pm = $pdo->prepare("UPDATE conversation_members SET unread = unread + 1
                             WHERE conversation_id = ? AND user_id IN ({$ph}) AND user_id <> ?");
        $pm->execute(array_merge([$convId], $mentions, [$senderId]));
    }

    return $id;
}

/** 引用目标必须真实存在、属于同一会话、且没被撤回 */
function hnim_real_reply_id(int $convId, int $replyTo, ?PDO $pdo = null): int
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT id FROM messages WHERE id = ? AND conversation_id = ? AND recalled_at = 0');
    $st->execute([$replyTo, $convId]);
    $v = $st->fetchColumn();
    return $v === false ? 0 : (int) $v;
}

/** @ 列表去重，只保留本会话真实存在的成员 */
function hnim_clean_mentions(int $convId, array $mentions, ?PDO $pdo = null): array
{
    $mentions = array_values(array_unique(array_filter(array_map('intval', (array) $mentions))));
    if (!$mentions) {
        return [];
    }
    $pdo = hnim_chat_pdo($pdo);
    $ph  = implode(',', array_fill(0, count($mentions), '?'));
    $st  = $pdo->prepare("SELECT user_id FROM conversation_members WHERE conversation_id = ? AND user_id IN ({$ph})");
    $st->execute(array_merge([$convId], $mentions));
    $ok = array_map('intval', array_column($st->fetchAll(), 'user_id'));
    return array_values(array_intersect($mentions, $ok));
}

function hnim_mark_read(int $convId, int $userId, ?PDO $pdo = null): void
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT MAX(id) FROM messages WHERE conversation_id = ?');
    $st->execute([$convId]);
    $max = (int) $st->fetchColumn();
    $up = $pdo->prepare('UPDATE conversation_members SET last_read_id = ?, unread = 0 WHERE conversation_id = ? AND user_id = ?');
    $up->execute([$max, $convId, $userId]);
}

/** 拉取新消息 */
/**
 * 取消息并补齐「发送者昵称 / 群名片 / 被引用消息摘要」。
 * messages 和 conversation_members 都在聊天库，users 在账号库，
 * 所以 JOIN 只能做一半，昵称统一在 PHP 里补。
 */
function hnim_message_query(string $cmp, string $order, int $limit, array $args, ?PDO $pdo = null): array
{
    $acc  = hnim_db();
    $chat = hnim_chat_db();

    $st = $chat->prepare(
        "SELECT m.*, cm.card AS sender_card,
                q.content AS quote_content, q.sender_id AS quote_sender, q.type AS quote_type,
                q.recalled_at AS quote_recalled
         FROM messages m
         LEFT JOIN conversation_members cm
                ON cm.conversation_id = m.conversation_id AND cm.user_id = m.sender_id
         LEFT JOIN messages q ON q.id = m.reply_to
         WHERE {$cmp}
         ORDER BY m.id {$order}
         LIMIT {$limit}"
    );
    $st->execute($args);
    $rows = $st->fetchAll();
    if (!$rows) {
        return [];
    }

    hnim_attach_senders($rows, 'sender_id', $acc);

    // 被引用消息的发送者昵称
    $qids = [];
    foreach ($rows as $r) {
        $qs = (int) ($r['quote_sender'] ?? 0);
        if ($qs > 0) {
            $qids[] = $qs;
        }
    }
    $qmap = $qids ? hnim_users_map($qids, $acc) : [];
    foreach ($rows as $i => $r) {
        $qs = (int) ($r['quote_sender'] ?? 0);
        $rows[$i]['quote_nick'] = $qs > 0 ? (string) ($qmap[$qs]['nickname'] ?? '') : '';
    }
    return $rows;
}

function hnim_fetch_messages(int $convId, int $sinceId, int $limit = 200, ?PDO $pdo = null): array
{
    return hnim_message_query(
        'm.conversation_id = ? AND m.id > ?',
        'ASC',
        max(1, min(500, $limit)),
        [$convId, $sinceId]
    );
}

/** 历史消息（倒序取 before_id，返回正序） */
function hnim_history(int $convId, int $beforeId, int $limit = 30, ?PDO $pdo = null): array
{
    $rows = hnim_message_query(
        'm.conversation_id = ? AND m.id < ?',
        'DESC',
        max(1, min(100, $limit)),
        [$convId, $beforeId > 0 ? $beforeId : PHP_INT_MAX]
    );
    return array_reverse($rows);
}

/* ================================================================== *
 *  好友
 * ================================================================== */

/** 好友关系上下文（remark） */
function hnim_friend_ctx(int $userId, int $friendId, ?PDO $pdo = null): ?array
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('SELECT * FROM friends WHERE user_id = ? AND friend_id = ? LIMIT 1');
    $st->execute([$userId, $friendId]);
    $r = $st->fetch();
    return $r ?: null;
}

function hnim_friend_status(int $userId, int $friendId, ?PDO $pdo = null): int
{
    $r = hnim_friend_ctx($userId, $friendId, $pdo);
    return $r ? (int) $r['status'] : -1;
}

/** 好友列表 */
function hnim_friend_list(int $userId, ?PDO $pdo = null): array
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare(
        'SELECT f.remark, f.status, f.group_id, u.*
         FROM friends f
         JOIN users u ON u.id = f.friend_id
         WHERE f.user_id = ?
         ORDER BY f.status ASC, f.group_id ASC, u.nickname ASC'
    );
    $st->execute([$userId]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $pub = hnim_user_public($r);
        $pub['remark'] = (string) $r['remark'];
        $pub['display'] = $r['remark'] !== '' ? $r['remark'] : $pub['nickname'];
        $pub['friend_status'] = (int) $r['status'];
        $pub['group_id'] = (int) $r['group_id'];
        $out[] = $pub;
    }
    return $out;
}

/** 申请添加好友（双向写入：一条 pending，一条 auto-accept 用于对方判断） */
function hnim_friend_request(int $fromId, int $toId, string $verifyMsg = '', ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    if ($fromId === $toId) {
        return false;
    }
    if (!hnim_user_by_id($toId, $pdo)) {
        return false;
    }
    if (hnim_is_blocked($fromId, $toId, $pdo)) {
        return false;
    }
    $verifyMsg = trim($verifyMsg);
    $now = time();
    $isSqlite = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
    $sql = $isSqlite
        ? 'INSERT INTO friends (user_id, friend_id, remark, status, verify_msg, created_at) VALUES (?,?,?,?,?,?)
           ON CONFLICT(user_id, friend_id) DO UPDATE SET status = excluded.status, verify_msg = excluded.verify_msg, created_at = excluded.created_at'
        : 'INSERT INTO friends (user_id, friend_id, remark, status, verify_msg, created_at) VALUES (?,?,?,?,?,?)
           ON DUPLICATE KEY UPDATE status = VALUES(status), verify_msg = VALUES(verify_msg), created_at = VALUES(created_at)';
    $st = $pdo->prepare($sql);
    $st->execute([$fromId, $toId, '', 0, $verifyMsg, $now]);
    return true;
}

function hnim_friend_accept(int $userId, int $fromId, ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    if (hnim_is_blocked($userId, $fromId, $pdo)) {
        return false;
    }
    // 我方记录置为通过
    $st = $pdo->prepare('UPDATE friends SET status = 1 WHERE user_id = ? AND friend_id = ? AND status = 0');
    $st->execute([$fromId, $userId]);
    if ($st->rowCount() === 0) {
        return false;
    }
    // 对方记录置为通过
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'sqlite') {
        $up = $pdo->prepare('INSERT INTO friends (user_id, friend_id, remark, status, created_at) VALUES (?,?,?,1,?)
                             ON CONFLICT(user_id, friend_id) DO UPDATE SET status = 1');
    } else {
        $up = $pdo->prepare('INSERT INTO friends (user_id, friend_id, remark, status, created_at) VALUES (?,?,?,1,?)
                             ON DUPLICATE KEY UPDATE status = 1');
    }
    $up->execute([$userId, $fromId, '', time()]);
    return true;
}

function hnim_friend_remove(int $userId, int $friendId, ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('DELETE FROM friends WHERE user_id = ? AND friend_id = ?');
    $st->execute([$userId, $friendId]);
    $st2 = $pdo->prepare('DELETE FROM friends WHERE user_id = ? AND friend_id = ?');
    $st2->execute([$friendId, $userId]);
    return true;
}

/** 待我处理的申请（对方 status = 0） */
function hnim_friend_requests(int $userId, ?PDO $pdo = null): array
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare(
        'SELECT f.created_at AS req_at, f.verify_msg, f.group_id, u.*
         FROM friends f
         JOIN users u ON u.id = f.user_id
         WHERE f.friend_id = ? AND f.status = 0
         ORDER BY f.created_at DESC'
    );
    $st->execute([$userId]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $pub = hnim_user_public($r);
        $pub['time'] = (int) $r['req_at'];
        $pub['verify_msg'] = (string) $r['verify_msg'];
        $out[] = $pub;
    }
    return $out;
}

/* ================================================================== *
 *  黑名单
 * ================================================================== */

/** 我是否把某人拉黑了（双向判断：任何一边拉黑都算） */
function hnim_is_blocked(int $userId, int $otherId, ?PDO $pdo = null): bool
{
    if ($userId === $otherId) {
        return false;
    }
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('SELECT COUNT(*) FROM blocks WHERE (user_id = ? AND block_id = ?) OR (user_id = ? AND block_id = ?)');
    $st->execute([$userId, $otherId, $otherId, $userId]);
    return (int) $st->fetchColumn() > 0;
}

/** 拉黑某人。拉黑后双方不能再发消息、不能加好友 */
function hnim_block_add(int $userId, int $targetId, ?PDO $pdo = null): bool
{
    if ($userId === $targetId) {
        return false;
    }
    $pdo = $pdo ?: hnim_db();
    if (!hnim_user_by_id($targetId, $pdo)) {
        return false;
    }
    try {
        $st = $pdo->prepare('INSERT INTO blocks (user_id, block_id, created_at) VALUES (?,?,?)');
        $st->execute([$userId, $targetId, time()]);
    } catch (Throwable $e) {
        return false;   // 已经拉黑过了
    }
    // 顺手把好友关系和待处理申请清掉
    $st = $pdo->prepare('DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)');
    $st->execute([$userId, $targetId, $targetId, $userId]);
    return true;
}

function hnim_block_remove(int $userId, int $targetId, ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('DELETE FROM blocks WHERE user_id = ? AND block_id = ?');
    $st->execute([$userId, $targetId]);
    return $st->rowCount() > 0;
}

/** 我拉黑的人 */
function hnim_block_list(int $userId, ?PDO $pdo = null): array
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare(
        'SELECT b.created_at AS blocked_at, u.*
         FROM blocks b
         JOIN users u ON u.id = b.block_id
         WHERE b.user_id = ?
         ORDER BY b.created_at DESC'
    );
    $st->execute([$userId]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $pub = hnim_user_public($r);
        $pub['time'] = (int) $r['blocked_at'];
        $out[] = $pub;
    }
    return $out;
}

/* ================================================================== *
 *  好友分组
 * ================================================================== */

/** 我的好友分组（带每组人数） */
function hnim_fgroup_list(int $userId, ?PDO $pdo = null): array
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare(
        'SELECT g.id, g.name, g.sort_no, g.created_at,
                (SELECT COUNT(*) FROM friends f WHERE f.user_id = g.user_id AND f.group_id = g.id AND f.status = 1) AS n
         FROM friend_groups g
         WHERE g.user_id = ?
         ORDER BY g.sort_no ASC, g.id ASC'
    );
    $st->execute([$userId]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $out[] = [
            'id'    => (int) $r['id'],
            'name'  => (string) $r['name'],
            'count' => (int) $r['n'],
        ];
    }
    return $out;
}

/**
 * 新建分组，返回新 id；同名就返回已存在的那个（避免重复建出两个同名组）
 */
function hnim_fgroup_create(int $userId, string $name, ?PDO $pdo = null): int
{
    $pdo = $pdo ?: hnim_db();
    $name = trim($name);
    if ($name === '') {
        return 0;
    }
    $st = $pdo->prepare('SELECT id FROM friend_groups WHERE user_id = ? AND name = ?');
    $st->execute([$userId, $name]);
    $id = $st->fetchColumn();
    if ($id !== false) {
        return (int) $id;
    }
    $st = $pdo->prepare('SELECT COALESCE(MAX(sort_no), 0) + 1 FROM friend_groups WHERE user_id = ?');
    $st->execute([$userId]);
    $sort = (int) $st->fetchColumn();
    $st = $pdo->prepare('INSERT INTO friend_groups (user_id, name, sort_no, created_at) VALUES (?,?,?,?)');
    $st->execute([$userId, $name, $sort, time()]);
    return (int) $pdo->lastInsertId();
}

/** 改分组名 */
function hnim_fgroup_rename(int $userId, int $groupId, string $name, ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    $name = trim($name);
    if ($name === '') {
        return false;
    }
    $st = $pdo->prepare('UPDATE friend_groups SET name = ? WHERE id = ? AND user_id = ?');
    $st->execute([$name, $groupId, $userId]);
    return $st->rowCount() > 0;
}

/**
 * 删分组。好友不会被删，只是退回“未分组”（group_id = 0）。
 */
function hnim_fgroup_delete(int $userId, int $groupId, ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    $st = $pdo->prepare('UPDATE friends SET group_id = 0 WHERE user_id = ? AND group_id = ?');
    $st->execute([$userId, $groupId]);
    $st = $pdo->prepare('DELETE FROM friend_groups WHERE id = ? AND user_id = ?');
    $st->execute([$groupId, $userId]);
    return $st->rowCount() > 0;
}

/** 把好友挪到某个分组。分组不存在或不属于我就返回 false */
function hnim_friend_move(int $userId, int $friendId, int $groupId, ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    if ($groupId > 0) {
        $st = $pdo->prepare('SELECT COUNT(*) FROM friend_groups WHERE id = ? AND user_id = ?');
        $st->execute([$groupId, $userId]);
        if ((int) $st->fetchColumn() < 1) {
            return false;
        }
    }
    $st = $pdo->prepare('UPDATE friends SET group_id = ? WHERE user_id = ? AND friend_id = ?');
    $st->execute([$groupId, $userId, $friendId]);
    return $st->rowCount() > 0;
}

/* ================================================================== *
 *  聊天记录搜索
 * ================================================================== */

/**
 * 在一个会话里搜关键词。
 * 只搜我有权看的会话，且强制跳过已撤回消息的正文（已清空）。
 */
function hnim_message_search(int $userId, int $convId, string $keyword, int $limit = 40, ?PDO $pdo = null): array
{
    $acc  = $pdo ?: hnim_db();
    $chat = hnim_chat_db();
    if (!hnim_is_member($convId, $userId, $chat)) {
        return [];
    }
    $kw = trim($keyword);
    if ($kw === '') {
        return [];
    }
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $kw) . '%';
    $limit = max(1, min($limit, 100));

    $st = $chat->prepare(
        'SELECT m.*, cm.card AS sender_card
         FROM messages m
         LEFT JOIN conversation_members cm ON cm.conversation_id = m.conversation_id AND cm.user_id = m.sender_id
         WHERE m.conversation_id = ? AND m.recalled_at = 0 AND m.content LIKE ?
         ORDER BY m.id DESC
         LIMIT ' . $limit
    );
    $st->execute([$convId, $like]);
    $rows = $st->fetchAll();
    hnim_attach_senders($rows, 'sender_id', $acc);

    return array_map(
        static function ($r) use ($userId) {
            return hnim_message_public($r, $userId);
        },
        $rows
    );
}

/* ================================================================== *
 *  群聊
 * ================================================================== */

function hnim_group_create(int $ownerId, string $title, array $memberIds = [], ?PDO $pdo = null): int
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('INSERT INTO conversations (type, gno, title, owner_id, created_at) VALUES (?,?,?,?,?)');
    $st->execute(['group', hnim_generate_gno($pdo), $title, $ownerId, time()]);
    $cid = (int) $pdo->lastInsertId();

    $add = $pdo->prepare('INSERT OR IGNORE INTO conversation_members (conversation_id, user_id, joined_at, role) VALUES (?,?,?,?)');
    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) !== 'sqlite') {
        $add = $pdo->prepare('INSERT IGNORE INTO conversation_members (conversation_id, user_id, joined_at, role) VALUES (?,?,?,?)');
    }
    $add->execute([$cid, $ownerId, time(), 'owner']);
    foreach ($memberIds as $m) {
        $m = (int) $m;
        if ($m > 0 && hnim_user_by_id($m)) {
            $add->execute([$cid, $m, time(), 'member']);
        }
    }
    $owner = hnim_user_by_id($ownerId);
    hnim_send_message($cid, $ownerId, 'system', ($owner['nickname'] ?? ('用户' . $ownerId)) . ' 创建了群「' . $title . '」', [], $pdo);
    return $cid;
}

/** 群昵称（优先 remark，其次 nickname，最后 username） */
function hnim_group_nick(int $userId, ?PDO $pdo = null): string
{
    $u = hnim_user_by_id($userId);
    if (!$u) {
        return '用户' . $userId;
    }
    return (string) ($u['nickname'] !== '' ? $u['nickname'] : $u['username']);
}

/**
 * 彻底删除一个用户（后台用）。
 * 账号库清好友 / 黑名单 / 分组 / 登录日志；
 * 聊天库清会话成员关系 / 收藏 / 入群申请；他发的消息保留（会话记录不塌），
 * 但发送者会显示成“已注销用户”；自己建的群转给最早加入的其他成员，
 * 群里只剩他自己就解散。
 */
function hnim_user_purge(int $userId): void
{
    if ($userId <= 0) {
        return;
    }
    $acc  = hnim_db();
    $chat = hnim_chat_db();

    try {
        $acc->prepare('DELETE FROM friends WHERE user_id = ? OR friend_id = ?')->execute([$userId, $userId]);
        $acc->prepare('DELETE FROM blocks  WHERE user_id = ? OR block_id = ?')->execute([$userId, $userId]);
        $acc->prepare('DELETE FROM friend_groups WHERE user_id = ?')->execute([$userId]);
        $acc->prepare('DELETE FROM login_log WHERE user_id = ?')->execute([$userId]);
        $acc->prepare('DELETE FROM email_codes WHERE email = (SELECT email FROM users WHERE id = ?)')->execute([$userId]);
    } catch (Throwable $e) {
        error_log('[hnim] purge account data: ' . $e->getMessage());
    }

    try {
        // 自己建的群：有别人就转让，没别人就解散
        $st = $chat->prepare("SELECT id FROM conversations WHERE type = 'group' AND owner_id = ?");
        $st->execute([$userId]);
        foreach ($st->fetchAll() as $c) {
            $cid = (int) $c['id'];
            $st2 = $chat->prepare('SELECT user_id FROM conversation_members WHERE conversation_id = ? AND user_id <> ? ORDER BY user_id ASC LIMIT 1');
            $st2->execute([$cid, $userId]);
            $heir = (int) $st2->fetchColumn();
            if ($heir > 0) {
                $chat->prepare("UPDATE conversations SET owner_id = ? WHERE id = ?")->execute([$heir, $cid]);
                $chat->prepare("UPDATE conversation_members SET role = 'owner' WHERE conversation_id = ? AND user_id = ?")->execute([$cid, $heir]);
            } else {
                $chat->prepare('DELETE FROM messages WHERE conversation_id = ?')->execute([$cid]);
                $chat->prepare('DELETE FROM conversation_members WHERE conversation_id = ?')->execute([$cid]);
                $chat->prepare('DELETE FROM group_requests WHERE conversation_id = ?')->execute([$cid]);
                $chat->prepare('DELETE FROM favorites WHERE message_id IN (SELECT id FROM messages WHERE conversation_id = ?)')->execute([$cid]);
                $chat->prepare('DELETE FROM conversations WHERE id = ?')->execute([$cid]);
            }
        }

        $chat->prepare('DELETE FROM favorites WHERE user_id = ?')->execute([$userId]);
        $chat->prepare('DELETE FROM group_requests WHERE user_id = ?')->execute([$userId]);
        $chat->prepare('DELETE FROM typing_state WHERE user_id = ?')->execute([$userId]);
        $chat->prepare('DELETE FROM conversation_members WHERE user_id = ?')->execute([$userId]);
    } catch (Throwable $e) {
        error_log('[hnim] purge chat data: ' . $e->getMessage());
    }

    $acc->prepare('DELETE FROM users WHERE id = ?')->execute([$userId]);
}

/** 往群里写一条系统提示 */
function hnim_group_sys(int $convId, string $text, ?PDO $pdo = null): void
{
    hnim_send_message($convId, 0, 'system', $text, [], $pdo);
}

/**
 * 群身份等级：owner(群主) > admin(管理员) > member(普通成员)
 */
function hnim_group_rank(string $role): int
{
    return ['member' => 1, 'admin' => 2, 'owner' => 3][$role] ?? 0;
}

/** 我在某个群里的身份，非成员返回空串 */
function hnim_my_role(int $convId, int $userId, ?PDO $pdo = null): string
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT role FROM conversation_members WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$convId, $userId]);
    $r = $st->fetchColumn();
    return $r === false ? '' : (string) $r;
}

/** 是否群管理员及以上 */
function hnim_is_manager(int $convId, int $userId, ?PDO $pdo = null): bool
{
    return hnim_group_rank(hnim_my_role($convId, $userId, $pdo)) >= 2;
}

/**
 * 我在某个会话里能不能发言。
 * 返回 null 表示可以；返回字符串表示不能发言的原因（前端直接显示）。
 */
function hnim_send_block(int $convId, int $userId, ?PDO $pdo = null): ?string
{
    $pdo = hnim_chat_pdo($pdo);
    $c = hnim_conv_by_id($convId, $pdo);
    if (!$c) {
        return '会话不存在';
    }
    $role = hnim_my_role($convId, $userId, $pdo);
    if ($role === '') {
        return '你不在这个会话中';
    }
    if ((string) $c['type'] !== 'group') {
        return null;
    }
    // 群主和管理员不受任何禁言限制
    if (hnim_group_rank($role) >= 2) {
        return null;
    }
    $st = $pdo->prepare('SELECT mute_until FROM conversation_members WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$convId, $userId]);
    $until = (int) $st->fetchColumn();
    if ($until > time()) {
        if ($until >= 4102444800) {   // 2100-01-01 视为永久
            return '你已被管理员禁言，无法发言';
        }
        $left = $until - time();
        if ($left < 3600) {
            return '你已被禁言，还剩 ' . max(1, (int) round($left / 60)) . ' 分钟';
        }
        if ($left < 86400) {
            return '你已被禁言，还剩 ' . (int) round($left / 3600) . ' 小时';
        }
        return '你已被禁言，还剩 ' . (int) round($left / 86400) . ' 天';
    }
    if ((int) ($c['all_muted'] ?? 0) === 1) {
        return '群主已开启全员禁言';
    }
    return null;
}

/**
 * 群资料：标题、公告、群主、我的身份、成员数、我能做什么
 * 前端按 can_* 决定按钮显示，服务端另行校验，前端被改也没用。
 */
function hnim_group_info(int $convId, int $viewerId, ?PDO $pdo = null): ?array
{
    $pdo = $pdo ?: hnim_db();
    $c = hnim_conv_by_id($convId, $pdo);
    if (!$c || (string) $c['type'] !== 'group' || !hnim_is_member($convId, $viewerId, $pdo)) {
        return null;
    }
    $role = hnim_my_role($convId, $viewerId, $pdo);
    $rank = hnim_group_rank($role);
    return [
        'id'           => $convId,
        'title'        => (string) $c['title'],
        'avatar'       => (string) $c['avatar'],
        'gno'          => $c['gno'] === null ? '' : (string) $c['gno'],
        'announcement' => (string) ($c['announcement'] ?? ''),
        'owner_id'     => (int) $c['owner_id'],
        'all_muted'    => (int) ($c['all_muted'] ?? 0) === 1,
        'member_count' => hnim_conv_member_count($convId, $pdo),
        'my_role'      => $role,
        'is_owner'     => $role === 'owner',
        'is_admin'     => $role === 'admin',
        'is_manager'   => $rank >= 2,
        'muted_until'  => hnim_mute_until($convId, $viewerId, $pdo),
        'requests'     => $rank >= 2 ? hnim_group_requests($convId, $pdo) : [],
        'can_manage'   => [
            'rename'     => $rank >= 3,
            'notice'     => $rank >= 3,
            'avatar'     => $rank >= 3,
            'all_muted'  => $rank >= 3,
            'kick'       => $rank >= 2,
            'mute'       => $rank >= 2,
            'set_admin'  => $rank >= 3,
            'recall'     => $rank >= 2,
            'approve'    => $rank >= 2,
            'disband'    => $rank >= 3,
            'leave'      => $rank < 3,
        ],
    ];
}

/** 我的禁言截止时间，0 表示没被禁言 */
function hnim_mute_until(int $convId, int $userId, ?PDO $pdo = null): int
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT mute_until FROM conversation_members WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$convId, $userId]);
    $v = (int) $st->fetchColumn();
    return $v > time() ? $v : 0;
}

/** 改群名（仅群主） */
function hnim_group_rename(int $convId, int $userId, string $title, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $title = trim($title);
    if ($title === '') {
        return false;
    }
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_owner']) {
        return false;
    }
    $st = $pdo->prepare('UPDATE conversations SET title = ? WHERE id = ?');
    $st->execute([$title, $convId]);
    hnim_group_sys($convId, hnim_group_nick($userId, $pdo) . ' 把群名改成了「' . $title . '」', $pdo);
    return true;
}

/** 设置 / 清除群公告（仅群主） */
function hnim_group_set_notice(int $convId, int $userId, string $text, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_owner']) {
        return false;
    }
    $text = trim($text);
    $st = $pdo->prepare('UPDATE conversations SET announcement = ? WHERE id = ?');
    $st->execute([$text, $convId]);
    hnim_group_sys(
        $convId,
        $text === ''
            ? hnim_group_nick($userId, $pdo) . ' 清除了群公告'
            : hnim_group_nick($userId, $pdo) . ' 更新了群公告',
        $pdo
    );
    return true;
}

/** 转让群主（仅群主，且目标必须已在群中） */
function hnim_group_transfer(int $convId, int $userId, int $targetId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_owner'] || $targetId === $userId) {
        return false;
    }
    if (!hnim_is_member($convId, $targetId, $pdo)) {
        return false;
    }
    $st = $pdo->prepare('UPDATE conversation_members SET role = ? WHERE conversation_id = ? AND user_id = ?');
    $st->execute(['member', $convId, $userId]);
    $st->execute(['owner', $convId, $targetId]);
    $st = $pdo->prepare('UPDATE conversations SET owner_id = ? WHERE id = ?');
    $st->execute([$targetId, $convId]);
    hnim_group_sys(
        $convId,
        hnim_group_nick($userId, $pdo) . ' 把群主转让给了 ' . hnim_group_nick($targetId, $pdo),
        $pdo
    );
    return true;
}

/**
 * 踢出成员（群管理员及以上）。
 * 只能踢比自己权限低的人：管理员踢不了管理员和群主，群主谁都能踢（但不能踢自己）。
 */
function hnim_group_kick(int $convId, int $userId, int $targetId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_manager'] || $targetId === $userId) {
        return false;
    }
    if (!hnim_is_member($convId, $targetId, $pdo)) {
        return false;
    }
    if (hnim_group_rank(hnim_my_role($convId, $targetId, $pdo)) >= hnim_group_rank($info['my_role'])) {
        return false;   // 不能踢平级或上级
    }
    $st = $pdo->prepare('DELETE FROM conversation_members WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$convId, $targetId]);
    hnim_group_sys($convId, hnim_group_nick($userId, $pdo) . ' 把 ' . hnim_group_nick($targetId, $pdo) . ' 移出了群聊', $pdo);
    return true;
}

/** 退群。群主不能直接退，必须先转让或解散。 */
function hnim_group_leave(int $convId, int $userId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info) {
        return false;
    }
    if ($info['is_owner']) {
        return false;
    }
    $st = $pdo->prepare('DELETE FROM conversation_members WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$convId, $userId]);
    hnim_group_sys($convId, hnim_group_nick($userId, $pdo) . ' 退出了群聊', $pdo);
    return true;
}

/** 解散群（仅群主） */
function hnim_group_disband(int $convId, int $userId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_owner']) {
        return false;
    }
    hnim_group_sys($convId, hnim_group_nick($userId, $pdo) . ' 解散了该群聊', $pdo);
    $st = $pdo->prepare('DELETE FROM conversation_members WHERE conversation_id = ?');
    $st->execute([$convId]);
    $st = $pdo->prepare('DELETE FROM conversations WHERE id = ?');
    $st->execute([$convId]);
    return true;
}

function hnim_group_add_member(int $convId, int $userId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    if (hnim_is_member($convId, $userId, $pdo)) {
        return false;   // 已在群中
    }
    try {
        $st = $pdo->prepare('INSERT INTO conversation_members (conversation_id, user_id, joined_at, role) VALUES (?,?,?,?)');
        $st->execute([$convId, $userId, time(), 'member']);
    } catch (Throwable $e) {
        return false;
    }
    $u = hnim_user_by_id($userId);
    hnim_send_message($convId, 0, 'system', ($u['nickname'] ?? ('用户' . $userId)) . ' 加入了群聊', [], $pdo);
    return true;
}

/* =========================================================
 *  禁言 / 管理员 / 群名片 / 群头像
 * ======================================================= */

/**
 * 禁言时长档位（分钟）。0 表示解除禁言。
 */
function hnim_mute_options(): array
{
    return [
        10    => '10 分钟',
        60    => '1 小时',
        360   => '6 小时',
        1440  => '1 天',
        10080 => '7 天',
        0     => '解除禁言',
    ];
}

/**
 * 禁言 / 解除某个成员（群管理员及以上）。
 * 不能禁言比自己权限高的人；群主和管理员本身也不可被禁言。
 *
 * @param int $minutes 禁言分钟数，0 表示解除
 */
function hnim_group_mute_member(int $convId, int $userId, int $targetId, int $minutes, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_manager']) {
        return false;
    }
    if (!hnim_is_member($convId, $targetId, $pdo)) {
        return false;
    }
    $tRole = hnim_my_role($convId, $targetId, $pdo);
    if ($tRole === '') {
        return false;
    }
    if (hnim_group_rank($tRole) >= 2) {
        return false;   // 管理员和群主不可被禁言
    }
    if ($minutes === 0) {
        $st = $pdo->prepare('UPDATE conversation_members SET mute_until = 0 WHERE conversation_id = ? AND user_id = ?');
        $st->execute([$convId, $targetId]);
        hnim_group_sys(
            $convId,
            hnim_group_nick($userId, $pdo) . ' 解除了对 ' . hnim_group_nick($targetId, $pdo) . ' 的禁言',
            $pdo
        );
        return true;
    }

    // 最长 30 天，防止有人拿“永久”当噱头把人永久踢出沉默状态
    $minutes = min($minutes, 43200);
    $until   = time() + $minutes * 60;
    $st = $pdo->prepare('UPDATE conversation_members SET mute_until = ? WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$until, $convId, $targetId]);
    hnim_group_sys(
        $convId,
        hnim_group_nick($userId, $pdo) . ' 禁言了 ' . hnim_group_nick($targetId, $pdo) . '（' . hnim_mute_text($minutes) . '）',
        $pdo
    );
    return true;
}

/** 把分钟数说成人话 */
function hnim_mute_text(int $minutes): string
{
    if ($minutes <= 0) {
        return '已解除';
    }
    if ($minutes % 10080 === 0) {
        return intdiv($minutes, 10080) . ' 天';
    }
    if ($minutes % 1440 === 0) {
        return intdiv($minutes, 1440) . ' 天';
    }
    if ($minutes % 60 === 0) {
        return intdiv($minutes, 60) . ' 小时';
    }
    return $minutes . ' 分钟';
}

/** 开启 / 关闭全员禁言（仅群主）。开启后只有管理员以上能发言。 */
function hnim_group_all_mute(int $convId, int $userId, bool $on, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_owner']) {
        return false;
    }
    $st = $pdo->prepare('UPDATE conversations SET all_muted = ? WHERE id = ?');
    $st->execute([$on ? 1 : 0, $convId]);
    hnim_group_sys($convId, hnim_group_nick($userId, $pdo) . ($on ? ' 开启了全员禁言' : ' 关闭了全员禁言'), $pdo);
    return true;
}

/** 设置 / 取消群管理员（仅群主） */
function hnim_group_set_admin(int $convId, int $userId, int $targetId, bool $on, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_owner'] || $targetId === $userId) {
        return false;
    }
    if (!hnim_is_member($convId, $targetId, $pdo)) {
        return false;
    }
    $role = $on ? 'admin' : 'member';
    $st = $pdo->prepare('UPDATE conversation_members SET role = ? WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$role, $convId, $targetId]);
    hnim_group_sys(
        $convId,
        hnim_group_nick($userId, $pdo) . ($on ? ' 设置 ' : ' 取消了 ') . hnim_group_nick($targetId, $pdo) . ' 的管理员',
        $pdo
    );
    return true;
}

/** 改自己的群名片（任何成员都能改自己的） */
function hnim_group_set_card(int $convId, int $userId, string $card, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    if (!hnim_is_member($convId, $userId, $pdo)) {
        return false;
    }
    $card = trim($card);
    $st = $pdo->prepare('UPDATE conversation_members SET card = ? WHERE conversation_id = ? AND user_id = ?');
    $st->execute([$card, $convId, $userId]);
    return true;
}

/** 改群头像（仅群主），传的是已上传文件的相对路径 */
function hnim_group_set_avatar(int $convId, int $userId, string $avatar, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $info = hnim_group_info($convId, $userId, $pdo);
    if (!$info || !$info['is_owner']) {
        return false;
    }
    $avatar = trim($avatar);
    if (!preg_match('#^uploads/[A-Za-z0-9_.\-]+$#', $avatar)) {
        return false;
    }
    $st = $pdo->prepare('UPDATE conversations SET avatar = ? WHERE id = ?');
    $st->execute([$avatar, $convId]);
    hnim_group_sys($convId, hnim_group_nick($userId, $pdo) . ' 修改了群头像', $pdo);
    return true;
}

/* =========================================================
 *  消息撤回
 * ======================================================= */

/** 撤回时间上限：自己发的 2 分钟，管理员替别人撤 5 分钟 */
function hnim_recall_limit(bool $isManager): int
{
    return $isManager ? 300 : 120;
}

/**
 * 撤回一条消息。
 * - 只能撤自己发的（或管理员撤群内任意人的）
 * - 有时间限制
 * - 只能撤还没被撤过的
 */
function hnim_message_recall(int $msgId, int $userId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT * FROM messages WHERE id = ?');
    $st->execute([$msgId]);
    $m = $st->fetch();
    if (!$m || (int) $m['sender_id'] === 0) {
        return false;                      // 系统消息不可撤回
    }
    if ((int) ($m['recalled_at'] ?? 0) > 0) {
        return false;                      // 已经撤过了
    }
    $cid  = (int) $m['conversation_id'];
    $mine = (int) $m['sender_id'] === $userId;

    $isManager = false;
    $c = hnim_conv_by_id($cid, $pdo);
    if ($c && (string) $c['type'] === 'group') {
        $isManager = hnim_is_manager($cid, $userId, $pdo);
    }
    if (!$mine && !$isManager) {
        return false;
    }
    if ((time() - (int) $m['created_at']) > hnim_recall_limit($isManager)) {
        return false;
    }
    $st = $pdo->prepare('UPDATE messages SET recalled_at = ? WHERE id = ? AND recalled_at = 0');
    $st->execute([time(), $msgId]);
    if ($st->rowCount() < 1) {
        return false;
    }
    // 清掉正文与附件，只留一条“这个位置曾经有消息”的壳子
    $st = $pdo->prepare("UPDATE messages SET content = '', type = 'recalled', meta = '' WHERE id = ?");
    $st->execute([$msgId]);

    if ($c && (string) $c['type'] === 'group') {
        hnim_group_sys(
            $cid,
            $mine
                ? hnim_group_nick($userId, $pdo) . ' 撤回了一条消息'
                : hnim_group_nick($userId, $pdo) . ' 撤回了 ' . hnim_group_nick((int) $m['sender_id'], $pdo) . ' 的一条消息',
            $pdo
        );
    }
    return true;
}

/** 消息能否被当前用户撤回（前端决定要不要显示“撤回”） */
function hnim_can_recall(array $m, int $userId, ?PDO $pdo = null): bool
{
    $pdo = $pdo ?: hnim_db();
    if ((int) ($m['recalled_at'] ?? 0) > 0 || (int) ($m['sender'] ?? 0) === 0) {
        return false;
    }
    $mine = (int) ($m['sender'] ?? 0) === $userId;
    $isManager = false;
    $cid = (int) ($m['conv'] ?? 0);
    $c = hnim_conv_by_id($cid, $pdo);
    if ($c && (string) $c['type'] === 'group') {
        $isManager = hnim_is_manager($cid, $userId, $pdo);
    }
    if (!$mine && !$isManager) {
        return false;
    }
    return (time() - (int) ($m['created_at'] ?? 0)) <= hnim_recall_limit($isManager);
}

/** 群成员资料 */
function hnim_group_members(int $convId, ?PDO $pdo = null): array
{
    $acc  = $pdo ?: hnim_db();
    $chat = hnim_chat_db();
    // 成员关系在聊天库、用户资料在账号库，两个库不能 JOIN，所以分两步取
    $st = $chat->prepare(
        "SELECT user_id, role AS group_role, mute_until AS m_mute_until, card AS m_card
         FROM conversation_members
         WHERE conversation_id = ?
         ORDER BY (role = 'owner') DESC, (role = 'admin') DESC, user_id ASC"
    );
    $st->execute([$convId]);
    $rows = $st->fetchAll();
    if (!$rows) {
        return [];
    }
    hnim_attach_users($rows, 'user_id', $acc);

    $now = time();
    $out = [];
    foreach ($rows as $r) {
        $pub = hnim_public_member($r);
        $pub['group_role'] = (string) $r['group_role'];
        $card = (string) $r['m_card'];
        $pub['card'] = $card;
        $pub['display'] = $card !== '' ? $card : $pub['display'];
        $until = (int) $r['m_mute_until'];
        $pub['mute_until'] = $until > $now ? $until : 0;
        $out[] = $pub;
    }
    return $out;
}


/* ================================================================== *
 *  上传
 * ================================================================== */

/**
 * 保存上传文件到 uploads 目录（相对根目录，随程序走）
 * @return array{ok:bool,path?:string,name?:string,size?:int,error?:string}
 */
function hnim_store_upload(array $file, string $kind, ?PDO $pdo = null): array
{
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['ok' => false, 'error' => '上传参数错误'];
    }
    switch ($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return ['ok' => false, 'error' => '文件超出服务器允许的大小'];
        case UPLOAD_ERR_NO_FILE:
            return ['ok' => false, 'error' => '没有选择文件'];
        default:
            return ['ok' => false, 'error' => '文件上传失败（code ' . $file['error'] . '）'];
    }

    $maxBytes = (int) hnim_config('upload.max_mb', 50) * 1024 * 1024;
    if (($file['size'] ?? 0) > $maxBytes) {
        return ['ok' => false, 'error' => '文件超过 ' . hnim_config('upload.max_mb', 50) . 'MB 限制'];
    }

    $sub  = $kind === 'image' ? 'img' : 'file';
    $dir  = HNIM_UPLOADS . '/' . $sub;
    if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
        return ['ok' => false, 'error' => '无法创建上传目录：' . $dir];
    }

    $orig = (string) ($file['name'] ?? 'file');
    $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $ext  = preg_match('/^[a-z0-9]{1,8}$/', $ext) ? $ext : '';

    if ($kind === 'image' && !in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], true)) {
        return ['ok' => false, 'error' => '仅支持 jpg/png/gif/webp 图片'];
    }

    $name = date('Ymd') . '_' . bin2hex(random_bytes(8)) . ($ext ? '.' . $ext : '');
    $dest = $dir . '/' . $name;

    $moved = is_uploaded_file($file['tmp_name'])
        ? @move_uploaded_file($file['tmp_name'], $dest)
        : @rename($file['tmp_name'], $dest);

    if (!$moved) {
        return ['ok' => false, 'error' => '保存文件失败'];
    }
    @chmod($dest, 0600);

    $safeName = hnim_str($orig, 'file', 120);
    $safeName = str_replace(["\r", "\n", "\0", '"'], '', $safeName);

    if ($kind === 'image') {
        // 记录一次校验信息，便于排查异常文件
        $info = @getimagesize($dest);
        return [
            'ok'   => true,
            'path' => 'uploads/img/' . $name,
            'name' => $safeName,
            'size' => (int) $file['size'],
            'w'    => $info ? (int) $info[0] : 0,
            'h'    => $info ? (int) $info[1] : 0,
        ];
    }
    return [
        'ok'   => true,
        'path' => 'uploads/file/' . $name,
        'name' => $safeName,
        'size' => (int) $file['size'],
    ];
}

/* ================================================================== *
 *  时间格式化
 * ================================================================== */

function hnim_time_text(int $ts, ?int $now = null): string
{
    $now = $now ?: time();
    $d0  = date('Y-m-d', $now);
    $d1  = date('Y-m-d', $ts);
    if ($d1 === $d0) {
        return date('H:i', $ts);
    }
    if ($d1 === date('Y-m-d', $now - 86400)) {
        return '昨天 ' . date('H:i', $ts);
    }
    if ($now - $ts < 7 * 86400) {
        return date('m-d', $ts);
    }
    return $d1;
}

function hnim_last_seen_text(int $ts): string
{
    if ($ts <= 0) {
        return '离线';
    }
    $diff = time() - $ts;
    if ($diff < 60)    return '在线';
    if ($diff < 3600)  return intdiv($diff, 60) . ' 分钟前';
    if ($diff < 86400) return intdiv($diff, 3600) . ' 小时前';
    if ($diff < 604800) return intdiv($diff, 86400) . ' 天前';
    return date('Y-m-d', $ts);
}
/* ================================================================== *
 *  聊天记录清理（后台「数据清理」，只有超管能进）
 * ================================================================== */

/**
 * 统计有多少条聊天记录早于 $cutoff。
 *
 * @return array{messages:int, conversations:int, from:int, to:int}
 */
function hnim_count_messages_before(int $cutoff, ?PDO $pdo = null): array
{
    $chat = hnim_chat_pdo($pdo);

    $st = $chat->prepare('SELECT COUNT(*) FROM messages WHERE created_at < ?');
    $st->execute([$cutoff]);
    $n = (int) $st->fetchColumn();

    $st = $chat->prepare('SELECT COUNT(DISTINCT conversation_id) FROM messages WHERE created_at < ?');
    $st->execute([$cutoff]);
    $c = (int) $st->fetchColumn();

    $st = $chat->prepare('SELECT MIN(created_at), MAX(created_at) FROM messages WHERE created_at < ?');
    $st->execute([$cutoff]);
    $row = $st->fetch() ?: [null, null];

    return [
        'messages'      => $n,
        'conversations' => $c,
        'from'          => (int) ($row[0] ?? 0),
        'to'            => (int) ($row[1] ?? 0),
    ];
}

/**
 * 删除 $cutoff 之前的所有聊天记录。
 *
 * 半年份的记录可能是几百万条，一条 DELETE 扫全表会把 InnoDB 的表锁住
 * 好几分钟，线上聊天全卡住。所以按批删：
 *   DELETE FROM messages WHERE id IN (SELECT id FROM messages WHERE created_at < ? LIMIT n)
 * 这个写法 MySQL 和 SQLite 都支持（DELETE ... LIMIT 在 SQLite 上不一定编译进去，
 * 所以不直接用）。
 *
 * 删完顺手把 favorites 里指向已删消息的行清掉，否则用户点收藏会点到空消息。
 *
 * @param int $cutoff    早于这个时间戳（秒）的记录全部删除
 * @param int $batch     每批删多少条
 * @param int $maxBatches 最多跑多少批，防止一次请求跑太久被主机掐断
 * @return array{messages:int, favorites:int, batches:int, more:bool}
 */
function hnim_purge_messages_before(int $cutoff, ?PDO $pdo = null, int $batch = 2000, int $maxBatches = 400): array
{
    $chat = hnim_chat_pdo($pdo);
    $batch = max(1, min($batch, 20000));

    $sql = 'DELETE FROM messages WHERE id IN '
         . '(SELECT id FROM messages WHERE created_at < ? LIMIT ' . $batch . ')';

    $deleted  = 0;
    $batches  = 0;
    while ($batches < $maxBatches) {
        $st = $chat->prepare($sql);
        $st->execute([$cutoff]);
        $n = (int) $st->rowCount();
        $batches++;
        if ($n <= 0) {
            $batches--;          // 这次没删到，说明已经删干净了
            break;
        }
        $deleted += $n;
        if ($n < $batch) {
            break;               // 最后一批不满，也算删完了
        }
    }

    // 收藏里指向已不存在消息的行
    $favDeleted = 0;
    try {
        $favDeleted = (int) $chat
            ->exec('DELETE FROM favorites WHERE message_id NOT IN (SELECT id FROM messages)')
            ->rowCount();
    } catch (Throwable $e) {
        error_log('[hnim] purge favorites failed: ' . $e->getMessage());
    }

    // 还会不会有剩余：刚好把 maxBatches 跑满、且最后一批是满的，就说明没删干净
    $more = ($batches >= $maxBatches);
    if ($more) {
        $st = $chat->prepare('SELECT 1 FROM messages WHERE created_at < ? LIMIT 1');
        $st->execute([$cutoff]);
        $more = (bool) $st->fetchColumn();
    }

    return [
        'messages'  => $deleted,
        'favorites' => $favDeleted,
        'batches'   => $batches,
        'more'      => $more,
    ];
}

/* ================================================================== *
 *  群号
 * ================================================================== */
/**
 * 生成一个没被占用的群号（QQ 那种 6~11 位数字，这里用 9 位随机数）。
 * 撞了就重摇，最多 40 次；还撞就退回用会话 id 拼一个保底的。
 */
function hnim_generate_gno(?PDO $pdo = null): string
{
    $pdo = hnim_chat_pdo($pdo);
    $chk = $pdo->prepare('SELECT 1 FROM conversations WHERE gno = ?');

    for ($i = 0; $i < 40; $i++) {
        // 首位不取 0，看起来更像正经群号；也不会出现 100000000 这种整头数
        $gno = (string) random_int(100000001, 999999999);
        $chk->execute([$gno]);
        if ($chk->fetchColumn() === false) {
            return $gno;
        }
    }

    // 极端情况下（不可能，但要有兜底）用最大 id 派生
    $maxId = (int) ($pdo->query('SELECT MAX(id) FROM conversations')->fetchColumn() ?: 0);
    do {
        $gno = (string) (900000000 + $maxId + random_int(0, 999));
        $maxId++;
        $chk->execute([$gno]);
    } while ($chk->fetchColumn() !== false);

    return $gno;
}

/** 按群号找群，不存在返回 null */
function hnim_group_by_gno(string $gno, ?PDO $pdo = null): ?array
{
    $gno = trim($gno);
    if ($gno === '' || !ctype_digit($gno)) {
        return null;
    }
    $pdo = hnim_chat_pdo($pdo);
    $st  = $pdo->prepare("SELECT * FROM conversations WHERE gno = ? AND type = 'group'");
    $st->execute([$gno]);
    $r = $st->fetch();
    return $r ?: null;
}

/** 给老群补群号（升级时调用，只补 NULL/空的） */
function hnim_backfill_gno(?PDO $pdo = null): int
{
    $pdo = hnim_chat_pdo($pdo);
    $st  = $pdo->prepare("SELECT id FROM conversations WHERE type = 'group' AND (gno IS NULL OR gno = '')");
    $st->execute();
    $up  = $pdo->prepare('UPDATE conversations SET gno = ? WHERE id = ?');
    $n   = 0;
    foreach ($st->fetchAll() as $r) {
        $up->execute([hnim_generate_gno($pdo), (int) $r['id']]);
        $n++;
    }
    return $n;
}

/**
 * 搜群：群号（完整数字）或群名模糊匹配，只返回我还没进的群。
 * $mine 传 true 时连我已在的群一起返回（进群申请里要显示）。
 */
function hnim_group_search(int $userId, string $kw, int $limit = 20, ?PDO $pdo = null): array
{
    $kw = trim($kw);
    if ($kw === '') {
        return [];
    }
    $pdo = hnim_chat_pdo($pdo);
    $limit = max(1, min(50, $limit));

    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $kw) . '%';
    $st = $pdo->prepare(
        "SELECT c.*,
                (SELECT COUNT(*) FROM conversation_members m WHERE m.conversation_id = c.id) AS n,
                (SELECT m2.role FROM conversation_members m2 WHERE m2.conversation_id = c.id AND m2.user_id = ?) AS my_role
         FROM conversations c
         WHERE c.type = 'group'
           AND (c.title LIKE ? OR c.gno LIKE ?)
           AND NOT EXISTS (SELECT 1 FROM conversation_members m3
                           WHERE m3.conversation_id = c.id AND m3.user_id = ?)
         ORDER BY c.id ASC
         LIMIT {$limit}"
    );
    $st->execute([$userId, $like, $like, $userId]);

    $out = [];
    foreach ($st->fetchAll() as $r) {
        $out[] = [
            'id'      => (int) $r['id'],
            'gno'     => (string) ($r['gno'] ?? ''),
            'title'   => (string) $r['title'],
            'avatar'  => (string) $r['avatar'],
            'owner'   => (int) $r['owner_id'],
            'member_count' => (int) $r['n'],
            'announcement' => (string) ($r['announcement'] ?? ''),
        ];
    }
    return $out;
}

/* ================================================================== *
 *  入群申请
 * ================================================================== */

/** 申请加入群：已经在群里 / 已经申请过 / 群不存在，都返回 false */
function hnim_group_request(int $userId, int $convId, string $reason = '', ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $g = $pdo->prepare("SELECT id FROM conversations WHERE id = ? AND type = 'group'");
    $g->execute([$convId]);
    if ($g->fetchColumn() === false) {
        return false;
    }
    if (hnim_is_member($convId, $userId, $pdo)) {
        return false;
    }
    // 已有待处理的申请就不重复插
    $c = $pdo->prepare('SELECT 1 FROM group_requests WHERE conversation_id = ? AND user_id = ? AND status = 0');
    $c->execute([$convId, $userId]);
    if ($c->fetchColumn() !== false) {
        return false;
    }
    $st = $pdo->prepare(
        'INSERT INTO group_requests (conversation_id, user_id, reason, status, created_at)
         VALUES (?,?,?,0,?)'
    );
    $st->execute([$convId, $userId, hnim_str($reason, '', 120), time()]);
    hnim_group_sys($convId, hnim_group_nick($userId, $pdo) . ' 申请加入群聊', $pdo);
    return true;
}

/** 群主/管理员看到的入群申请列表 */
function hnim_group_requests(int $convId, ?PDO $pdo = null): array
{
    $acc  = $pdo ?: hnim_db();
    $chat = hnim_chat_db();
    // 申请单在聊天库、申请人资料在账号库，不能 JOIN，分两步取
    $st = $chat->prepare(
        'SELECT r.id AS req_id, r.user_id, r.reason, r.created_at AS req_at
         FROM group_requests r
         WHERE r.conversation_id = ? AND r.status = 0
         ORDER BY r.id ASC'
    );
    $st->execute([$convId]);
    $rows = $st->fetchAll();
    if (!$rows) {
        return [];
    }
    hnim_attach_users($rows, 'user_id', $acc);

    $out = [];
    foreach ($rows as $r) {
        $u = hnim_public_member($r);
        $u['req_id'] = (int) $r['req_id'];
        $u['reason'] = (string) $r['reason'];
        $u['time']   = (int) $r['req_at'];
        $out[] = $u;
    }
    return $out;
}

/** 我发出的、还在等审批的入群申请 */
function hnim_my_group_requests(int $userId, ?PDO $pdo = null): array
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare(
        'SELECT r.id, r.reason, r.created_at, c.id AS cid, c.title, c.gno
         FROM group_requests r
         JOIN conversations c ON c.id = r.conversation_id
         WHERE r.user_id = ? AND r.status = 0
         ORDER BY r.id DESC'
    );
    $st->execute([$userId]);
    return array_map(static function ($r) {
        return [
            'req_id' => (int) $r['id'],
            'cid'    => (int) $r['cid'],
            'title'  => (string) $r['title'],
            'gno'    => (string) ($r['gno'] ?? ''),
            'reason' => (string) $r['reason'],
            'time'   => (int) $r['created_at'],
        ];
    }, $st->fetchAll());
}

/**
 * 审批入群申请。只有群主/管理员能批；通过就拉进群，驳回就只记结果。
 * @return string '' 表示成功，否则是给用户看的原因
 */
function hnim_group_request_handle(int $reqId, int $actorId, bool $accept, ?PDO $pdo = null): string
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT * FROM group_requests WHERE id = ?');
    $st->execute([$reqId]);
    $r = $st->fetch();
    if (!$r) {
        return '申请不存在';
    }
    if ((int) $r['status'] !== 0) {
        return '这条申请已经处理过了';
    }
    $cid  = (int) $r['conversation_id'];
    $uid  = (int) $r['user_id'];
    $nick = hnim_group_nick($uid, $pdo);

    if (!hnim_is_manager($cid, $actorId, $pdo)) {
        return '只有群主和管理员能处理入群申请';
    }

    $up = $pdo->prepare('UPDATE group_requests SET status = ? WHERE id = ?');
    $up->execute([$accept ? 1 : 2, $reqId]);

    if ($accept) {
        // 万一期间已经被别的途径拉进来了，就别重复插
        if (!hnim_is_member($cid, $uid, $pdo)) {
            hnim_group_add_member($cid, $uid, $pdo);
        }
        hnim_group_sys($cid, $nick . ' 已加入群聊', $pdo);
    } else {
        hnim_group_sys($cid, $nick . ' 的入群申请被拒绝', $pdo);
    }
    return '';
}

/* ================================================================== *
 *  收藏
 * ================================================================== */

function hnim_favorite_add(int $userId, int $messageId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    // 先确认这条消息确实在自己待着的会话里
    $st = $pdo->prepare(
        'SELECT 1 FROM messages m
         JOIN conversation_members cm ON cm.conversation_id = m.conversation_id AND cm.user_id = ?
         WHERE m.id = ? AND m.recalled_at = 0'
    );
    $st->execute([$userId, $messageId]);
    if ($st->fetchColumn() === false) {
        return false;
    }
    $isSqlite = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
    $sql = $isSqlite
        ? 'INSERT INTO favorites (user_id, message_id, created_at) VALUES (?,?,?)
           ON CONFLICT(user_id, message_id) DO NOTHING'
        : 'INSERT IGNORE INTO favorites (user_id, message_id, created_at) VALUES (?,?,?)';
    $ins = $pdo->prepare($sql);
    $ins->execute([$userId, $messageId, time()]);
    return true;
}

function hnim_favorite_remove(int $userId, int $messageId, ?PDO $pdo = null): bool
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('DELETE FROM favorites WHERE user_id = ? AND message_id = ?');
    $st->execute([$userId, $messageId]);
    return $st->rowCount() > 0;
}

/** 我收藏过的消息 id 集合，用来给气泡打星 */
function hnim_favorite_ids(int $userId, ?PDO $pdo = null): array
{
    $pdo = hnim_chat_pdo($pdo);
    $st = $pdo->prepare('SELECT message_id FROM favorites WHERE user_id = ?');
    $st->execute([$userId]);
    return array_map('intval', array_column($st->fetchAll(), 'message_id'));
}

/** 收藏列表，带上会话标题方便分辨 */
function hnim_favorite_list(int $userId, int $limit = 100, ?PDO $pdo = null): array
{
    $acc  = $pdo ?: hnim_db();
    $chat = hnim_chat_db();
    $limit = max(1, min(200, $limit));
    // 收藏、消息、会话都在聊天库；只有发送者昵称在账号库，所以这里不 JOIN users
    $st = $chat->prepare(
        "SELECT f.message_id, f.created_at AS fav_at, m.*,
                cm.card AS sender_card,
                c.type AS ctype, c.title AS ctitle
         FROM favorites f
         JOIN messages m ON m.id = f.message_id
         JOIN conversations c ON c.id = m.conversation_id
         JOIN conversation_members cm ON cm.conversation_id = m.conversation_id AND cm.user_id = f.user_id
         WHERE f.user_id = ?
         ORDER BY f.id DESC
         LIMIT {$limit}"
    );
    $st->execute([$userId]);
    $rows = $st->fetchAll();
    if (!$rows) {
        return [];
    }
    hnim_attach_senders($rows, 'sender_id', $acc);

    $out = [];
    foreach ($rows as $r) {
        $pub = hnim_message_public($r, $userId, true);
        $pub['fav_at'] = (int) $r['fav_at'];
        $pub['conv_type'] = (string) $r['ctype'];
        if ($r['ctype'] === 'single') {
            [$a, $b] = array_map('intval', explode(':', (string) $r['ctitle']));
            $peerId = ($a === $userId) ? $b : $a;
            $pub['conv_title'] = hnim_group_nick($peerId, $acc);
        } else {
            $pub['conv_title'] = (string) $r['ctitle'];
        }
        $out[] = $pub;
    }
    return $out;
}

/* ================================================================== *
 *  快捷回复短语（存在用户签名之外的一个小集合，随程序走）
 * ================================================================== */

function hnim_phrase_list(?PDO $pdo = null): array
{
    return [
        '好的，收到。',
        '稍等，我看一下。',
        '不好意思，我这边马上处理。',
        '谢谢！',
        '这个我再确认一下，晚点回复你。',
    ];
}
