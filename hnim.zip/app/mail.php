<?php
/**
 * HNIM 邮件发送（纯 PHP socket 实现，不依赖 Composer / PHPMailer）
 * ------------------------------------------------------------------
 * 支持三种常见发信方式：
 *   - none : 不加密（一般用于内网邮件服务器，端口 25）
 *   - ssl  : 一上来就是 SSL 连接（QQ 邮箱 / 163 常用，端口 465）
 *   - tls  : 明文连接后用 STARTTLS 升级（端口 587）
 * 认证支持 AUTH LOGIN 和 AUTH PLAIN。
 *
 * 所有 SMTP 参数都存在 settings 表里，后台改完立即生效，不用改配置文件。
 */
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/* ================================================================== *
 *  配置读取 / 保存
 * ================================================================== */

/** 读取 SMTP 配置（带默认值，方便后台表单直接回填） */
function hnim_smtp_conf(): array
{
    return [
        'enabled'   => (string) hnim_setting('smtp.enabled', '0') === '1',
        'host'      => (string) hnim_setting('smtp.host', ''),
        'port'      => (int)    hnim_setting('smtp.port', 465),
        'user'      => (string) hnim_setting('smtp.user', ''),
        'pass'      => (string) hnim_setting('smtp.pass', ''),
        'secure'    => (string) hnim_setting('smtp.secure', 'ssl'),
        'from'      => (string) hnim_setting('smtp.from', ''),
        'from_name' => (string) hnim_setting('smtp.from_name', hnim_app_name()),
        'timeout'   => (int)    hnim_setting('smtp.timeout', 12),
    ];
}

/** 站点名（邮件标题里用） */
function hnim_app_name(): string
{
    $n = (string) hnim_config('app.name', '');
    return $n !== '' ? $n : 'HNIM';
}

/**
 * SMTP 是否已经配置好、可以直接发信。
 * 注册流程会用它来判断——没配好就不允许注册。
 */
function hnim_smtp_ready(): ?string
{
    $c = hnim_smtp_conf();
    if (!$c['enabled']) {
        return '管理员还没有开启邮件服务';
    }
    if ($c['host'] === '') {
        return '管理员还没有填写邮件服务器地址';
    }
    if ($c['user'] === '') {
        return '管理员还没有填写发信邮箱账号';
    }
    if ($c['pass'] === '') {
        return '管理员还没有填写邮箱授权码';
    }
    if ($c['from'] === '') {
        return '管理员还没有填写发件人邮箱';
    }
    return null;
}

/** 保存 SMTP 配置。$data 只包含要改的键，密码留空表示不改。 */
function hnim_smtp_save(array $data): void
{
    if (array_key_exists('enabled', $data)) {
        hnim_setting_set('smtp.enabled', $data['enabled'] ? '1' : '0');
    }
    foreach (['host', 'user', 'secure', 'from', 'from_name'] as $k) {
        if (array_key_exists($k, $data)) {
            hnim_setting_set('smtp.' . $k, trim((string) $data[$k]));
        }
    }
    if (array_key_exists('port', $data)) {
        $port = (int) $data['port'];
        hnim_setting_set('smtp.port', (string) ($port > 0 && $port <= 65535 ? $port : 465));
    }
    // 密码：空字符串表示“保持原样”，避免后台一保存就把授权码清掉
    if (array_key_exists('pass', $data) && (string) $data['pass'] !== '') {
        hnim_setting_set('smtp.pass', (string) $data['pass']);
    }
}

/* ================================================================== *
 *  SMTP 协议实现
 * ================================================================== */

/**
 * 简易 SMTP 客户端。
 * 内部类，只给 hnim_smtp_send() 用。
 */
final class HnimSmtp
{
    /** @var resource */
    private $fp;
    private string $last = '';

    public function __construct(
        private string $host,
        private int $port,
        private string $secure,
        private int $timeout = 12
    ) {
    }

    /** 建立连接 */
    public function connect(): void
    {
        $remote = ($this->secure === 'ssl' ? 'ssl://' : '') . $this->host . ':' . $this->port;
        $ctx = stream_context_create([
            'ssl' => [
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true,
            ],
        ]);
        $errno = 0;
        $errstr = '';
        $fp = @stream_socket_client(
            $remote,
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $ctx
        );
        if (!$fp) {
            throw new RuntimeException("连接邮件服务器失败（{$this->host}:{$this->port}）：{$errstr}");
        }
        $this->fp = $fp;
        stream_set_timeout($this->fp, $this->timeout);

        $this->expect(220, '服务器没有正常打招呼');
        $this->ehlo();
    }

    /** 读一行（含多行响应的续行处理） */
    private function read(): string
    {
        $data = '';
        while (($line = fgets($this->fp, 2048)) !== false) {
            $data .= $line;
            // SMTP 多行响应：第 4 个字符是 '-' 表示还有下一行
            if (strlen($line) < 4 || $line[3] !== '-') {
                break;
            }
        }
        $this->last = $data;
        return $data;
    }

    /** 读响应并校验状态码 */
    private function expect(int $code, string $friendly): void
    {
        $resp = $this->read();
        if ($resp === '') {
            throw new RuntimeException($friendly . '（服务器无响应）');
        }
        if ((int) substr($resp, 0, 3) !== $code) {
            throw new RuntimeException($friendly . '：' . trim($this->shorten($resp)));
        }
    }

    /** 发一条命令 */
    private function cmd(string $line): void
    {
        if (@fwrite($this->fp, $line . "\r\n") === false) {
            throw new RuntimeException('与邮件服务器的连接已断开');
        }
    }

    /** 只取响应里最有用的一行，别把整段退回信息糊到界面上 */
    private function shorten(string $resp): string
    {
        $lines = preg_split('/\r?\n/', trim($resp));
        $first = (string) ($lines[0] ?? '');
        return mb_substr($first, 0, 160, 'UTF-8');
    }

    private function ehlo(): void
    {
        $name = $_SERVER['SERVER_NAME'] ?? 'localhost';
        if ($name === '' || $name === 'localhost') {
            $name = 'hnim.local';
        }
        $this->cmd('EHLO ' . $name);
        try {
            $this->expect(250, '服务器拒绝了 EHLO');
        } catch (RuntimeException $e) {
            // 个别老服务器只认 HELO
            $this->cmd('HELO ' . $name);
            $this->expect(250, '服务器拒绝了 HELO');
        }

        if ($this->secure === 'tls') {
            $this->cmd('STARTTLS');
            $this->expect(220, '服务器不支持 STARTTLS 加密');
            $ok = @stream_socket_enable_crypto(
                $this->fp,
                true,
                STREAM_CRYPTO_METHOD_TLS_CLIENT
            );
            if ($ok !== true) {
                throw new RuntimeException('TLS 加密握手失败，请确认端口和加密方式是否匹配');
            }
            // 升级后重新 EHLO
            $this->cmd('EHLO ' . $name);
            $this->expect(250, '加密后 EHLO 失败');
        }
    }

    /** 登录（AUTH LOGIN，失败再试 AUTH PLAIN） */
    public function auth(string $user, string $pass): void
    {
        // 授权码一般是 16 位。明显偏短基本只有两种原因：复制没复制全，
        // 或者填了密码框但没点「保存设置」（测试邮件那个表单只带收件人，
        // 它用的是数据库里已存的那份）。与其让服务器回一句含糊的 535，
        // 不如这里就把话说清楚。
        $hint = '';
        if ($pass !== '' && strlen($pass) < 8) {
            $hint = '（当前只有 ' . strlen($pass) . ' 位，授权码通常是 16 位）';
        }

        $this->cmd('AUTH LOGIN');
        $resp = $this->read();
        if ((int) substr($resp, 0, 3) !== 334) {
            // 有些服务器不认 LOGIN，改用 PLAIN
            $this->cmd('AUTH PLAIN ' . base64_encode("\0" . $user . "\0" . $pass));
            $this->expect(235, $this->authErr($resp, $hint));
            return;
        }
        $this->cmd(base64_encode($user));
        $this->expect(334, '邮箱账号不正确');
        $this->cmd(base64_encode($pass));
        $this->expect(235, $this->authErr($resp, $hint));
    }

    /**
     * 认证失败的说明。
     *
     * 535 是「凭据被拒」，但服务器给的文案往往把几种完全不同的原因混在一句里
     * （QQ 就是：账号异常 / 服务未开启 / 密码错 / 频率限制 / 系统繁忙）。
     * 我们能确定的只有一件事：连接、TLS、EHLO 都过了，是密码那一步没过。
     */
    private function authErr(string $resp, string $hint = ''): string
    {
        $code = substr($resp, 0, 3);
        $msg  = '邮箱账号或授权码不正确' . $hint
              . '。QQ/163 邮箱要填网页版「设置 → 账户」里生成的『授权码』，不是登录密码。';

        if ($code === '535') {
            $low = strtolower($resp);
            // 把服务器自己列的原因里我们能对号入座的两条点名，省得用户瞎试
            if (str_contains($low, 'frequency') || str_contains($resp, '频率')) {
                $msg .= ' 若刚失败过好几次，可能是被限频了，等 10~30 分钟再试，别反复点测试。';
            }
            if (str_contains($low, 'not open') || str_contains($low, 'service is not')) {
                $msg .= ' 服务器说「服务未开启」——回邮箱网页版确认 SMTP 服务已开启。';
            }
        }
        return $msg;
    }

    /** 发一封信 */
    public function send(string $from, string $fromName, string $to, string $subject, string $html): void
    {
        $this->cmd('MAIL FROM:<' . $from . '>');
        $this->expect(250, '发件人被服务器拒绝');

        $this->cmd('RCPT TO:<' . $to . '>');
        $this->expect(250, '收件人被服务器拒绝');

        $this->cmd('DATA');
        $this->expect(354, '服务器拒绝接收邮件内容');

        $body = $this->buildMessage($from, $fromName, $to, $subject, $html);
        // 正文里的孤立点要转义，避免被当成结束标记
        $body = preg_replace('/^\./m', '..', $body);
        if (@fwrite($this->fp, $body . "\r\n.\r\n") === false) {
            throw new RuntimeException('发送邮件内容时连接中断');
        }
        $this->expect(250, '邮件被服务器退回');
    }

    /** 拼一封 MIME 邮件（UTF-8 + base64，中文不乱码） */
    private function buildMessage(string $from, string $fromName, string $to, string $subject, string $html): string
    {
        $b = chr(13) . chr(10);
        $h = [];
        $h[] = 'Date: ' . date('r');
        $h[] = 'From: ' . $this->encodeName($fromName) . ' <' . $from . '>';
        $h[] = 'To: <' . $to . '>';
        $h[] = 'Subject: ' . $this->encodeHeader($subject);
        $h[] = 'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $this->host . '>';
        $h[] = 'MIME-Version: 1.0';
        $h[] = 'Content-Type: text/html; charset=UTF-8';
        $h[] = 'Content-Transfer-Encoding: base64';
        return implode($b, $h) . $b . $b . chunk_split(base64_encode($html), 76, $b);
    }

    /** 标题按 RFC2047 编码（中文邮件标题必需） */
    private function encodeHeader(string $s): string
    {
        if (preg_match('/[\x80-\xFF]/', $s)) {
            return '=?UTF-8?B?' . base64_encode($s) . '?=';
        }
        return $s;
    }

    /** 发件人显示名编码 */
    private function encodeName(string $s): string
    {
        return $this->encodeHeader(str_replace(['<', '>', '"'], '', $s));
    }

    public function quit(): void
    {
        if (is_resource($this->fp)) {
            @fwrite($this->fp, "QUIT\r\n");
            @fclose($this->fp);
        }
    }
}

/* ================================================================== *
 *  对外接口
 * ================================================================== */

/**
 * 真正发一封信。
 * @return array{ok:bool,error?:string}
 */
function hnim_smtp_send(string $to, string $subject, string $html): array
{
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => '收件邮箱格式不对'];
    }
    $why = hnim_smtp_ready();
    if ($why !== null) {
        return ['ok' => false, 'error' => $why];
    }
    $c = hnim_smtp_conf();
    $from = $c['from'] !== '' ? $c['from'] : $c['user'];

    $smtp = new HnimSmtp($c['host'], $c['port'], $c['secure'], max(5, $c['timeout']));
    try {
        $smtp->connect();
        $smtp->auth($c['user'], $c['pass']);
        $smtp->send($from, $c['from_name'], $to, $subject, $html);
        $smtp->quit();
    } catch (Throwable $e) {
        try {
            $smtp->quit();
        } catch (Throwable $ignore) {
            // 收尾失败无所谓
        }
        return ['ok' => false, 'error' => $e->getMessage()];
    }
    return ['ok' => true];
}

/**
 * 后台“发送测试邮件”按钮用。
 * @return array{ok:bool,error?:string}
 */
function hnim_smtp_test(string $to): array
{
    return hnim_smtp_send(
        $to,
        '【' . hnim_app_name() . '】测试邮件',
        hnim_mail_tpl('这是一封测试邮件', '如果你收到了它，说明邮件服务已经配置成功，用户注册可以正常收验证码了。', '')
    );
}

/**
 * 邮件正文模板。
 */
function hnim_mail_tpl(string $title, string $line1, string $code): string
{
    $name = htmlspecialchars(hnim_app_name(), ENT_QUOTES, 'UTF-8');
    $t = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $l = htmlspecialchars($line1, ENT_QUOTES, 'UTF-8');
    $codeBox = $code === ''
        ? ''
        : '<div style="margin:18px 0;padding:14px 0;text-align:center;background:#f2f6ff;border-radius:10px;'
        . 'font-size:28px;letter-spacing:8px;font-weight:700;color:#1a6bff;">'
        . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</div>';

    return '<div style="max-width:520px;margin:0 auto;font-family:-apple-system,Segoe UI,Microsoft YaHei,sans-serif;color:#222;">'
        . '<div style="padding:18px 22px;background:#1a6bff;color:#fff;border-radius:10px 10px 0 0;font-size:17px;font-weight:600;">' . $name . '</div>'
        . '<div style="padding:22px;border:1px solid #e6e9ef;border-top:none;border-radius:0 0 10px 10px;">'
        . '<h2 style="margin:0 0 12px;font-size:17px;">' . $t . '</h2>'
        . '<p style="margin:0;line-height:1.7;color:#555;">' . $l . '</p>'
        . $codeBox
        . '<p style="margin:14px 0 0;font-size:12px;color:#999;">如果不是你本人操作，请忽略这封邮件。</p>'
        . '</div></div>';
}

/* ================================================================== *
 *  注册验证码：发 / 校验 / 限量
 * ================================================================== */

/**
 * 给邮箱发一个注册验证码。
 * @return array{ok:bool,error?:string}
 */
function hnim_mail_code_send(string $email, string $purpose = 'register', string $ip = ''): array
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => '邮箱格式不正确'];
    }
    $why = hnim_smtp_ready();
    if ($why !== null) {
        return ['ok' => false, 'error' => $why];
    }
    $pdo = hnim_db();

    // 同一邮箱 60 秒内只能发一次，防刷
    $st = $pdo->prepare('SELECT send_at FROM email_codes WHERE email = ? AND purpose = ? ORDER BY id DESC LIMIT 1');
    $st->execute([$email, $purpose]);
    $last = (int) $st->fetchColumn();
    if ($last > 0 && time() - $last < 60) {
        $wait = 60 - (time() - $last);
        return ['ok' => false, 'error' => "发送太频繁了，请 {$wait} 秒后再试"];
    }

    // 同一邮箱一天最多 10 封，防止被人拿来刷邮件
    $st = $pdo->prepare('SELECT COUNT(*) FROM email_codes WHERE email = ? AND send_at > ?');
    $st->execute([$email, time() - 86400]);
    if ((int) $st->fetchColumn() >= 10) {
        return ['ok' => false, 'error' => '这个邮箱今天收到的验证码太多了，请明天再试'];
    }

    $code = (string) random_int(100000, 999999);
    $now  = time();
    $st = $pdo->prepare(
        'INSERT INTO email_codes (email, code, purpose, ip, send_at, expire_at, used) VALUES (?,?,?,?,?,?,0)'
    );
    $st->execute([$email, $code, $purpose, mb_substr($ip, 0, 64), $now, $now + 600]);

    $r = hnim_smtp_send(
        $email,
        '【' . hnim_app_name() . '】注册验证码',
        hnim_mail_tpl(
            '注册验证码',
            '你的验证码是下面这 6 位数字，10 分钟内有效，请尽快填写。',
            $code
        )
    );
    if (!$r['ok']) {
        // 发不出去就把这条验证码标记作废，免得占着 60 秒冷却
        $st = $pdo->prepare('UPDATE email_codes SET used = 1 WHERE email = ? AND code = ? AND purpose = ?');
        $st->execute([$email, $code, $purpose]);
        return ['ok' => false, 'error' => '验证码发送失败：' . ($r['error'] ?? '未知错误')];
    }
    return ['ok' => true];
}

/**
 * 校验验证码，成功后立即作废（一次性）。
 */
function hnim_mail_code_check(string $email, string $code, string $purpose = 'register'): bool
{
    $code = trim($code);
    if (!preg_match('/^\d{4,8}$/', $code)) {
        return false;
    }
    $pdo = hnim_db();
    $st = $pdo->prepare(
        'SELECT id FROM email_codes
         WHERE email = ? AND code = ? AND purpose = ? AND used = 0 AND expire_at >= ?
         ORDER BY id DESC LIMIT 1'
    );
    $st->execute([$email, $code, $purpose, time()]);
    $id = (int) $st->fetchColumn();
    if ($id <= 0) {
        return false;
    }
    $pdo->prepare('UPDATE email_codes SET used = 1 WHERE id = ?')->execute([$id]);
    return true;
}

/** 清理过期验证码（后台顺手调用） */
function hnim_mail_code_gc(): void
{
    try {
        hnim_db()->prepare('DELETE FROM email_codes WHERE expire_at < ?')->execute([time() - 86400]);
    } catch (Throwable $e) {
        // 清理失败不影响使用
    }
}
