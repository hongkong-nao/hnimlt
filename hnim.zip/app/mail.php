<?php
/**
 * HNIM 邮件发送（纯 PHP socket 实现，不依赖 Composer / PHPMailer）
 * ------------------------------------------------------------------
 * 支持三种常见发信方式：
 *   - none : 不加密（一般用于内网邮件服务器，端口 25）
 *   - ssl  : 一上来就是 SSL 连接（QQ 邮箱 / 163 常用，端口 465）
 *   - tls  : 明文连接后用 STARTTLS 升级（端口 587）
 * 认证支持 AUTH LOGIN 和 AUTH PLAIN。
 *
 * 所有 SMTP 参数都存在 settings 表里，后台改完立即生效，不用改配置文件。
 */
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/* ================================================================== *
 *  配置读取 / 保存
 * ================================================================== */

/** 读取 SMTP 配置（带默认值，方便后台表单直接回填） */
function hnim_smtp_conf(): array
{
    return [
        'enabled'   => (string) hnim_setting('smtp.enabled', '0') === '1',
        'host'      => (string) hnim_setting('smtp.host', ''),
        'port'      => (int)    hnim_setting('smtp.port', 465),
        'user'      => (string) hnim_setting('smtp.user', ''),
        'pass'      => (string) hnim_setting('smtp.pass', ''),
        'secure'    => (string) hnim_setting('smtp.secure', 'ssl'),
        // 是否校验邮件服务器的证书。默认校验。
        'verify'    => (string) hnim_setting('smtp.verify', '1') === '1',
        // 是否允许在**完全没有加密**的连接上登录。默认不允许。
        // 见 assertEncrypted()：这不是「要不要加密」的开关，而是
        // 「明文也要硬上」的逃生舱，只有内网自建邮件服务器才用得上。
        'allow_insecure' => (string) hnim_setting('smtp.allow_insecure', '0') === '1',
        'from'      => (string) hnim_setting('smtp.from', ''),
        'from_name' => (string) hnim_setting('smtp.from_name', hnim_app_name()),
        'timeout'   => (int)    hnim_setting('smtp.timeout', 12),
    ];
}

/** 站点名（邮件标题里用） */
function hnim_app_name(): string
{
    $n = (string) hnim_config('app.name', '');
    return $n !== '' ? $n : 'HNIM';
}

/**
 * SMTP 是否已经配置好、可以直接发信。
 * 注册流程会用它来判断——没配好就不允许注册。
 */
function hnim_smtp_ready(): ?string
{
    $c = hnim_smtp_conf();
    if (!$c['enabled']) {
        return '管理员还没有开启邮件服务';
    }
    if ($c['host'] === '') {
        return '管理员还没有填写邮件服务器地址';
    }
    if ($c['user'] === '') {
        return '管理员还没有填写发信邮箱账号';
    }
    if ($c['pass'] === '') {
        return '管理员还没有填写邮箱授权码';
    }
    if ($c['from'] === '') {
        return '管理员还没有填写发件人邮箱';
    }
    return null;
}

/** 保存 SMTP 配置。$data 只包含要改的键，密码留空表示不改。 */
function hnim_smtp_save(array $data): void
{
    if (array_key_exists('enabled', $data)) {
        hnim_setting_set('smtp.enabled', $data['enabled'] ? '1' : '0');
    }
    foreach (['host', 'user', 'secure', 'from', 'from_name'] as $k) {
        if (array_key_exists($k, $data)) {
            hnim_setting_set('smtp.' . $k, trim((string) $data[$k]));
        }
    }
    if (array_key_exists('port', $data)) {
        $port = (int) $data['port'];
        hnim_setting_set('smtp.port', (string) ($port > 0 && $port <= 65535 ? $port : 465));
    }
    // 证书校验开关。关掉等于「加密了但不验证对面是谁」，中间人照样能拿走授权码，
    // 所以默认开启，只有服务器确实用自签证书时才需要手动关。
    if (array_key_exists('verify', $data)) {
        hnim_setting_set('smtp.verify', $data['verify'] ? '1' : '0');
    }
    // 明文登录的逃生舱。和 verify 一样默认关闭，只有内网邮件服务器用得上。
    if (array_key_exists('allow_insecure', $data)) {
        hnim_setting_set('smtp.allow_insecure', $data['allow_insecure'] ? '1' : '0');
    }
    // 密码：空字符串表示“保持原样”，避免后台一保存就把授权码清掉
    if (array_key_exists('pass', $data) && (string) $data['pass'] !== '') {
        hnim_setting_set('smtp.pass', (string) $data['pass']);
    }
}

/* ================================================================== *
 *  SMTP 协议实现
 * ================================================================== */

/**
 * 简易 SMTP 客户端。
 * 内部类，只给 hnim_smtp_send() 用。
 */
final class HnimSmtp
{
    /** @var resource */
    private $fp;
    private string $last = '';

    public function __construct(
        private string $host,
        private int $port,
        private string $secure,
        private int $timeout = 12,
        private bool $verify = true,
        private bool $allowInsecure = false
    ) {
    }

    /**
     * TLS 上下文。
     *
     * verify_peer 之前是关的，那样等于「加密了但完全不验证对面是谁」——
     * 授权码照样能被中间人截走，535 之外的风险在这里。现在默认校验，
     * 真的碰到自签证书再由管理员手动放宽。
     *
     * crypto_method 限死 TLS 1.2 / 1.3，不给 SSLv3、TLS 1.0/1.1 留口子。
     *
     * @return resource 流上下文（注意：stream_context_create() 给的是
     *                    resource，不是 StreamContext 对象，所以这里不能写返回类型）
     */
    private function sslContext()
    {
        return stream_context_create([
            'ssl' => [
                'verify_peer'       => $this->verify,
                'verify_peer_name'  => $this->verify,
                'allow_self_signed' => !$this->verify,
                'SNI_enabled'       => true,
                'peer_name'         => $this->host,
                'crypto_method'     => STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT
                                   | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT,
            ],
        ]);
    }

    /**
     * 现在这条连接到底加没加密？
     *
     * 问的是 socket 本身，不是 $this->secure——后者只是「我们打算怎么连」。
     * 两者可能不一致：加密方式填错、端口和方式不配套、服务器把 STARTTLS
     * 悄悄降级回明文，这些都只有问 socket 才发现得了。所以发凭据之前
     * 必须以这里为准，不能拿配置里的 secure 当保证。
     */
    private function isEncrypted(): bool
    {
        if (!is_resource($this->fp)) {
            return false;
        }
        $md = @stream_get_meta_data($this->fp);
        return is_array($md) && !empty($md['crypto']);
    }

    /**
     * 发凭据前的最后一道闸：没加密就不发。
     *
     * 为什么非要在这里拦：授权码是 base64 编码，不是加密——明文发出去等于
     * 直接把密钥贴在网络上，任何中间人截一下就能拿去发信。之前 secure=none
     * 只会给一句「建议改用 SSL」的提示，照发不误。
     *
     * @param string $what 要发的东西（授权码 / 邮件正文），用于报错文案
     */
    private function assertEncrypted(string $what): void
    {
        if ($this->isEncrypted() || $this->allowInsecure) {
            return;
        }
        throw new RuntimeException(
            '已拒绝在未加密的连接上发送' . $what . '。'
            . '请把「加密方式」改成 SSL（端口 465）或 STARTTLS（端口 587）后重试；'
            . '确实只能用明文的内网邮件服务器，再勾上「允许明文登录」。'
        );
    }

    /** 连接失败的原因是不是出在证书上（只有这种才值得提示放宽校验） */
    private function isCertError(string $errstr): bool
    {
        $low = strtolower($errstr);
        // 英文是 OpenSSL 的原话，中文是我们自己包装的提示（点「允许自签证书」那类），
        // 两边都要认，否则 STARTTLS 失败时会因为只有中文措辞而判断不出是证书问题，
        // 给出「改端口」这种驴唇不对马嘴的提示。
        foreach (['certificate', 'self signed', 'self-signed', 'verify', 'issuer', 'ssl',
                  '证书', '自签'] as $needle) {
            if (str_contains($low, $needle)) {
                return true;
            }
        }
        return false;
    }

    /** 建立连接 */
    public function connect(): void
    {
        $remote = ($this->secure === 'ssl' ? 'ssl://' : '') . $this->host . ':' . $this->port;
        $errno = 0;
        $errstr = '';
        $fp = @stream_socket_client(
            $remote,
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $this->sslContext()
        );
        if (!$fp) {
            // 只在「证书不合格」这一种原因下才提示放宽；连不上如果是端口被封、
            // DNS 不通之类的问题，放宽证书校验也救不了，别让人白折腾。
            $tip = ($this->verify && $this->isCertError($errstr))
                 ? '。看着像是证书没通过校验：若你的邮件服务器用的是自签证书，'
                 . '可到后台「邮件设置」勾上「允许自签证书」再试一次。'
                 : '';
            throw new RuntimeException("连接邮件服务器失败（{$this->host}:{$this->port}）：{$errstr}{$tip}");
        }
        $this->fp = $fp;
        stream_set_timeout($this->fp, $this->timeout);

        $this->expect(220, '服务器没有正常打招呼');
        $this->ehlo();
    }

    /** 读一行（含多行响应的续行处理） */
    private function read(): string
    {
        $data = '';
        while (($line = fgets($this->fp, 2048)) !== false) {
            $data .= $line;
            // SMTP 多行响应：第 4 个字符是 '-' 表示还有下一行
            if (strlen($line) < 4 || $line[3] !== '-') {
                break;
            }
        }
        $this->last = $data;
        return $data;
    }

    /** 读响应并校验状态码 */
    private function expect(int $code, string $friendly): void
    {
        $resp = $this->read();
        if ($resp === '') {
            throw new RuntimeException($friendly . '（服务器无响应）');
        }
        if ((int) substr($resp, 0, 3) !== $code) {
            throw new RuntimeException($friendly . '：' . trim($this->shorten($resp)));
        }
    }

    /** 发一条命令 */
    private function cmd(string $line): void
    {
        if (@fwrite($this->fp, $line . "\r\n") === false) {
            throw new RuntimeException('与邮件服务器的连接已断开');
        }
    }

    /** 只取响应里最有用的一行，别把整段退回信息糊到界面上 */
    private function shorten(string $resp): string
    {
        $lines = preg_split('/\r?\n/', trim($resp));
        $first = (string) ($lines[0] ?? '');
        // 末尾那半句 "More information at https://…" 是帮助链接。
        // 按 160 字截断会正好切在 URL 中间，显示成 https://help.ma 这种半截地址——
        // 既不好看也点不开，所以整段去掉。
        $first = (string) preg_replace(
            '/\s*(?:More information (?:at|is)\s+)?https?:\/\/\S*$/i',
            '',
            $first
        );
        return mb_substr(trim($first), 0, 160, 'UTF-8');
    }

    private function ehlo(): void
    {
        $name = $_SERVER['SERVER_NAME'] ?? 'localhost';
        if ($name === '' || $name === 'localhost') {
            $name = 'hnim.local';
        }
        $this->cmd('EHLO ' . $name);
        try {
            $this->expect(250, '服务器拒绝了 EHLO');
        } catch (RuntimeException $e) {
            // 个别老服务器只认 HELO
            $this->cmd('HELO ' . $name);
            $this->expect(250, '服务器拒绝了 HELO');
        }

        if ($this->secure === 'tls') {
            $this->cmd('STARTTLS');
            $this->expect(220, '服务器不支持 STARTTLS 加密。加密方式和端口要配套：'
                             . 'STARTTLS 一般用 587，465 是「一上来就 SSL」那种，别混。');
            $ok = @stream_socket_enable_crypto(
                $this->fp,
                true,
                STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT
            );
            if ($ok !== true) {
                // stream_socket_enable_crypto() 返回 false 时不会说明原因，真实原因藏在
                // OpenSSL 的错误队列里。不捞出来就只能给一句「握手失败」，管理员看完
                // 仍然不知道该改端口还是该换证书。
                // 注意：openssl_error_string() 每读一次就清空队列，所以只取一次。
                $ossl = openssl_error_string();
                $why  = (is_string($ossl) && $ossl !== '') ? "（OpenSSL：{$ossl}）" : '（服务器未给出具体原因）';
                throw new RuntimeException(
                    'TLS 加密握手失败' . $why . '。请确认两点：端口和加密方式是否配套'
                    . '（STARTTLS 配 465 连不通），以及服务器证书是否有效。'
                );
            }
            // 升级后必须重新 EHLO：加密前的 EHLO 是明文协商出来的，不能沿用
            $this->cmd('EHLO ' . $name);
            $this->expect(250, '加密后 EHLO 失败');
        }
    }

    /** 登录（AUTH LOGIN，失败再试 AUTH PLAIN） */
    public function auth(string $user, string $pass): void
    {
        // 授权码是 base64，不是加密。没加密就不发，见 assertEncrypted()。
        $this->assertEncrypted('邮箱授权码');
        $this->cmd('AUTH LOGIN');
        $resp = $this->read();
        if ((int) substr($resp, 0, 3) !== 334) {
            // 有些服务器不认 LOGIN，改用 PLAIN
            $this->cmd('AUTH PLAIN ' . base64_encode("\0" . $user . "\0" . $pass));
            $this->expectAuth(235, $pass);
            return;
        }
        $this->cmd(base64_encode($user));
        $this->expect(334, '邮箱账号不正确');
        $this->cmd(base64_encode($pass));
        $this->expectAuth(235, $pass);
    }

    /**
     * 认证这一步的状态码校验。
     *
     * 单独写一个而不复用 expect()，是因为必须**先把服务器那条 535 读出来**，
     * 才能据此判断失败原因。之前把提示文案在 expect() 调用前就拼好，
     * 结果里面能拿到的只有上一条响应（334），诊断信息全丢——这就是那段
     * 「按关键词点名原因」从来没生效的原因。
     */
    private function expectAuth(int $code, string $pass): void
    {
        $resp = $this->read();
        if ($resp === '') {
            throw new RuntimeException($this->authErr('', $pass) . '（服务器无响应）');
        }
        if ((int) substr($resp, 0, 3) !== $code) {
            // 顺序：先说我们判断出什么，再原样附上服务器的话，最后给排查步骤。
            // 「服务器把所有可能原因都塞在一句里」这句必须排在原文之后——
            // 放前面就成了先下结论再摆证据，读起来像在硬凑。
            $msg = rtrim($this->authErr($resp, $pass), '。')
                 . '：' . trim($this->shorten($resp));
            if (substr($resp, 0, 3) === '535') {
                $msg .= $this->authChecklist();
            }
            throw new RuntimeException($msg);
        }
    }

    /**
     * 认证失败的说明。
     *
     * $resp 必须是**刚刚读出来的那条响应**，传错的话下面的判断全是空转。
     *
     * 只报授权码**长度**、绝不回显内容：长度是这会儿最有用的线索
     * （授权码一般 16 位），既能定位问题，又不泄露密钥。
     */
    private function authErr(string $resp, string $pass): string
    {
        $len = strlen($pass);
        $msg = '邮箱账号或授权码不正确';

        if ($len === 0) {
            $msg .= '（后台里一个授权码都没存，请填好后先点「保存设置」再发测试邮件）';
        } elseif ($len < 8) {
            $msg .= '（当前保存的只有 ' . $len . ' 位，授权码通常是 16 位，多半没复制全）';
        } else {
            $msg .= '（当前保存的是 ' . $len . ' 位，长度没问题，所以不是没填全的问题）';
        }

        $msg .= '。QQ / 163 邮箱要填网页版「设置 → 账户」里生成的『授权码』，不是登录密码。';

        return $msg;
    }

    /**
     * 535 之后附的排查步骤。
     *
     * 刻意**不**去匹配响应里的关键词来判断原因：QQ 这句 535 是固定模板，
     * 不管真实原因是哪一条，都会把「服务未开启」「频率限制」全列一遍。
     * 照关键词猜属于假精准，只会把人带偏。索性老实交代它没有指明是哪一条。
     */
    private function authChecklist(): string
    {
        return '  ↑ 服务器把所有可能原因都塞进了上面这一句（账号异常 / 服务未开启 / 密码错 / '
             . '频率限制 / 系统繁忙），它并没有指明是哪一条，只能挨个排除：'
             . '① 回邮箱网页版确认 SMTP 服务已开启；'
             . '② 确认填的是授权码而不是 QQ 密码；'
             . '③ 刚连续失败过多次的话，等 10~30 分钟再试，别反复点「发送测试邮件」。';
    }

    /**
     * 分阶段自检。**不发任何邮件**，只把每个环节的结果如实报出来。
     *
     * 为什么要单独写一个，而不是复用 connect()：
     * connect() 是一步到底的，任何一步失败都只抛一句笼统的异常。
     * 而实际排障必须分清是「TCP 不通」「TLS 握手失败」「证书不合格」
     * 「EHLO 被拒」「认证被拒」——这几类的处理方式完全不一样。
     *
     * 返回结构：
     *   ok      整体是否走通到认证那一步
     *   stage   卡在哪一环
     *   msg     这一环的结果
     *   detail  补充说明（数组，每条一行）
     */
    public function diagnose(string $user, string $pass): array
    {
        $r = ['ok' => false, 'stage' => '开始', 'msg' => '', 'detail' => []];

        // 没授权码就别急着去连服务器了。先报这个，白跑一趟网络也换不来新信息。
        if ($pass === '') {
            $r['stage'] = '配置检查';
            $r['msg']   = '后台里没有保存授权码';
            $r['detail'][] = '请在「邮箱授权码 / 密码」里填好，并且要点「保存设置」，然后再来点自检。';
            return $r;
        }
        $r['detail'][] = '当前保存的授权码是 ' . strlen($pass) . ' 位'
            . '（授权码通常是 16 位；这里只报位数，不显示内容）';

        // ① TCP（secure=ssl 时这一步同时包含 TLS 握手）
        $r['stage'] = '① TCP 连接';
        $remote = ($this->secure === 'ssl' ? 'ssl://' : '') . $this->host . ':' . $this->port;
        $errno = 0;
        $errstr = '';
        $fp = @stream_socket_client(
            $remote,
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $this->sslContext()
        );
        if (!$fp) {
            $r['msg'] = "连不上 {$this->host}:{$this->port} —— {$errstr}";
            $r['detail'][] = $this->verify && $this->isCertError($errstr)
                ? '像是证书没通过校验。若你的邮件服务器用自签证书，勾上「允许自签证书」再试。'
                : '不是证书能解决的问题，多半是端口被封、DNS 不通或服务器不可达。';
            return $r;
        }
        $this->fp = $fp;
        stream_set_timeout($this->fp, $this->timeout);
        $r['msg'] = "已连上 {$this->host}:{$this->port}";

        // ② 证书与加密（隐式 SSL 这一步就已经是加密态）
        $r['stage'] = '② 加密与证书';
        $md     = @stream_get_meta_data($this->fp);
        $crypto = is_array($md) ? ($md['crypto'] ?? []) : [];
        if (!empty($crypto)) {
            $r['detail'][] = 'TLS 版本 ' . ($crypto['protocol'] ?? '?')
                . '，加密套件 ' . ($crypto['cipher_name'] ?? '?');
            $par = stream_context_get_params($this->fp);
            $cert = $par['ssl']['peer_certificate'] ?? null;
            if ($cert) {
                $info = @openssl_x509_parse($cert);
                if (is_array($info)) {
                    $r['detail'][] = '对方证书 CN ' . ($info['subject']['CN'] ?? '?')
                        . '，签发机构 ' . ($info['issuer']['CN'] ?? '?');
                    $r['detail'][] = '有效期至 ' . date('Y-m-d', $info['validTo_time_t'] ?? 0);
                }
            }
            $r['detail'][] = $this->verify
                ? '证书校验：已开启且通过'
                : '证书校验：已被你手动关闭（不算真正的加密，只在没有自签证书时才该关）';
        } else {
            // 这一栏是 ② 加密与证书。secure=tls 时此刻确实还是明文——STARTTLS 还没发，
            // 但那只是流程还没走到，不是「加密失败」，所以措辞上不能报警。
            // 真正的结论在 ④ 那一行（升级后到底成了什么），别在这里抢着下判断。
            if ($this->secure === 'none') {
                $r['detail'][] = $this->allowInsecure
                    ? '按设置未加密（明文），且已勾选「允许明文登录」，'
                      . '所以仍然会继续尝试登录。仅限内网邮件服务器使用。'
                    : '按设置未加密（明文），已拒绝发送授权码（除非勾选「允许明文登录」）。'
                      . '公网邮箱请把「加密方式」改成 SSL（465）或 STARTTLS（587）。';
            } else {
                $r['detail'][] = '此刻尚未加密（STARTTLS 还没发出），'
                    . '接下来由 ④ 完成升级；升级失败会在那一栏停住。';
            }
        }

        $greet = $this->read();
        if (!str_starts_with($greet, '220')) {
            $r['msg'] = $r['msg'] . '；但服务器打招呼异常：' . trim($this->shorten($greet));
            return $r;
        }

        // ③+④ EHLO 与 STARTTLS。
        // 注意只能调一次 ehlo()：它内部对 secure=tls 已经做了
        // 「STARTTLS → 握手 → 重新 EHLO」全套。再调一次就是连着做两次 STARTTLS，
        // 第二次必然失败，诊断结果反而会误导人。
        $r['stage'] = $this->secure === 'tls' ? '③④ EHLO + STARTTLS' : '③ EHLO';
        try {
            $this->ehlo();
        } catch (RuntimeException $e) {
            // 这一环最常见的失败就是证书校验不过，所以要把放宽的提示带上，
            // 而不是把异常原样往上抛（抛上去最后会变成「意外中断」，等于什么都没说）。
            $r['msg'] = $e->getMessage();
            $r['detail'][] = 'TCP 连接是通的，问题出在加密握手。';
            $r['detail'][] = ($this->verify && $this->isCertError($e->getMessage()))
                ? '看着像证书没通过校验。若你的邮件服务器用自签证书，'
                  . '可到后台「邮件设置」勾上「允许自签证书」再试一次。'
                : '若服务器证书本身没问题，检查「加密方式」和「端口」是否配套：'
                  . 'STARTTLS 一般配 587，465 是「一上来就 SSL」那种。';
            $this->closeQuietly();
            return $r;
        }
        $caps = str_replace(["\r\n", "\r", "\n"], ' / ', trim($this->last));
        $r['detail'][] = '服务器广告：' . ($caps !== '' ? $caps : '（没拿到）');

        if ($this->secure === 'tls') {
            $md2 = @stream_get_meta_data($this->fp);
            $c2  = is_array($md2) ? ($md2['crypto'] ?? []) : [];
            $r['msg'] = !empty($c2)
                ? 'STARTTLS 已升级为 ' . ($c2['protocol'] ?? '?') . ' / ' . ($c2['cipher_name'] ?? '?')
                : 'STARTTLS 握手完成（加密细节见上一栏）';
            // 必须写进 detail 而不是只放在 msg 里：后面的阶段会把 msg 覆盖掉
            // （认证失败时 msg 就变成「授权码不正确」了），只放 msg 等于白记。
            // 必须写进 detail 而不是只放在 msg 里：后面的阶段会把 msg 覆盖掉
            // （认证失败时 msg 就变成「授权码不正确」了），只放 msg 等于白记。
            if (!empty($c2)) {
                $r['detail'][] = 'STARTTLS 升级后：' . ($c2['protocol'] ?? '?') . ' / ' . ($c2['cipher_name'] ?? '?');
                // 邮件正文（含注册验证码）也要在这条连接上跑，所以同样值得单独确认一次加密。
                $r['detail'][] = $this->verify
                    ? '证书校验：已开启且通过（STARTTLS 之后，邮件正文同样受保护）'
                    : '证书校验：已被手动关闭——正文虽已加密，但无法确认对面是谁。';
            } else {
                $r['detail'][] = 'STARTTLS 已完成升级，但读不到协商结果（老版本 PHP 偶尔会这样）';
            }
        } else {
            $r['msg'] = '服务器已接受';
        }

        if (!str_contains(strtoupper($caps), 'AUTH')) {
            $r['detail'][] = '注意：服务器广告的能力里没有 AUTH。开了 SMTP 服务的邮箱一定会广告，'
                . '没有就说明该邮箱的 SMTP 服务可能还没开启。';
        }

        // ⑤ 认证（授权码位数的提示已在开头给过）
        $r['stage'] = '⑤ 账号密码认证';
        try {
            $this->auth($user, $pass);
        } catch (RuntimeException $e) {
            $r['msg'] = $e->getMessage();
            // 「守卫拦下了」和「服务器不认凭据」是两回事，措辞不能混。
            // 前者根本没发出去，说「前面几步都通了、只差凭据」会让人
            // 反复去换授权码——问题根本不在授权码上。
            $r['detail'][] = str_contains($e->getMessage(), '已拒绝在未加密的连接上发送')
                ? '失败原因是「没有加密」，不是授权码不对：上面那句话才是要解决的事，'
                  . '授权码一个字都还没发出去，别去换授权码。'
                : '说明前面几步都通了（TCP、加密、EHLO 全正常），'
                  . '失败只发生在凭据这一环节。';
            $this->closeQuietly();
            return $r;
        }
        $r['ok']   = true;
        $r['msg']  = '认证成功（服务器回了 235），凭据本身没问题';
        $r['detail'][] = '那就别再怀疑授权码了：要么是 SMTP 服务没开，要么是被限频，要么是账号被风控。';
        $this->closeQuietly();
        return $r;
    }

    /** 关掉连接，不报错 */
    private function closeQuietly(): void
    {
        if (!is_resource($this->fp)) {
            return;
        }
        @fwrite($this->fp, "QUIT\r\n");
        @fclose($this->fp);
    }

    /** 发一封信 */
    public function send(string $from, string $fromName, string $to, string $subject, string $html): void
    {
        $this->cmd('MAIL FROM:<' . $from . '>');
        $this->expect(250, '发件人被服务器拒绝');

        $this->cmd('RCPT TO:<' . $to . '>');
        $this->expect(250, '收件人被服务器拒绝');

        $this->cmd('DATA');
        $this->expect(354, '服务器拒绝接收邮件内容');

        $body = $this->buildMessage($from, $fromName, $to, $subject, $html);
        // 正文里的孤立点要转义，避免被当成结束标记
        $body = preg_replace('/^\./m', '..', $body);
        if (@fwrite($this->fp, $body . "\r\n.\r\n") === false) {
            throw new RuntimeException('发送邮件内容时连接中断');
        }
        $this->expect(250, '邮件被服务器退回');
    }

    /** 拼一封 MIME 邮件（UTF-8 + base64，中文不乱码） */
    private function buildMessage(string $from, string $fromName, string $to, string $subject, string $html): string
    {
        $b = chr(13) . chr(10);
        $h = [];
        $h[] = 'Date: ' . date('r');
        $h[] = 'From: ' . $this->encodeName($fromName) . ' <' . $from . '>';
        $h[] = 'To: <' . $to . '>';
        $h[] = 'Subject: ' . $this->encodeHeader($subject);
        $h[] = 'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $this->host . '>';
        $h[] = 'MIME-Version: 1.0';
        $h[] = 'Content-Type: text/html; charset=UTF-8';
        $h[] = 'Content-Transfer-Encoding: base64';
        return implode($b, $h) . $b . $b . chunk_split(base64_encode($html), 76, $b);
    }

    /** 标题按 RFC2047 编码（中文邮件标题必需） */
    private function encodeHeader(string $s): string
    {
        if (preg_match('/[\x80-\xFF]/', $s)) {
            return '=?UTF-8?B?' . base64_encode($s) . '?=';
        }
        return $s;
    }

    /** 发件人显示名编码 */
    private function encodeName(string $s): string
    {
        return $this->encodeHeader(str_replace(['<', '>', '"'], '', $s));
    }

    public function quit(): void
    {
        if (is_resource($this->fp)) {
            @fwrite($this->fp, "QUIT\r\n");
            @fclose($this->fp);
        }
    }
}

/* ================================================================== *
 *  对外接口
 * ================================================================== */

/**
 * 真正发一封信。
 * @return array{ok:bool,error?:string}
 */
function hnim_smtp_send(string $to, string $subject, string $html): array
{
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => '收件邮箱格式不对'];
    }
    $why = hnim_smtp_ready();
    if ($why !== null) {
        return ['ok' => false, 'error' => $why];
    }
    $c = hnim_smtp_conf();
    $from = $c['from'] !== '' ? $c['from'] : $c['user'];

    $smtp = new HnimSmtp(
        $c['host'], $c['port'], $c['secure'], max(5, $c['timeout']),
        $c['verify'], $c['allow_insecure']
    );
    try {
        $smtp->connect();
        $smtp->auth($c['user'], $c['pass']);
        $smtp->send($from, $c['from_name'], $to, $subject, $html);
        $smtp->quit();
    } catch (Throwable $e) {
        try {
            $smtp->quit();
        } catch (Throwable $ignore) {
            // 收尾失败无所谓
        }
        return ['ok' => false, 'error' => $e->getMessage()];
    }
    return ['ok' => true];
}

/**
 * 后台“发送测试邮件”按钮用。
 * @return array{ok:bool,error?:string}
 */
function hnim_smtp_test(string $to): array
{
    return hnim_smtp_send(
        $to,
        '【' . hnim_app_name() . '】测试邮件',
        hnim_mail_tpl('这是一封测试邮件', '如果你收到了它，说明邮件服务已经配置成功，用户注册可以正常收验证码了。', '')
    );
}

/**
 * 分阶段自检入口（后台「SMTP 自检」按钮用）。
 *
 * 和 hnim_smtp_test() 的区别：不发任何邮件，只把 TCP、加密、EHLO、
 * STARTTLS、认证这五个环节分别的结果报出来。排障时最费时间的就是
 * 「服务器只给一句笼统的错误」，这个能把问题定位到具体某一环。
 *
 * 返回：['ok'=>bool, 'stage'=>string, 'msg'=>string, 'detail'=>string[]]
 */
function hnim_smtp_diag(): array
{
    $why = hnim_smtp_ready();
    if ($why !== null) {
        return ['ok' => false, 'stage' => '配置检查', 'msg' => $why, 'detail' => []];
    }

    $c    = hnim_smtp_conf();
    $smtp = new HnimSmtp(
        $c['host'], $c['port'], $c['secure'], max(5, $c['timeout']),
        $c['verify'], $c['allow_insecure']
    );
    try {
        return $smtp->diagnose($c['user'], $c['pass']);
    } catch (Throwable $e) {
        return [
            'ok'     => false,
            'stage'  => '意外中断',
            'msg'    => $e->getMessage(),
            'detail' => ['这不该是正常现象，请把这句话反馈出来。'],
        ];
    }
}

/**
 * 邮件正文模板。
 */
function hnim_mail_tpl(string $title, string $line1, string $code): string
{
    $name = htmlspecialchars(hnim_app_name(), ENT_QUOTES, 'UTF-8');
    $t = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $l = htmlspecialchars($line1, ENT_QUOTES, 'UTF-8');
    $codeBox = $code === ''
        ? ''
        : '<div style="margin:18px 0;padding:14px 0;text-align:center;background:#f2f6ff;border-radius:10px;'
        . 'font-size:28px;letter-spacing:8px;font-weight:700;color:#1a6bff;">'
        . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</div>';

    return '<div style="max-width:520px;margin:0 auto;font-family:-apple-system,Segoe UI,Microsoft YaHei,sans-serif;color:#222;">'
        . '<div style="padding:18px 22px;background:#1a6bff;color:#fff;border-radius:10px 10px 0 0;font-size:17px;font-weight:600;">' . $name . '</div>'
        . '<div style="padding:22px;border:1px solid #e6e9ef;border-top:none;border-radius:0 0 10px 10px;">'
        . '<h2 style="margin:0 0 12px;font-size:17px;">' . $t . '</h2>'
        . '<p style="margin:0;line-height:1.7;color:#555;">' . $l . '</p>'
        . $codeBox
        . '<p style="margin:14px 0 0;font-size:12px;color:#999;">如果不是你本人操作，请忽略这封邮件。</p>'
        . '</div></div>';
}

/* ================================================================== *
 *  注册验证码：发 / 校验 / 限量
 * ================================================================== */

/**
 * 给邮箱发一个注册验证码。
 * @return array{ok:bool,error?:string}
 */
function hnim_mail_code_send(string $email, string $purpose = 'register', string $ip = ''): array
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => '邮箱格式不正确'];
    }
    $why = hnim_smtp_ready();
    if ($why !== null) {
        return ['ok' => false, 'error' => $why];
    }
    $pdo = hnim_db();

    // 同一邮箱 60 秒内只能发一次，防刷
    $st = $pdo->prepare('SELECT send_at FROM email_codes WHERE email = ? AND purpose = ? ORDER BY id DESC LIMIT 1');
    $st->execute([$email, $purpose]);
    $last = (int) $st->fetchColumn();
    if ($last > 0 && time() - $last < 60) {
        $wait = 60 - (time() - $last);
        return ['ok' => false, 'error' => "发送太频繁了，请 {$wait} 秒后再试"];
    }

    // 同一邮箱一天最多 10 封，防止被人拿来刷邮件
    $st = $pdo->prepare('SELECT COUNT(*) FROM email_codes WHERE email = ? AND send_at > ?');
    $st->execute([$email, time() - 86400]);
    if ((int) $st->fetchColumn() >= 10) {
        return ['ok' => false, 'error' => '这个邮箱今天收到的验证码太多了，请明天再试'];
    }

    $code = (string) random_int(100000, 999999);
    $now  = time();
    $st = $pdo->prepare(
        'INSERT INTO email_codes (email, code, purpose, ip, send_at, expire_at, used) VALUES (?,?,?,?,?,?,0)'
    );
    $st->execute([$email, $code, $purpose, mb_substr($ip, 0, 64), $now, $now + 600]);

    $r = hnim_smtp_send(
        $email,
        '【' . hnim_app_name() . '】注册验证码',
        hnim_mail_tpl(
            '注册验证码',
            '你的验证码是下面这 6 位数字，10 分钟内有效，请尽快填写。',
            $code
        )
    );
    if (!$r['ok']) {
        // 发不出去就把这条验证码标记作废，免得占着 60 秒冷却
        $st = $pdo->prepare('UPDATE email_codes SET used = 1 WHERE email = ? AND code = ? AND purpose = ?');
        $st->execute([$email, $code, $purpose]);
        return ['ok' => false, 'error' => '验证码发送失败：' . ($r['error'] ?? '未知错误')];
    }
    return ['ok' => true];
}

/**
 * 校验验证码，成功后立即作废（一次性）。
 */
function hnim_mail_code_check(string $email, string $code, string $purpose = 'register'): bool
{
    $code = trim($code);
    if (!preg_match('/^\d{4,8}$/', $code)) {
        return false;
    }
    $pdo = hnim_db();
    $st = $pdo->prepare(
        'SELECT id FROM email_codes
         WHERE email = ? AND code = ? AND purpose = ? AND used = 0 AND expire_at >= ?
         ORDER BY id DESC LIMIT 1'
    );
    $st->execute([$email, $code, $purpose, time()]);
    $id = (int) $st->fetchColumn();
    if ($id <= 0) {
        return false;
    }
    $pdo->prepare('UPDATE email_codes SET used = 1 WHERE id = ?')->execute([$id]);
    return true;
}

/** 清理过期验证码（后台顺手调用） */
function hnim_mail_code_gc(): void
{
    try {
        hnim_db()->prepare('DELETE FROM email_codes WHERE expire_at < ?')->execute([time() - 86400]);
    } catch (Throwable $e) {
        // 清理失败不影响使用
    }
}
