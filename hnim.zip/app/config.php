<?php
/**
 * HNIM 配置装载器
 * 所有路径均使用相对定位，保证整个程序目录可直接拷贝到 U 盘 / 移动硬盘运行。
 */
declare(strict_types=1);

define('HNIM_ROOT',    dirname(__DIR__));
define('HNIM_APP',     HNIM_ROOT . DIRECTORY_SEPARATOR . 'app');
define('HNIM_CONFIG',  HNIM_ROOT . DIRECTORY_SEPARATOR . 'config');
define('HNIM_DATA',    HNIM_ROOT . DIRECTORY_SEPARATOR . 'data');
define('HNIM_UPLOADS', HNIM_ROOT . DIRECTORY_SEPARATOR . 'uploads');
define('HNIM_VERSION', '1.0.0');
define('HNIM_NAME',    'HNIM');

/** 配置文件是否存在（= 是否已安装） */
function hnim_installed(): bool
{
    static $flag = null;
    if ($flag !== null) {
        return $flag;
    }
    $flag = is_file(HNIM_CONFIG . '/config.php') && is_file(HNIM_CONFIG . '/database.php');
    return $flag;
}

/**
 * 配置文件缺失时的提示。
 *
 * install.php 已按要求删除（避免被重装），所以不能再跳过去 ——
 * 缺文件就明确告诉人缺哪个、怎么补。
 */
function hnim_require_installed(): void
{
    if (hnim_installed()) {
        return;
    }
    $miss = [];
    if (!is_file(HNIM_CONFIG . '/config.php')) {
        $miss[] = 'config/config.php';
    }
    if (!is_file(HNIM_CONFIG . '/database.php')) {
        $miss[] = 'config/database.php';
    }

    $isApi = basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')) === 'api.php';
    if ($isApi) {
        hnim_json([
            'ok'    => false,
            'error' => '配置不完整，缺少：' . implode('、', $miss) . '。请把备份的配置放回 config/ 目录。',
        ], 503);
    }

    if (!headers_sent()) {
        http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
    }
    $list = '';
    foreach ($miss as $f) {
        $list .= '<li><code>' . htmlspecialchars($f, ENT_QUOTES, 'UTF-8') . '</code></li>';
    }
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>配置缺失 · HNIM</title><style>'
       . 'body{margin:0;font:15px/1.7 "Microsoft YaHei",system-ui,sans-serif;background:#f4f6fa;color:#1f2329}'
       . '.box{max-width:640px;margin:8vh auto;background:#fff;border-radius:12px;padding:32px;'
       . 'box-shadow:0 6px 24px rgba(0,0,0,.07)}h1{margin:0 0 8px;font-size:21px;color:#c0392b}'
       . 'code{background:#f2f4f8;padding:2px 6px;border-radius:4px}</style></head><body><div class="box">'
       . '<h1>配置文件缺失</h1><p>下面这些文件不见了，程序没法启动：</p><ul>' . $list . '</ul>'
       . '<p>安装向导已经删掉了，请从备份里把 <code>config/</code> 目录整个放回去即可。</p>'
       . '</div></body></html>';
    exit;
}

/**
 * 长轮询最长挂起秒数。
 * PHP 内置服务器（php -S）没有并发能力：
 *   - Windows 下 PHP_CLI_SERVER_WORKERS 不生效，整个服务器是单线程的，
 *     一旦挂起 20 秒，其他所有人的所有请求都会排队卡死。
 *   - Linux/macOS 下多进程 worker 才真正生效。
 * 所以这里按运行环境决定：单线程时返回 0（立即返回，由客户端自己间隔重试）。
 */
function hnim_poll_max(): int
{
    $sapi = PHP_SAPI;
    if ($sapi !== 'cli-server') {
        return 20;   // Apache / Nginx / FPM：每请求独立进程，随便挂
    }
    $workers = (int) getenv('PHP_CLI_SERVER_WORKERS');
    if ($workers > 1 && PHP_OS_FAMILY !== 'Windows') {
        return 20;
    }
    return 0;
}

/** 读取配置（带内存缓存） */
function hnim_config(?string $key = null, $default = null)
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = [];
        foreach (['config.php', 'database.php', 'admin.php'] as $f) {
            $path = HNIM_CONFIG . '/' . $f;
            if (is_file($path)) {
                $part = @include $path;
                if (is_array($part)) {
                    $cfg = array_merge($cfg, $part);
                }
            }
        }
    }
    if ($key === null) {
        return $cfg;
    }
    $node = $cfg;
    foreach (explode('.', $key) as $seg) {
        if (!is_array($node) || !array_key_exists($seg, $node)) {
            return $default;
        }
        $node = $node[$seg];
    }
    return $node;
}

/** 生成安装锁标记（防止重复安装） */
function hnim_install_token(): string
{
    $f = HNIM_CONFIG . '/installed.lock';
    if (is_file($f)) {
        return trim((string) @file_get_contents($f));
    }
    return '';
}

/* ------------------------------------------------------------------ *
 *  数据库
 * ------------------------------------------------------------------ */

/**
 * 数据库连不上的专用异常。
 * 单独一个类型，是为了把「数据库没连上」和「代码有 bug」区分开：
 * 前者要给人看一段人话提示，后者该照常抛出去留堆栈。
 */
class HnimDbError extends RuntimeException
{
}

/**
 * 取某个库的连接地址，供排查提示页显示。
 * 从配置里读而不是写死在提示语里 —— 换了库地址，提示也跟着变。
 */
function hnim_db_error_addr(string $which): string
{
    $host = trim((string) hnim_config($which . '.host', ''));
    if ($host === '') {
        return '(未配置)';
    }
    $port = (int) hnim_config($which . '.port', 3306);
    // localhost / 127.0.0.1 带端口才看得出区别，公网地址带上更好认
    $isLocal = ($host === 'localhost' || $host === '127.0.0.1' || $host === '::1');
    if ($port > 0 && $port !== 3306) {
        return $host . ':' . $port;
    }
    return $isLocal ? $host . '（本机 MySQL）' : $host;
}

/**
 * 数据库连不上时的友好提示页。
 *
 * 部署时最常见的故障就是数据库地址 / 密码填错，如果直接抛异常，
 * PHP 在 display_errors 关闭时只会吐一个 500 空白页，用户完全不知道该查什么。
 */
function hnim_db_error_page(Throwable $e, string $prefix = '数据库连接失败：'): void
{
    $msg   = $e->getMessage();
    $entry = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));

    // API 调用：回 JSON，前端能直接显示
    if ($entry === 'api.php') {
        if (!headers_sent()) {
            http_response_code(503);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'ok'       => false,
            'error'    => $prefix . $msg,
            'db_error' => true,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!headers_sent()) {
        http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
    }
    // 「连不上」和「连上了但建不出表」是两回事，标题和排查清单得分开写，
    // 不然用户明明库是通的，却被提示去检查地址密码，白折腾半天。
    $isTable = ($prefix !== '数据库连接失败：');
    $safe = htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>' . ($isTable ? '数据库表未就绪' : '数据库连接失败') . ' · HNIM</title><style>'
       . 'body{margin:0;font:15px/1.7 "Microsoft YaHei",system-ui,sans-serif;background:#f4f6fa;color:#1f2329}'
       . '.box{max-width:680px;margin:8vh auto;background:#fff;border-radius:12px;padding:32px;'
       . 'box-shadow:0 6px 24px rgba(0,0,0,.07)}h1{margin:0 0 8px;font-size:21px;color:#c0392b}'
       . 'p{margin:8px 0}code{background:#f2f4f8;padding:2px 6px;border-radius:4px}'
       . 'pre{background:#f2f4f8;padding:14px;border-radius:8px;overflow:auto;white-space:pre-wrap;word-break:break-all}'
       . 'ol{padding-left:22px}li{margin:6px 0}a{color:#1a73e8}</style></head><body><div class="box">'
       . '<h1>' . ($isTable ? '数据库表没建出来' : '连不上数据库') . '</h1>'
       . '<p>' . ($isTable
            ? '程序和数据库都是好的，连接也成功了，只是里面的表没能自动建出来，所以暂时进不去。原始报错：'
            : '程序已经装好了，但数据库连接失败，所以暂时进不去。原始报错：')
       . '</p>'
       . '<pre>' . $safe . '</pre>'
       . '<p>请按下面顺序排查：</p><ol>'
       // 地址/密码只在真的连不上时才需要查；库都连上了就别让用户去折腾这些
       . ($isTable ? '' : '<li>确认 <code>config/database.php</code> 里的地址、库名、账号、密码没写错。</li>')
       . '<li>确认数据库账号有 <code>CREATE TABLE</code> 权限'
       . '（很多虚拟主机的数据库账号只给了 SELECT/INSERT/UPDATE/DELETE，没有 CREATE）。</li>'
       . '<li>没有 CREATE 权限的话，在 phpMyAdmin 里选中这个库 →「导入」→'
       . '把程序 <code>app/schema.php</code> 里的建表语句执行一遍即可；'
       . '或者联系主机商给这个账号补上 CREATE 权限。</li>'
       // 地址从配置里读，改了库这里也跟着变，不会写出过期的提示
       . '<li>账号库地址 <code>' . hnim_db_error_addr('db') . '</code>；'
       . '聊天库地址 <code>' . hnim_db_error_addr('chat') . '</code>'
       . (hnim_chat_db_enabled() && hnim_db_error_addr('chat') !== hnim_db_error_addr('db')
            ? '，聊天库在另一台机器，要确认那台防火墙 / 安全组放行了 ' . (int) hnim_config('chat.port', 3306) . ' 端口。'
            : '。')
       . '</li>'
       . '<li>改完直接刷新本页即可，程序会自动把缺掉的表补建出来，不用重装。</li>'
       // 固定链回首页，不用 REQUEST_URI：那个地址可能本身就是打不开的路径
       . '</ol><p><a href="' . htmlspecialchars((string) hnim_url('index.php'), ENT_QUOTES, 'UTF-8') . '">刷新重试</a></p>'
       . '</div></body></html>';
    exit;
}

/**
 * 连接 MySQL；库不存在时自动把它建出来。
 * 这样部署时只要把库名写进 config/database.php，程序第一次访问就会
 * 自动建库 + 建表，不用先手工 CREATE DATABASE。
 *
 * @throws RuntimeException
 */
function hnim_mysql_connect(string $host, int $port, string $name, string $user, string $pass, array $opts, string $charset = 'utf8mb4'): PDO
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        throw new RuntimeException('数据库名只能用字母、数字和下划线，当前值：' . $name);
    }
    if (!preg_match('/^[A-Za-z0-9_]+$/', $charset)) {
        $charset = 'utf8mb4';
    }
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";
    try {
        return new PDO($dsn, $user, $pass, $opts);
    } catch (PDOException $e) {
        // 只有「库不存在」才自动建；密码错、没权限之类的问题要如实报出来
        $msg = $e->getMessage();
        if (stripos($msg, 'unknown database') === false
            && stripos($msg, '1049') === false
            && stripos($msg, "doesn't exist") === false) {
            throw new HnimDbError('数据库连接失败：' . $msg);
        }
    }

    // 不带库名连一次，把库建出来
    try {
        $boot = new PDO("mysql:host={$host};port={$port};charset={$charset}", $user, $pass, $opts);
        $boot->exec("CREATE DATABASE IF NOT EXISTS `{$name}` DEFAULT CHARACTER SET {$charset} COLLATE {$charset}_unicode_ci");
    } catch (PDOException $e) {
        throw new HnimDbError(
            "数据库 `{$name}` 不存在，且当前账号没有建库权限，请手工执行："
            . "CREATE DATABASE `{$name}` DEFAULT CHARACTER SET {$charset};（" . $e->getMessage() . '）'
        );
    }
    return new PDO($dsn, $user, $pass, $opts);
}

/**
 * 账号库连接（存用户 / 好友 / 黑名单 / 后台设置 / 日志）。
 * 连上后会自动建库、建表、升级表结构。
 *
 * @throws RuntimeException
 */
function hnim_db(bool $fresh = false): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO && !$fresh) {
        return $pdo;
    }

    $driver = (string) hnim_config('db.driver', 'mysql');
    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        // 聊天库在别的机器上，连不上时别把整个页面卡住等默认 60 秒超时
        PDO::ATTR_TIMEOUT            => 5,
    ];

    if ($driver === 'sqlite') {
        $path = (string) hnim_config('db.path', HNIM_DATA . '/hnim.sqlite');
        $dir  = dirname($path);
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $pdo = new PDO('sqlite:' . $path, null, null, $opts);
        try {
            $pdo->exec('PRAGMA journal_mode = WAL');
        } catch (Throwable $e) {
            // 库文件只读时切不了 WAL（写不进去），忽略即可：
            // 下面建表那步会给出更清楚的提示，不用在这里先炸掉。
        }
        $pdo->exec('PRAGMA busy_timeout = 8000');
        $pdo->exec('PRAGMA foreign_keys = ON');
        $errors = hnim_schema_ensure($pdo, 'sqlite', 'db', null);
        hnim_schema_require_ready($pdo, $errors, 'sqlite', basename($path));
        return $pdo;
    }

    $host    = (string) hnim_config('db.host', '127.0.0.1');
    $port    = (int)    hnim_config('db.port', 3306);
    $name    = (string) hnim_config('db.name', '');
    $user    = (string) hnim_config('db.user', 'root');
    $pass    = (string) hnim_config('db.pass', '');
    $charset = (string) hnim_config('db.charset', 'utf8mb4');

    if ($host === '' || $name === '') {
        throw new HnimDbError('数据库地址或数据库名称为空，请检查 config/database.php。');
    }
    // 库不存在会自动建出来，然后自动建表。
    // 连不上就直接给人话提示页：连不上库的话这个请求本来也不可能成功。
    try {
        $pdo = hnim_mysql_connect($host, $port, $name, $user, $pass, $opts, $charset);
    } catch (HnimDbError $e) {
        hnim_db_error_page($e);
    }
    $pdo->exec("SET NAMES {$charset}");
    try {
        $pdo->exec("SET SESSION sql_mode='NO_ENGINE_SUBSTITUTION'");
    } catch (Throwable $e) {
        // 某些托管环境禁用该语句，忽略
    }
    // 聊天库连不上不该拖垮账号库，这里只记日志，等真正用到聊天功能时再报错
    $chatPdo = null;
    if (hnim_chat_db_enabled()) {
        try {
            $chatPdo = hnim_chat_db();
        } catch (Throwable $e) {
            error_log('[hnim] chat db unavailable: ' . $e->getMessage());
        }
    }
    $schemaErrors = hnim_schema_ensure($pdo, 'mysql', 'db', $chatPdo);
    hnim_schema_require_ready($pdo, $schemaErrors, 'mysql', $name);
    return $pdo;
}

/**
 * 是否启用了独立的聊天数据库。
 * 没配 chat.* 就退回账号库（单库模式），老部署不受影响。
 */
function hnim_chat_db_enabled(): bool
{
    static $flag = null;
    if ($flag === null) {
        $flag = ((string) hnim_config('db.driver', 'mysql')) !== 'sqlite'
            && (string) hnim_config('chat.name', '') !== '';
    }
    return $flag;
}

/**
 * 聊天库连接（存会话 / 消息 / 收藏 / 入群申请）。
 * 未启用时返回 hnim_db()，这样所有业务代码只用调一个函数。
 *
 * @throws RuntimeException
 */
function hnim_chat_db(bool $fresh = false): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO && !$fresh) {
        return $pdo;
    }
    if (!hnim_chat_db_enabled()) {
        return hnim_db($fresh);
    }

    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        // 聊天库是远程库，挂了要快速失败，别让整页干等
        PDO::ATTR_TIMEOUT            => 5,
    ];
    $host    = (string) hnim_config('chat.host', '127.0.0.1');
    $port    = (int)    hnim_config('chat.port', 3306);
    $name    = (string) hnim_config('chat.name', '');
    $user    = (string) hnim_config('chat.user', '');
    $pass    = (string) hnim_config('chat.pass', '');
    $charset = (string) hnim_config('chat.charset', 'utf8mb4');

    if ($host === '' || $name === '') {
        throw new HnimDbError('聊天数据库地址或名称为空，请检查 config/database.php。');
    }
    // 聊天库不存在就自动建，然后自动建表
    $pdo = hnim_mysql_connect($host, $port, $name, $user, $pass, $opts, $charset);
    try {
        $pdo->exec("SET NAMES {$charset}");
    } catch (Throwable $e) {
        // 忽略
    }
    // 注意：$pdo 已经赋给 static 变量了，下面建表过程里再调用 hnim_chat_db() 不会重入
    hnim_schema_ensure($pdo, 'mysql', 'chat', $pdo);
    return $pdo;
}

/**
 * 聊天表查询统一走这里。
 * 配了独立聊天库时永远用聊天库（忽略调用方传进来的账号库连接，
 * 免得不小心把 messages 查到账号库去）；没配时就是同一个库，
 * 用传进来的连接，方便测试时注入。
 */
function hnim_chat_pdo(?PDO $pdo = null): PDO
{
    // 所有聊天表查询都走这里，所以聊天库连不上时在这里统一给提示页。
    // （hnim_chat_db() 本身保持抛异常，后台体检要靠它 catch 住返回「连接失败」）
    try {
        if (hnim_chat_db_enabled()) {
            return hnim_chat_db();
        }
        return $pdo ?: hnim_db();
    } catch (HnimDbError $e) {
        hnim_db_error_page($e);
    }
}

/** 聊天库是否真的连得上（后台体检用） */
function hnim_chat_db_check(): array
{
    if (!hnim_chat_db_enabled()) {
        return ['ok' => true, 'msg' => '未启用独立聊天库（与账号库同一个库）'];
    }
    try {
        $pdo = hnim_chat_db(true);
        $st = $pdo->query('SELECT COUNT(*) FROM conversations');
        return [
            'ok'  => true,
            'msg' => '连接正常，会话 ' . (int) $st->fetchColumn() . ' 个',
        ];
    } catch (Throwable $e) {
        return ['ok' => false, 'msg' => '连接失败：' . $e->getMessage()];
    }
}

/**
 * 确保某个库的表结构齐全：**缺表就整张建出来**，缺列就补，索引也补上。
 *
 * 之前只会给「已经存在的表」补字段，整库是空的时候一个表都不会建，
 * 所以现在部署时必须先跑一遍安装向导。加上这段之后，把库名写进
 * config/database.php 就能直接用：第一次访问自动建库 + 建表。
 *
 * 账号库和聊天库各有各的锁文件，互不影响。
 *
 * @param PDO      $pdo     账号库连接（$which='chat' 时就是聊天库连接）
 * @param string   $driver  mysql / sqlite
 * @param string   $which   锁文件后缀：db / chat
 * @param PDO|null $chatPdo 聊天库连接；单库模式传 null
 *
 * @return string[] 出错信息（空数组＝一切正常）
 */
function hnim_schema_ensure(PDO $pdo, string $driver, string $which, ?PDO $chatPdo = null): array
{
    static $done = [];
    if (isset($done[$which])) {
        return [];
    }
    $done[$which] = true;

    // 锁文件放在 config/ 下；但很多虚拟主机上传后目录是只读的，
    // 那样 lock 永远写不进去，等于每次请求都重跑一遍建表（又慢又吵）。
    // 所以先探一下能不能写，不能写就退到 data/ 下。
    $lockDir = HNIM_CONFIG;
    if (!is_writable($lockDir)) {
        if (!is_dir(HNIM_DATA)) {
            @mkdir(HNIM_DATA, 0700, true);
        }
        if (is_dir(HNIM_DATA) && is_writable(HNIM_DATA)) {
            $lockDir = HNIM_DATA;
        }
    }
    $lock = $lockDir . '/schema.' . $which . '.lock';
    // 版本号：改了表结构 / 修了建表逻辑就往上加 1，
    // 老 lock 会被判定为过期从而重跑，老站点升级后自动补齐。
    $ver  = '5';
    if (is_file($lock) && trim((string) @file_get_contents($lock)) === $ver) {
        // lock 说「建好了」，但表要是真没了（手动删过 / 上次建到一半崩了），
        // 还是得补建。每请求多一条 SELECT 1，代价可以忽略，
        // 换来的是「删表后刷新页面就自愈」，不用人肉介入。
        if (hnim_schema_exists($pdo, 'users')) {
            return [];
        }
        @unlink($lock);
    }

    $errors = [];
    // which=db 那一轮把两个库都管了（账号表进账号库、聊天表进聊天库）；
    // which=chat 那一轮是 hnim_chat_db() 自己触发的，那里的 $pdo 就是聊天库连接，
    // 所以只能建聊天表 —— 否则会把账号表也塞进聊天库去。
    $chatOnly = ($which === 'chat');
    try {
        // 1) 缺表就建（CREATE TABLE IF NOT EXISTS，重复执行安全）
        foreach (hnim_schema_statements($driver) as $sql) {
            if (!preg_match('/CREATE TABLE IF NOT EXISTS\s+(\w+)/i', $sql, $m)) {
                continue;
            }
            $table = $m[1];
            if (hnim_schema_is_chat_table($table)) {
                // $chatPdo 为空 = 单库模式，聊天表就建在账号库这个连接上
                $target = $chatPdo ?: $pdo;
            } elseif ($chatOnly) {
                continue;   // 账号表归 which=db 那轮管
            } else {
                $target = $pdo;
            }
            if (hnim_schema_exists($target, $table)) {
                continue;
            }
            try {
                $target->exec($sql);
            } catch (Throwable $e) {
                $errors[] = '建表 ' . $table . ' 失败：' . $e->getMessage();
            }
        }

        // 2) 索引。必须跟建表一起做：users.username 和 friends(user_id,friend_id)
        //    这两个唯一索引是数据完整性底线，缺了就会出现重名 / 重复好友。
        //    全部用 IF NOT EXISTS 或捕获「已存在」，重复执行安全。
        foreach (hnim_schema_statements($driver) as $sql) {
            if (!preg_match('/CREATE\s+(UNIQUE\s+)?INDEX\s+(IF NOT EXISTS\s+)?(\w+)\s+ON\s+(\w+)/i', $sql, $m)) {
                continue;
            }
            $table = $m[4];
            if (hnim_schema_is_chat_table($table)) {
                $target = $chatPdo ?: $pdo;
            } elseif ($chatOnly) {
                continue;
            } else {
                $target = $pdo;
            }
            if (!hnim_schema_exists($target, $table)) {
                continue;   // 表还没建出来（建表那步失败了），跳过
            }
            try {
                $target->exec($sql);
            } catch (Throwable $e) {
                // 索引已存在 / 历史数据有重复，都不算致命
                if (stripos($e->getMessage(), 'exist') === false) {
                    $errors[] = $m[3] . ': ' . $e->getMessage();
                }
            }
        }

        // 3) 补字段（聊天表的部分要落到聊天库上，所以把 chatPdo 和 chatOnly 一起传下去）
        foreach (hnim_schema_upgrade($pdo, $driver, $chatPdo, $chatOnly) as $e) {
            $errors[] = $e;
        }

        // 4) 收尾体检：这一轮该落的表，一张都不能少。
        //    少建了就绝对不能写 lock —— 否则以后每个请求都以为「已建好」直接跳过，
        //    表永远补不上，页面只能报 Table 'xxx.users' doesn't exist。
        $missing = [];
        foreach (hnim_schema_statements($driver) as $sql) {
            if (!preg_match('/CREATE TABLE IF NOT EXISTS\s+(\w+)/i', $sql, $m)) {
                continue;
            }
            $table = $m[1];
            $isChat = hnim_schema_is_chat_table($table);
            if ($chatOnly && !$isChat) {
                continue;
            }
            $target = $isChat ? ($chatPdo ?: $pdo) : $pdo;
            if (!hnim_schema_exists($target, $table)) {
                $missing[] = $table;
            }
        }
        if ($missing) {
            $errors[] = '以下表没能建出来：' . implode('、', $missing);
        }

        // 5) 只有一张表都没少才写 lock；有错就把老 lock 删掉，下个请求自动重试。
        if (!$errors && !$missing) {
            @file_put_contents($lock, $ver);
        } else {
            @unlink($lock);
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
        @unlink($lock);   // 出错绝不留下 lock，否则永远修不好
    }
    if ($errors) {
        error_log('[hnim] schema(' . $which . '): ' . implode(' | ', $errors));
    }
    return $errors;
}

/* ------------------------------------------------------------------ *
 *  后台设置（存 settings 表，改完立即生效，不用改配置文件）
 * ------------------------------------------------------------------ */

/**
 * 建完表之后确认「真的能用了」。
 *
 * 以前没有这一步：建表失败时请求会继续往下走，
 * 直到某条 SQL 撞上「Table 'xxx.users' doesn't exist」才炸，
 * 抛出来的是一整段 PDOException 堆栈 —— 看着像程序坏了，
 * 实际只是「数据库账号没有 CREATE 权限」，根本看不出该去改什么。
 */
function hnim_schema_require_ready(PDO $pdo, array $errors, string $driver, string $dbLabel): void
{
    if (hnim_schema_exists($pdo, 'users')) {
        // 表建出来了，但索引之类还有告警：记进日志，不打扰用户
        if ($errors) {
            error_log('[hnim] 建表告警(' . $driver . '): ' . implode(' | ', $errors));
        }
        return;
    }
    $why = $driver === 'sqlite'
        ? '请确认 data/ 目录可写（便携模式下要把整个 hnim 目录放在有写权限的地方）；'
          . '也可以直接把 data/hnim.sqlite 删掉，让程序重新建一份。'
        : '最常见的原因是数据库账号没有 CREATE TABLE 权限（只给了 SELECT/INSERT），'
          . '或者主机禁止建表。请在 phpMyAdmin 里手工建表，或把账号权限补齐后刷新本页。';
    // 注意：HnimDbError 继承自 Exception，构造函数的第 2 个参数是 int $code，
    // 不能拿它当「标题前缀」用 —— 前缀要传给 hnim_db_error_page() 的第 2 个参数。
    hnim_db_error_page(new HnimDbError(
        '数据库 ' . $dbLabel . ' 连上了，但表没能建出来。' . $why
        . "\n建表过程记录：" . implode('；', array_slice($errors, 0, 8))
    ), '数据库表未就绪：');
}

/** 读一个后台设置；找不到返回 $default */
function hnim_setting(string $key, $default = null)
{
    static $cache = null;
    if ($cache === null || !empty($GLOBALS['__hnim_setting_dirty'])) {
        $GLOBALS['__hnim_setting_dirty'] = false;
        $cache = [];
        try {
            foreach (hnim_db()->query('SELECT k, v FROM settings')->fetchAll() as $r) {
                $cache[(string) $r['k']] = $r['v'];
            }
        } catch (Throwable $e) {
            // settings 表还没建好（首次升级中），先按默认值走
            return $default;
        }
    }
    if (!array_key_exists($key, $cache)) {
        return $default;
    }
    $raw = $cache[$key];
    if ($raw === null || $raw === '') {
        return $default;
    }
    // 存进去时带 __json 前缀的是数组
    if (strncmp((string) $raw, '__json:', 7) === 0) {
        $d = json_decode(substr((string) $raw, 7), true);
        return is_array($d) ? $d : $default;
    }
    return $raw;
}

/** 写一个后台设置（数组自动 JSON 化） */
function hnim_setting_set(string $key, $value): void
{
    $pdo = hnim_db();
    if (is_array($value)) {
        $raw = '__json:' . json_encode($value, JSON_UNESCAPED_UNICODE);
    } elseif (is_bool($value)) {
        $raw = $value ? '1' : '0';
    } else {
        $raw = (string) $value;
    }
    if ((string) hnim_config('db.driver', 'mysql') === 'sqlite') {
        $sql = 'INSERT INTO settings (k, v, updated_at) VALUES (?, ?, ?)
                ON CONFLICT(k) DO UPDATE SET v = excluded.v, updated_at = excluded.updated_at';
    } else {
        $sql = 'INSERT INTO settings (k, v, updated_at) VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = VALUES(updated_at)';
    }
    $st = $pdo->prepare($sql);
    $st->execute([$key, $raw, time()]);
    hnim_setting_cache_reset();
}

/** 让 hnim_setting 的进程内缓存失效 */
function hnim_setting_cache_reset(): void
{
    // hnim_setting 用 static 缓存，这里用一个全局标记让它下次重建
    $GLOBALS['__hnim_setting_dirty'] = true;
}

/** 仅用于安装向导：尝试连接，失败抛异常 */
function hnim_db_try(array $db): PDO
{
    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    if (($db['driver'] ?? 'mysql') === 'sqlite') {
        $path = $db['path'] ?? (HNIM_DATA . '/hnim.sqlite');
        $dir  = dirname($path);
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $pdo = new PDO('sqlite:' . $path, null, null, $opts);
        $pdo->exec('PRAGMA journal_mode = WAL');
        $pdo->exec('PRAGMA busy_timeout = 8000');
        return $pdo;
    }

    $host = trim((string) ($db['host'] ?? ''));
    $name = trim((string) ($db['name'] ?? ''));
    $port = (int) ($db['port'] ?? 3306);
    if ($host === '') {
        throw new RuntimeException('请填写数据库地址');
    }
    if ($name === '') {
        throw new RuntimeException('请填写数据库名称');
    }
    $charset = (string) ($db['charset'] ?? 'utf8mb4');
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";
    try {
        $pdo = new PDO($dsn, (string) ($db['user'] ?? 'root'), (string) ($db['pass'] ?? ''), $opts);
    } catch (PDOException $e) {
        throw new RuntimeException('连接数据库失败：' . $e->getMessage());
    }
    $pdo->exec("SET NAMES {$charset}");
    return $pdo;
}

/* ------------------------------------------------------------------ *
 *  请求上下文
 * ------------------------------------------------------------------ */

/** 是否为 AJAX / API 调用 */
function hnim_is_api(): bool
{
    return str_contains((string) ($_SERVER['SCRIPT_NAME'] ?? ''), 'api')
        || (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest')
        || str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json');
}

/** 相对当前页的 URL 前缀（用于 USB 环境下子目录部署） */
function hnim_base_url(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }
    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    $dir    = rtrim(str_replace('\\', '/', dirname($script)), '/');
    // 目录部署时 dirname 为 /foo，站点根时为 /
    $base = ($dir === '/' || $dir === '.') ? '' : $dir;
    return $base;
}

function hnim_url(string $path = ''): string
{
    $p = ltrim($path, '/');
    return hnim_base_url() . '/' . $p;
}

function hnim_asset(string $path): string
{
    $ver = @filemtime(HNIM_ROOT . '/assets/' . ltrim($path, '/'));
    return hnim_url('assets/' . ltrim($path, '/')) . ($ver ? '?v=' . $ver : '');
}

/**
 * 带版本号的静态资源 URL，路径相对站点根（不限 assets/ 下面）。
 *
 * 后台的 admin/style.css 用这个 —— hnim_asset() 写死了 assets/ 前缀，用不上。
 *
 * 为什么非要带 ?v=：改了样式以后浏览器还拿着旧缓存不改，
 * 「换了主题怎么没变」是最常见的一条售后问题，直接从文件 mtime 取版本号解决。
 *
 * 只接受程序里写死的路径，这里不做用户输入校验的兜底，
 * 但仍然挡一下 ..，免得以后有人手滑把变量传进来。
 */
function hnim_asset_rel(string $path): string
{
    $p = ltrim(str_replace('\\', '/', $path), '/');
    if ($p === '' || str_contains($p, '..')) {
        return hnim_url('assets/');
    }
    $ver = @filemtime(HNIM_ROOT . '/' . $p);
    return hnim_url($p) . ($ver ? '?v=' . $ver : '');
}

/** 站点根 URL（HTTP 用），用于分享链接 */
function hnim_origin(): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scheme = $https ? 'https' : 'http';
    return $scheme . '://' . $host . hnim_base_url();
}

/** 启动会话 */
function hnim_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $save = HNIM_DATA . '/sessions';
    if (!is_dir($save)) {
        @mkdir($save, 0700, true);
    }
    session_save_path($save);
    session_name('HNIMSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => hnim_base_url() . '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    @session_start();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
}

function hnim_csrf(): string
{
    hnim_session_start();
    return (string) $_SESSION['csrf'];
}

function hnim_csrf_check(?string $token): bool
{
    hnim_session_start();
    return is_string($token) && hash_equals((string) $_SESSION['csrf'], $token);
}

function hnim_client_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64);
}

function hnim_ua(): string
{
    return substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
}

/** 读取请求参数（POST 优先，其次 JSON body） */
function hnim_input(string $key, $default = null)
{
    static $json = null;
    if ($json === null) {
        $json = [];
        $ct = (string) ($_SERVER['CONTENT_TYPE'] ?? '');
        if (str_contains($ct, 'application/json')) {
            $raw = file_get_contents('php://input');
            if ($raw !== false && $raw !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $json = $decoded;
                }
            }
        }
    }
    if (array_key_exists($key, $_POST)) {
        return $_POST[$key];
    }
    if (array_key_exists($key, $json)) {
        return $json[$key];
    }
    if (array_key_exists($key, $_GET)) {
        return $_GET[$key];
    }
    return $default;
}

function hnim_int($v, int $default = 0): int
{
    return is_numeric($v) ? (int) $v : $default;
}

/**
 * 把可能的各种写法统一成 id 列表。
 * 前端发的是 members[]=1&members[]=2 或 JSON 数组；但表单客户端、curl、
 * 手写接口很容易只发 "1,2" / "1 2" / "System.Object[]" 这类字符串，
 * 这里全部兜住，避免成员被静默丢掉。
 */
function hnim_id_list($v): array
{
    if (is_string($v)) {
        $v = trim($v);
        if ($v === '') {
            return [];
        }
        if (str_starts_with($v, '[') || str_starts_with($v, '{')) {
            $decoded = json_decode($v, true);
            $v = is_array($decoded) ? $decoded : preg_split('/[\s,;|]+/', $v);
        } else {
            $v = preg_split('/[\s,;|]+/', $v);
        }
    }
    if (!is_array($v)) {
        $v = [$v];
    }
    $out = [];
    foreach ($v as $x) {
        if (is_array($x) || is_object($x)) {
            continue;
        }
        $x = is_string($x) ? trim($x) : $x;
        if ($x === '' || !is_numeric($x)) {
            continue;
        }
        $out[] = (int) $x;
    }
    return array_values(array_unique($out));
}

function hnim_str($v, string $default = '', int $max = 2000): string
{
    if (!is_scalar($v)) {
        return $default;
    }
    $s = trim((string) $v);
    if (function_exists('mb_substr')) {
        return mb_substr($s, 0, $max, 'UTF-8');
    }
    return substr($s, 0, $max);
}

/**
 * 生成一个随机强密码（安装向导里管理员密码留空时用）。
 * 刻意排除容易看错的 0/O/1/l/I，方便人抄到纸上。
 */
function hnim_random_password(int $len = 12): string
{
    $lower = 'abcdefghjkmnpqrstuvwxyz';
    $upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    $digit = '23456789';
    $sym   = '!@#$%^&*-_=+';
    $all   = $lower . $upper . $digit . $sym;

    // 每类至少一个，保证复杂度下限
    $out = [
        $lower[random_int(0, strlen($lower) - 1)],
        $upper[random_int(0, strlen($upper) - 1)],
        $digit[random_int(0, strlen($digit) - 1)],
        $sym[random_int(0, strlen($sym) - 1)],
    ];
    for ($i = count($out); $i < $len; $i++) {
        $out[] = $all[random_int(0, strlen($all) - 1)];
    }
    // Fisher-Yates 洗牌，避免固定位置暴露"第一位必是小写"之类的规律
    for ($i = count($out) - 1; $i > 0; $i--) {
        $j = random_int(0, $i);
        [$out[$i], $out[$j]] = [$out[$j], $out[$i]];
    }
    return implode('', $out);
}
