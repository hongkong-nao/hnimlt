<?php
/**
 * HNIM 数据库结构定义
 * 同一份模板同时兼容 MySQL/MariaDB 与 SQLite 便携模式。
 */
declare(strict_types=1);

/**
 * 生成建表语句
 *
 * 差异点：
 *  - 主键自增写法
 *  - 索引：MySQL 写在 CREATE TABLE 内部，SQLite 用 CREATE INDEX IF NOT EXISTS
 *  - 表后缀（ENGINE / CHARSET）
 */
function hnim_schema_statements(string $driver): array
{
    $sqlite = ($driver === 'sqlite');

    if ($sqlite) {
        $pk  = 'id INTEGER PRIMARY KEY AUTOINCREMENT';
        $sfx = '';
    } else {
        // 主键必须和 AUTO_INCREMENT 写在同一处：MySQL 不接受「有自增列但没把它设成键」，
        // 会直接报 1075（Incorrect table definition; there can be only one auto column
        // and it must be defined as a key）。
        // 以前这里有两个变量（$pk / $pkInc），只有 $pkInc 带 PRIMARY KEY，
        // 而 SQLite 分支里两者一模一样 —— 所以本地用 SQLite 怎么测都测不出来，
        // 一上真 MySQL 就有几张表建不出来。现在只留一个变量，用错的可能性直接归零。
        $pk  = 'id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY';
        $sfx = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    }

    $t = [];

    /* ---------------- 用户（账号库） ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS users (
        {$pk},
        username   VARCHAR(32)  NOT NULL,
        password   VARCHAR(255) NOT NULL,
        nickname   VARCHAR(32)  NOT NULL,
        avatar     VARCHAR(255) NOT NULL DEFAULT '',
        signature  VARCHAR(120) NOT NULL DEFAULT '',
        role       VARCHAR(16)  NOT NULL DEFAULT 'user',
        email      VARCHAR(128) NOT NULL DEFAULT '',
        email_ok   TINYINT      NOT NULL DEFAULT 0,
        banned     TINYINT      NOT NULL DEFAULT 0,
        ban_reason VARCHAR(120) NOT NULL DEFAULT '',
        online     TINYINT      NOT NULL DEFAULT 0,
        last_seen  BIGINT       NOT NULL DEFAULT 0,
        created_at BIGINT       NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 邮件验证码（账号库） ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS email_codes (
        {$pk},
        email      VARCHAR(128) NOT NULL,
        code       VARCHAR(12)  NOT NULL,
        purpose    VARCHAR(16)  NOT NULL DEFAULT 'register',
        ip         VARCHAR(64)  NOT NULL DEFAULT '',
        send_at    BIGINT       NOT NULL DEFAULT 0,
        expire_at  BIGINT       NOT NULL DEFAULT 0,
        used       TINYINT      NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 后台设置（账号库） ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS settings (
        k          VARCHAR(64) NOT NULL,
        v          TEXT,
        updated_at BIGINT      NOT NULL DEFAULT 0,
        PRIMARY KEY (k)
    ){$sfx}";

    /* ---------------- 后台操作日志（账号库） ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS admin_log (
        {$pk},
        admin      VARCHAR(32)  NOT NULL DEFAULT '',
        action     VARCHAR(64)  NOT NULL DEFAULT '',
        detail     VARCHAR(255) NOT NULL DEFAULT '',
        ip         VARCHAR(64)  NOT NULL DEFAULT '',
        created_at BIGINT       NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 会话 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS conversations (
        {$pk},
        type      VARCHAR(16) NOT NULL DEFAULT 'single',
        gno       VARCHAR(16) NULL DEFAULT NULL,
        title     VARCHAR(64) NOT NULL DEFAULT '',
        avatar    VARCHAR(255) NOT NULL DEFAULT '',
        owner_id  BIGINT      NOT NULL DEFAULT 0,
        announcement VARCHAR(255) NOT NULL DEFAULT '',
        all_muted TINYINT NOT NULL DEFAULT 0,
        created_at BIGINT     NOT NULL DEFAULT 0
    ){$sfx}";

    $t[] = "CREATE TABLE IF NOT EXISTS conversation_members (
        conversation_id BIGINT NOT NULL,
        user_id         BIGINT NOT NULL,
        unread          INTEGER NOT NULL DEFAULT 0,
        last_read_id    BIGINT  NOT NULL DEFAULT 0,
        muted           TINYINT NOT NULL DEFAULT 0,
        role            VARCHAR(16) NOT NULL DEFAULT 'member',
        mute_until      BIGINT  NOT NULL DEFAULT 0,
        card            VARCHAR(32) NOT NULL DEFAULT '',
        joined_at       BIGINT  NOT NULL DEFAULT 0,
        PRIMARY KEY (conversation_id, user_id)
    ){$sfx}";

    /* ---------------- 正在输入 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS typing_state (
        conversation_id BIGINT NOT NULL,
        user_id         BIGINT NOT NULL,
        typing_at       BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (conversation_id, user_id)
    ){$sfx}";

    /* ---------------- 消息 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS messages (
        {$pk},
        conversation_id BIGINT NOT NULL,
        sender_id       BIGINT NOT NULL,
        type            VARCHAR(16) NOT NULL DEFAULT 'text',
        content         TEXT,
        meta            TEXT,
        recall_until    BIGINT NOT NULL DEFAULT 0,
        recalled_at     BIGINT NOT NULL DEFAULT 0,
        reply_to        BIGINT NOT NULL DEFAULT 0,
        mentions        TEXT,
        created_at      BIGINT NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 收藏 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS favorites (
        {$pk},
        user_id    BIGINT      NOT NULL,
        message_id BIGINT      NOT NULL,
        created_at BIGINT      NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 入群申请 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS group_requests (
        {$pk},
        conversation_id BIGINT      NOT NULL,
        user_id         BIGINT      NOT NULL,
        reason          VARCHAR(120) NOT NULL DEFAULT '',
        status          INTEGER     NOT NULL DEFAULT 0,
        created_at      BIGINT      NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 好友分组 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS friend_groups (
        {$pk},
        user_id    BIGINT      NOT NULL,
        name       VARCHAR(32) NOT NULL DEFAULT '',
        sort_no    INTEGER     NOT NULL DEFAULT 0,
        created_at BIGINT      NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 黑名单 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS blocks (
        {$pk},
        user_id    BIGINT NOT NULL,
        block_id   BIGINT NOT NULL,
        created_at BIGINT NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 好友 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS friends (
        {$pk},
        user_id    BIGINT      NOT NULL,
        friend_id  BIGINT      NOT NULL,
        remark     VARCHAR(32) NOT NULL DEFAULT '',
        status     INTEGER     NOT NULL DEFAULT 0,
        group_id   BIGINT      NOT NULL DEFAULT 0,
        verify_msg VARCHAR(120) NOT NULL DEFAULT '',
        created_at BIGINT      NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 登录日志 ---------------- */
    $t[] = "CREATE TABLE IF NOT EXISTS login_log (
        {$pk},
        user_id    BIGINT       NOT NULL DEFAULT 0,
        ip         VARCHAR(64)  NOT NULL DEFAULT '',
        ua         VARCHAR(255) NOT NULL DEFAULT '',
        ok         INTEGER      NOT NULL DEFAULT 0,
        created_at BIGINT       NOT NULL DEFAULT 0
    ){$sfx}";

    /* ---------------- 索引 ---------------- */
    if ($sqlite) {
        $t[] = 'CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users (username)';
        $t[] = 'CREATE INDEX IF NOT EXISTS idx_email_codes ON email_codes (email, purpose, used)';
        $t[] = 'CREATE UNIQUE INDEX IF NOT EXISTS idx_friend_pair   ON friends (user_id, friend_id)';
        $t[] = 'CREATE INDEX IF NOT EXISTS idx_cm_user   ON conversation_members (user_id)';
        $t[] = 'CREATE INDEX IF NOT EXISTS idx_msg_conv   ON messages (conversation_id, id)';
        $t[] = 'CREATE INDEX IF NOT EXISTS idx_msg_created ON messages (created_at)';
        $t[] = 'CREATE UNIQUE INDEX IF NOT EXISTS idx_conv_gno  ON conversations (gno)';
        $t[] = 'CREATE UNIQUE INDEX IF NOT EXISTS idx_fav_pair  ON favorites (user_id, message_id)';
        $t[] = 'CREATE INDEX IF NOT EXISTS idx_greq_conv ON group_requests (conversation_id, status)';
    } else {
        // 单聊的 gno 是 NULL，唯一索引允许多个 NULL，所以不会撞号
        $t[] = 'CREATE INDEX idx_email_codes ON email_codes (email, purpose, used)';
        $t[] = 'CREATE UNIQUE INDEX idx_conv_gno ON conversations (gno)';
        $t[] = 'CREATE UNIQUE INDEX idx_fav_pair ON favorites (user_id, message_id)';
        $t[] = 'CREATE INDEX idx_greq_conv ON group_requests (conversation_id, status)';
    }

    return $t;
}

/**
 * 表归属：账号库放账号相关，聊天库放聊天相关。
 * 聊天库没配（或连不上）时，这些表会退回账号库，保证单库模式照常能跑。
 */
function hnim_schema_is_chat_table(string $table): bool
{
    return in_array($table, [
        'conversations', 'conversation_members', 'messages',
        'typing_state', 'favorites', 'group_requests',
    ], true);
}

function hnim_schema_exists(PDO $pdo, string $table): bool
{
    try {
        $pdo->query("SELECT 1 FROM {$table} LIMIT 1");
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * 某张表该用哪个连接。
 *
 * 双库模式下聊天表在聊天库、账号表在账号库 —— 这是整个建表流程唯一的落位依据，
 * 所有地方都走这个函数，不要再各写一份判断。
 * （早先就是因为两处判断不一致，把聊天表的唯一索引建到了账号库上，
 *   同时还把 8 张账号表建进了聊天库。）
 */
function hnim_schema_conn(PDO $pdo, string $table, ?PDO $chatPdo = null): PDO
{
    if (!hnim_schema_is_chat_table($table)) {
        return $pdo;
    }
    // 单库模式下 hnim_chat_pdo() 会原样返回传进来的连接
    return hnim_chat_pdo($chatPdo ?: $pdo);
}

/**
 * 补齐后来新增的字段（老用户不重装也能用上）。
 * 只做“加列”，不删不改任何已有数据，重复执行安全。
 *
 * @param PDO      $pdo     账号库连接（$chatOnly 为 true 时其实是聊天库连接）
 * @param PDO|null $chatPdo 聊天库连接（双库模式）
 * @param bool     $chatOnly 只处理聊天表：which=chat 那一轮里 $pdo 指向的是聊天库，
 *                          这时再建账号表就会把它们塞进聊天库，必须跳过。
 * @return string[] 出错信息，空数组代表成功
 */
function hnim_schema_upgrade(PDO $pdo, string $driver, ?PDO $chatPdo = null, bool $chatOnly = false): array
{
    $add = [
        'conversations' => [
            'announcement' => "VARCHAR(255) NOT NULL DEFAULT ''",
            'all_muted'    => 'TINYINT NOT NULL DEFAULT 0',
            'gno'          => 'VARCHAR(16) NULL DEFAULT NULL',
        ],
        'conversation_members' => [
            'mute_until' => 'BIGINT NOT NULL DEFAULT 0',
            'card'       => "VARCHAR(32) NOT NULL DEFAULT ''",
        ],
        'messages' => [
            'recalled_at'  => 'BIGINT NOT NULL DEFAULT 0',
            'reply_to'     => 'BIGINT NOT NULL DEFAULT 0',
            'mentions'     => 'TEXT',
        ],
        'friends' => [
            'group_id'   => 'BIGINT NOT NULL DEFAULT 0',
            'verify_msg' => "VARCHAR(120) NOT NULL DEFAULT ''",
        ],
        'users' => [
            'email'       => "VARCHAR(128) NOT NULL DEFAULT ''",
            'email_ok'    => 'TINYINT NOT NULL DEFAULT 0',
            'banned'      => 'TINYINT NOT NULL DEFAULT 0',
            'ban_reason'  => "VARCHAR(120) NOT NULL DEFAULT ''",
        ],
    ];

    $errors = [];
    foreach ($add as $table => $cols) {
        if ($chatOnly && !hnim_schema_is_chat_table($table)) {
            continue;   // 这一轮 $pdo 是聊天库，账号表不归它管
        }
        // 聊天表：既要在聊天库上查有没有这列，也要在聊天库上加
        $tp = hnim_schema_conn($pdo, $table, $chatPdo);
        if (!hnim_schema_exists($tp, $table)) {
            continue;
        }
        try {
            if ($driver === 'sqlite') {
                $have = array_column($tp->query("PRAGMA table_info({$table})")->fetchAll(), 'name');
            } else {
                $have = array_column($tp->query("SHOW COLUMNS FROM {$table}")->fetchAll(), 'Field');
            }
        } catch (Throwable $e) {
            $errors[] = $table . ': ' . $e->getMessage();
            continue;
        }
        foreach ($cols as $col => $def) {
            if (in_array($col, $have, true)) {
                continue;
            }
            try {
                $tp->exec("ALTER TABLE {$table} ADD COLUMN {$col} {$def}");
            } catch (Throwable $e) {
                $errors[] = "{$table}.{$col}: " . $e->getMessage();
            }
        }
    }

    // 2) 整张新表直接建（CREATE TABLE IF NOT EXISTS，重复执行安全）
    foreach (['blocks', 'friend_groups', 'favorites', 'group_requests',
              'settings', 'admin_log', 'email_codes'] as $wanted) {
        if ($chatOnly && !hnim_schema_is_chat_table($wanted)) {
            continue;
        }
        foreach (hnim_schema_statements($driver) as $sql) {
            if (stripos($sql, "CREATE TABLE IF NOT EXISTS {$wanted} ") === 0) {
                try {
                    hnim_schema_conn($pdo, $wanted, $chatPdo)->exec($sql);
                } catch (Throwable $e) {
                    $errors[] = $wanted . ': ' . $e->getMessage();
                }
                break;
            }
        }
    }

    // 3) 唯一索引单独建：老库可能已经有重复的 gno（历史数据），建索引要容错。
    //    按“表名”落位，不再靠索引名去猜它属于哪张表。
    foreach ([
        'conversations'  => 'CREATE UNIQUE INDEX ' . ($driver === 'sqlite' ? 'IF NOT EXISTS ' : '')
                          . 'idx_conv_gno ON conversations (gno)',
        'favorites'      => 'CREATE UNIQUE INDEX ' . ($driver === 'sqlite' ? 'IF NOT EXISTS ' : '')
                          . 'idx_fav_pair ON favorites (user_id, message_id)',
        'group_requests' => 'CREATE INDEX ' . ($driver === 'sqlite' ? 'IF NOT EXISTS ' : '')
                          . 'idx_greq_conv ON group_requests (conversation_id, status)',
    ] as $table => $sql) {
        if ($chatOnly && !hnim_schema_is_chat_table($table)) {
            continue;
        }
        try {
            hnim_schema_conn($pdo, $table, $chatPdo)->exec($sql);
        } catch (Throwable $e) {
            // 索引重复（已在）或历史数据冲突都不影响功能，记一条日志就行
            if (stripos($e->getMessage(), 'exist') === false) {
                $errors[] = "{$table}: " . $e->getMessage();
            }
        }
    }

    return $errors;
}
