<?php
/**
 * HNIM 管理后台入口
 * ------------------------------------------------------------------
 * 只有 config/admin.php 里配置的账号能进；这个账号由 install.php 第 4 步
 * 由你自己设定，程序源码里没有任何默认账号或默认密码。
 * 后台分四块：概览、用户管理、邮件设置、操作日志。
 */
declare(strict_types=1);

/* 后台的删号 / 封禁 / 改密码这些动作也走 JSON 输出，
   同样要在 require 之前把输出管起来，理由见 api.php 里的注释。 */
if (function_exists('ob_start')) {
    ob_start();
}
@ini_set('display_errors', '0');
@ini_set('html_errors', '0');

require_once __DIR__ . '/app/core.php';
require_once __DIR__ . '/app/admin_auth.php';

hnim_output_guard();

hnim_require_installed();

hnim_session_start();

/* 后台账号配置必须在做任何事之前就位。这里不能像以前那样「缺了就自动补一个
   默认账号」——那样漏传一次 config/admin.php 就会生成一个密码人人皆知的超管。
   所以缺了就直接把原因显示出来，让人去补文件或重跑 install.php。 */
try {
    hnim_admin_ensure();
} catch (RuntimeException $e) {
    // hnim_output_guard() 开的缓冲要在这里自己收掉，否则下面 echo 的东西
    // 会和它抢同一个缓冲区，页面可能只显示一半。
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    $why = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>后台账号未配置</title>'
       . '<style>body{font:15px/1.8 system-ui,"Microsoft YaHei",sans-serif;margin:0;'
       . 'background:#f5f6f8;color:#222}main{max-width:640px;margin:12vh auto;padding:28px 32px;'
       . 'background:#fff;border:1px solid #e3e5e9;border-radius:12px}'
       . 'h1{font-size:20px;margin:0 0 14px;color:#b91c1c}p{margin:10px 0}'
       . 'code{background:#f2f3f5;padding:2px 6px;border-radius:4px;font-size:13px}'
       . 'a{color:#1d4ed8}</style></head><body><main>'
       . '<h1>后台无法进入：账号配置没就位</h1><p>' . $why . '</p>'
       . '<p>这是刻意设计的：后台账号只能由你自己设置，程序不会自动生成默认密码，'
       . '免得哪次漏传文件就凭空多出一个谁都能进的后台。</p>'
       . '<p>处理办法：打开 <code>install.php</code> 走一遍安装向导，'
       . '第 4 步会让你自己设定后台账号和密码；'
       . '或者把备份里的 <code>config/admin.php</code> 放回 <code>config/</code> 目录。</p>'
       . '<p><a href="index.php">← 返回首页</a></p>'
       . '</main></body></html>';
    exit;
}

$err = '';
$p   = hnim_str(hnim_input('p', 'dashboard'), 'dashboard', 20);

/* ---------------- 退出 ---------------- */
if ($p === 'logout') {
    hnim_admin_logout();
    header('Location: ' . hnim_url('admin.php'));
    exit;
}

/* ---------------- 登录 ---------------- */
if (!hnim_admin_logged() && $_SERVER['REQUEST_METHOD'] === 'POST' && hnim_input('do') === 'login') {
    $user = hnim_str(hnim_input('user', ''), '', 64);
    $pass = (string) hnim_input('pass', '');
    $key  = hnim_admin_try_key();
    $try  = $_SESSION[$key] ?? ['n' => 0, 'at' => 0];
    if ((int) $try['at'] > time() - 900 && (int) $try['n'] >= 5) {
        $err = '登录失败次数太多，请 15 分钟后再试。';
    } elseif (!hnim_csrf_check(hnim_input('csrf'))) {
        $err = '页面已过期，请刷新后重试。';
    } elseif ($user === '' || $pass === '') {
        $err = '请输入后台账号和密码。';
    } elseif (!hnim_admin_login($user, $pass)) {
        usleep(400000);
        $try = ((int) $try['at'] > time() - 900) ? $try : ['n' => 0, 'at' => time()];
        $try['n']  = (int) $try['n'] + 1;
        $try['at'] = time();
        $_SESSION[$key] = $try;
        $err = '账号或密码不对（还可以试 ' . max(0, 5 - (int) $try['n']) . ' 次）。';
    } else {
        unset($_SESSION[$key]);
        hnim_admin_log('登录后台', '');
        header('Location: ' . hnim_url('admin.php?p=dashboard'));
        exit;
    }
}

/* ---------------- 没登录就显示登录页 ---------------- */
if (!hnim_admin_logged()) {
    $csrf = hnim_csrf();
    ?>
<?php require_once __DIR__ . '/admin/layout.php'; ?>
<?php hnim_admin_doc('登录'); ?>
<body class="login-body">
<form class="login-card" method="post" autocomplete="off">
  <div class="login-logo">H</div>
  <h1>HNIM 管理后台</h1>
  <p class="login-sub">请使用后台管理员账号登录</p>
  <?php if ($err !== ''): ?><div class="alert err"><?= htmlspecialchars($err, ENT_QUOTES) ?></div><?php endif; ?>
  <input type="hidden" name="do" value="login">
  <input type="hidden" name="csrf" value="<?= $csrf ?>">
  <label>后台账号</label>
  <input type="text" name="user" placeholder="管理员账号" autofocus>
  <label>后台密码</label>
  <input type="password" name="pass" placeholder="请输入密码">
  <button class="btn primary" type="submit">登 录</button>
  <a class="back" href="<?= hnim_url('index.php') ?>">← 返回聊天</a>
</form>
</body>
</html>
    <?php
    exit;
}

/* ---------------- 已登录：加载版面 + 对应页面 ---------------- */
$pages = [
    'dashboard' => '概览',
    'users'     => '用户管理',
    'data'      => '数据清理',
    'mail'      => '邮件设置',
    'logs'      => '操作日志',
];
if (!isset($pages[$p])) {
    $p = 'dashboard';
}
$csrf = hnim_csrf();
$adminUser = hnim_admin_conf()['user'];
// layout.php 上面登录页已经 require 过一次，这里必须用 require_once
require_once __DIR__ . '/admin/layout.php';
hnim_admin_head($p === 'dashboard' ? '概览' : $pages[$p]);
require __DIR__ . '/admin/page-' . $p . '.php';
hnim_admin_foot();
