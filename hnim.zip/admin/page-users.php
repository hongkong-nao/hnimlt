<?php
/** HNIM 后台 · 用户管理（封禁 / 解封 / 删除 / 重置密码 / 改身份） */
declare(strict_types=1);

$acc  = hnim_db();
$chat = hnim_chat_db();
$msg  = '';
$msgType = 'ok';

/* ---------------- 处理动作 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do  = hnim_str(hnim_input('do', ''), '', 20);
    $id  = hnim_int(hnim_input('id', 0));
    $back = hnim_url('admin.php?p=users');

    if (!hnim_csrf_check(hnim_input('csrf'))) {
        $msg = '页面已过期，请刷新后重试。';
        $msgType = 'err';
    } elseif ($id <= 0) {
        $msg = '参数不对，请重新操作。';
        $msgType = 'err';
    } else {
        $target = hnim_user_by_id($id, $acc);
        if (!$target) {
            $msg = '这个用户不存在，可能已经被删掉了。';
            $msgType = 'err';
        } else {
            switch ($do) {
                case 'ban':
                    $reason = hnim_str(hnim_input('reason', ''), '', 120);
                    $st = $acc->prepare('UPDATE users SET banned = 1, ban_reason = ? WHERE id = ?');
                    $st->execute([$reason !== '' ? $reason : '违反使用规定', $id]);
                    hnim_admin_log('封禁用户', '#' . $id . ' ' . $target['username'] . ' ' . $reason);
                    $msg = '已封禁「' . $target['nickname'] . '」，TA 将无法登录。';
                    break;

                case 'unban':
                    $st = $acc->prepare('UPDATE users SET banned = 0, ban_reason = \'\' WHERE id = ?');
                    $st->execute([$id]);
                    hnim_admin_log('解封用户', '#' . $id . ' ' . $target['username']);
                    $msg = '已解封「' . $target['nickname'] . '」。';
                    break;

                case 'pass':
                    $new = (string) hnim_input('newpass', '');
                    if (strlen($new) < 6) {
                        $msg = '新密码至少 6 位。';
                        $msgType = 'err';
                        break;
                    }
                    $st = $acc->prepare('UPDATE users SET password = ? WHERE id = ?');
                    $st->execute([password_hash($new, PASSWORD_DEFAULT), $id]);
                    hnim_admin_log('重置密码', '#' . $id . ' ' . $target['username']);
                    $msg = '已把「' . $target['nickname'] . '」的密码改成你填的新密码。';
                    break;

                case 'role':
                    $role = hnim_input('role') === 'admin' ? 'admin' : 'user';
                    $st = $acc->prepare('UPDATE users SET role = ? WHERE id = ?');
                    $st->execute([$role, $id]);
                    hnim_admin_log('修改身份', '#' . $id . ' -> ' . $role);
                    $msg = '已把「' . $target['nickname'] . '」设为' . ($role === 'admin' ? '管理员' : '普通用户') . '。';
                    break;

                case 'edit':
                    $nick  = hnim_str(hnim_input('nickname', ''), '', 32);
                    $email = hnim_str(hnim_input('email', ''), '', 128);
                    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $msg = '邮箱格式不正确。';
                        $msgType = 'err';
                        break;
                    }
                    $st = $acc->prepare('UPDATE users SET nickname = ?, email = ? WHERE id = ?');
                    $st->execute([$nick !== '' ? $nick : $target['username'], $email, $id]);
                    hnim_admin_log('修改资料', '#' . $id . ' ' . $target['username']);
                    $msg = '资料已更新。';
                    break;

                case 'delete':
                    if (hnim_input('confirm') !== 'yes') {
                        $msg = '删除前请先勾选确认框。';
                        $msgType = 'err';
                        break;
                    }
                    hnim_user_purge($id);
                    hnim_admin_log('删除用户', '#' . $id . ' ' . $target['username']);
                    $msg = '已删除「' . $target['nickname'] . '」及其好友、会话、收藏等数据。';
                    break;

                default:
                    $msg = '未知操作。';
                    $msgType = 'err';
            }
        }
    }
}

/* ---------------- 查询列表 ---------------- */
$kw   = hnim_str(hnim_input('kw', ''), '', 64);
$page = max(1, hnim_int(hnim_input('page', 1), 1));
$per  = 20;
$off  = ($page - 1) * $per;

$where = '';
$args  = [];
if ($kw !== '') {
    $where = 'WHERE username LIKE ? OR nickname LIKE ? OR email LIKE ?';
    $like  = '%' . $kw . '%';
    $args  = [$like, $like, $like];
}

$total = 0;
$rows  = [];
try {
    $st = $acc->prepare('SELECT COUNT(*) FROM users ' . $where);
    $st->execute($args);
    $total = (int) $st->fetchColumn();

    $st = $acc->prepare(
        'SELECT id, username, nickname, email, email_ok, role, banned, ban_reason, online, last_seen, created_at
         FROM users ' . $where . ' ORDER BY id DESC LIMIT ' . $per . ' OFFSET ' . $off
    );
    $st->execute($args);
    $rows = $st->fetchAll();
} catch (Throwable $e) {
    $msg = '读取用户列表失败：' . $e->getMessage();
    $msgType = 'err';
}

$pages = max(1, (int) ceil($total / $per));
$qs = $kw !== '' ? '&kw=' . urlencode($kw) : '';
?>

<?php if ($msg !== ''): ?>
  <div class="alert <?= $msgType ?>"><?= hnim_admin_e($msg) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-hd">
    <h2>全部用户（共 <?= $total ?> 个）</h2>
    <span class="sub">封禁后对方无法登录；删除会连同好友、会话、收藏一起清掉</span>
  </div>

  <form class="filter" method="get" action="<?= hnim_url('admin.php') ?>">
    <input type="hidden" name="p" value="users">
    <input type="text" name="kw" value="<?= hnim_admin_e($kw) ?>" placeholder="按账号 / 昵称 / 邮箱搜索">
    <button class="btn primary sm" type="submit">搜索</button>
    <?php if ($kw !== ''): ?><a class="btn sm" href="<?= hnim_url('admin.php?p=users') ?>">清空</a><?php endif; ?>
  </form>

  <div class="card-bd" style="padding:0">
    <table class="tbl">
      <thead>
        <tr>
          <th>ID</th><th>账号</th><th>昵称</th><th>邮箱</th><th>身份</th><th>状态</th><th>注册</th><th>操作</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="8" class="empty">没有找到符合条件的用户</td></tr>
      <?php else: foreach ($rows as $u): ?>
        <tr>
          <td class="mono"><?= (int) $u['id'] ?></td>
          <td><b><?= hnim_admin_e($u['username']) ?></b></td>
          <td><?= hnim_admin_e($u['nickname']) ?></td>
          <td class="mono"><?= $u['email'] !== '' ? hnim_admin_e($u['email']) : '<span class="muted">未绑定</span>' ?></td>
          <td><?= $u['role'] === 'admin' ? '<span class="badge blue">管理员</span>' : '<span class="badge gray">用户</span>' ?></td>
          <td>
            <?php if ((int) $u['banned'] === 1): ?>
              <span class="badge red">已封禁</span>
              <?php if ($u['ban_reason'] !== ''): ?><div class="hint"><?= hnim_admin_e($u['ban_reason']) ?></div><?php endif; ?>
            <?php elseif ((int) $u['last_seen'] > time() - 300): ?>
              <span class="badge green">在线</span>
            <?php else: ?>
              <span class="badge gray">离线</span>
            <?php endif; ?>
          </td>
          <td class="muted"><?= hnim_admin_time($u['created_at']) ?></td>
          <td>
            <div class="btn-row">
              <?php if ((int) $u['banned'] === 1): ?>
                <form method="post" style="display:inline">
                  <input type="hidden" name="csrf" value="<?= $csrf ?>">
                  <input type="hidden" name="do" value="unban">
                  <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                  <button class="btn ok sm" type="submit">解封</button>
                </form>
              <?php else: ?>
                <button class="btn danger sm" type="button"
                  onclick="hnimBan(<?= (int) $u['id'] ?>, '<?= hnim_admin_e(addslashes($u['nickname'])) ?>')">封禁</button>
              <?php endif; ?>
              <button class="btn sm" type="button"
                onclick="hnimPass(<?= (int) $u['id'] ?>, '<?= hnim_admin_e(addslashes($u['nickname'])) ?>')">改密码</button>
              <button class="btn sm" type="button"
                onclick="hnimEdit(<?= (int) $u['id'] ?>,
                  '<?= hnim_admin_e(addslashes($u['nickname'])) ?>',
                  '<?= hnim_admin_e(addslashes($u['email'])) ?>')">改资料</button>
              <form method="post" style="display:inline"
                    onsubmit="return confirm('确定要删除「<?= hnim_admin_e(addslashes($u['nickname'])) ?>」吗？\n\nTA 的好友、会话、收藏都会被清除，且无法恢复。');">
                <input type="hidden" name="csrf" value="<?= $csrf ?>">
                <input type="hidden" name="do" value="delete">
                <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                <input type="hidden" name="confirm" value="yes">
                <button class="btn danger sm" type="submit">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($pages > 1): ?>
  <div class="pager">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <?php if ($i === $page): ?>
        <span class="on"><?= $i ?></span>
      <?php else: ?>
        <a href="<?= hnim_url('admin.php?p=users&page=' . $i . $qs) ?>"><?= $i ?></a>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<!-- 封禁 / 改密码 / 改资料：内联小弹窗 -->
<div class="modal-mask" id="aMask" style="display:none">
  <form class="modal-box" method="post" id="aForm">
    <input type="hidden" name="csrf" value="<?= $csrf ?>">
    <input type="hidden" name="do" id="aDo">
    <input type="hidden" name="id" id="aId">
    <h3 id="aTitle">操作</h3>
    <div id="aReason" style="display:none">
      <label class="f">封禁原因（对方登录时能看到）</label>
      <input type="text" name="reason" id="aReasonInput" placeholder="例如：发布违规内容">
    </div>
    <div id="aPass" style="display:none">
      <label class="f">新密码（至少 6 位）</label>
      <input type="text" name="newpass" id="aPassInput" placeholder="给 TA 设置一个新密码">
    </div>
    <div id="aEdit" style="display:none">
      <label class="f">昵称</label>
      <input type="text" name="nickname" id="aNick">
      <label class="f" style="margin-top:10px">邮箱</label>
      <input type="text" name="email" id="aEmail" placeholder="留空表示不绑定邮箱">
    </div>
    <div class="modal-acts">
      <button class="btn" type="button" onclick="hnimCloseModal()">取消</button>
      <button class="btn primary" type="submit">确定</button>
    </div>
  </form>
</div>

<style>
.modal-mask{position:fixed;inset:0;background:rgba(15,22,40,.5);display:grid;place-items:center;z-index:50;padding:20px}
.modal-box{background:#fff;border-radius:14px;padding:22px;width:100%;max-width:400px;box-shadow:0 24px 60px rgba(0,0,0,.3)}
.modal-box h3{font-size:15.5px;margin-bottom:14px}
.modal-box label.f{display:block;margin-bottom:6px}
.modal-acts{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}
</style>
<script>
function hnimOpenModal(){document.getElementById('aMask').style.display='grid';}
function hnimCloseModal(){
  document.getElementById('aMask').style.display='none';
  ['aReason','aPass','aEdit'].forEach(function(i){document.getElementById(i).style.display='none';});
}
function hnimBan(id,name){
  document.getElementById('aDo').value='ban';
  document.getElementById('aId').value=id;
  document.getElementById('aTitle').textContent='封禁用户 · '+name;
  document.getElementById('aReason').style.display='block';
  hnimOpenModal();
}
function hnimPass(id,name){
  document.getElementById('aDo').value='pass';
  document.getElementById('aId').value=id;
  document.getElementById('aTitle').textContent='重置密码 · '+name;
  document.getElementById('aPass').style.display='block';
  document.getElementById('aPassInput').value='';
  hnimOpenModal();
}
function hnimEdit(id,name,email){
  document.getElementById('aDo').value='edit';
  document.getElementById('aId').value=id;
  document.getElementById('aTitle').textContent='修改资料 · '+name;
  document.getElementById('aEdit').style.display='block';
  document.getElementById('aNick').value=name;
  document.getElementById('aEmail').value=email;
  hnimOpenModal();
}
</script>
