<?php
/** HNIM 后台 · 概览 */
declare(strict_types=1);

$acc  = hnim_db();
$chat = hnim_chat_db();

$stat = static function (PDO $pdo, string $sql): int {
    try {
        return (int) $pdo->query($sql)->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
};

$nUsers  = $stat($acc, 'SELECT COUNT(*) FROM users');
$nBanned = $stat($acc, 'SELECT COUNT(*) FROM users WHERE banned = 1');
$nOnline = $stat($acc, 'SELECT COUNT(*) FROM users WHERE last_seen > ' . (time() - 300));
$nGroups = $stat($chat, "SELECT COUNT(*) FROM conversations WHERE type = 'group'");
$nConvs  = $stat($chat, 'SELECT COUNT(*) FROM conversations');
$nMsgs   = $stat($chat, 'SELECT COUNT(*) FROM messages');
$nToday  = $stat($acc, 'SELECT COUNT(*) FROM users WHERE created_at >= ' . strtotime('today'));

$dbCheck  = hnim_chat_db_check();
$smtpWhy  = hnim_smtp_ready();
$smtpConf = hnim_smtp_conf();

$recent = [];
try {
    $recent = $acc->query('SELECT id, username, nickname, email, banned, created_at FROM users ORDER BY id DESC LIMIT 8')->fetchAll();
} catch (Throwable $e) {
    $recent = [];
}
?>

<div class="grid cols-4">
  <div class="stat"><div class="n"><?= $nUsers ?></div><div class="t">注册用户（今天新增 <?= $nToday ?>）</div></div>
  <div class="stat"><div class="n"><?= $nOnline ?></div><div class="t">最近 5 分钟在线</div></div>
  <div class="stat"><div class="n"><?= $nGroups ?></div><div class="t">群聊数量</div></div>
  <div class="stat"><div class="n"><?= $nMsgs ?></div><div class="t">聊天消息总数</div></div>
</div>

<div class="grid cols-2" style="margin-top:20px">
  <div class="card">
    <div class="card-hd"><h2>运行状态</h2></div>
    <div class="card-bd">
      <div class="kv"><div class="k">账号数据库</div><div class="v">
        <?php if ((string) hnim_config('db.driver', 'mysql') === 'sqlite'): ?>
          SQLite 便携模式
        <?php else: ?>
          <span class="mono"><?= hnim_admin_e(hnim_config('db.host', '') . ':' . hnim_config('db.port', 3306)) ?> / <?= hnim_admin_e(hnim_config('db.name', '')) ?></span>
        <?php endif; ?>
      </div></div>
      <div class="kv"><div class="k">聊天数据库</div><div class="v">
        <?php if (hnim_chat_db_enabled()): ?>
          <span class="badge <?= $dbCheck['ok'] ? 'green' : 'red' ?>"><?= $dbCheck['ok'] ? '已连接' : '连接失败' ?></span>
          <span class="mono muted" style="margin-left:6px"><?= hnim_admin_e(hnim_config('chat.host', '') . ':' . hnim_config('chat.port', 3306)) ?> / <?= hnim_admin_e(hnim_config('chat.name', '')) ?></span>
          <div class="hint" style="margin-top:4px"><?= hnim_admin_e($dbCheck['msg']) ?></div>
        <?php else: ?>
          <span class="badge gray">与账号库共用</span>
        <?php endif; ?>
      </div></div>
      <div class="kv"><div class="k">会话 / 消息</div><div class="v"><?= $nConvs ?> 个会话，<?= $nMsgs ?> 条消息</div></div>
      <div class="kv"><div class="k">被封禁账号</div><div class="v"><?= $nBanned ?> 个</div></div>
      <div class="kv"><div class="k">程序版本</div><div class="v">HNIM v<?= HNIM_VERSION ?></div></div>
    </div>
  </div>

  <div class="card">
    <div class="card-hd">
      <h2>邮件服务</h2>
      <a class="btn sm" href="<?= hnim_url('admin.php?p=mail') ?>">去设置</a>
    </div>
    <div class="card-bd">
      <?php if ($smtpWhy === null): ?>
        <div class="alert ok" style="margin:0 0 14px">邮件服务已配置，注册可以正常收发验证码。</div>
      <?php else: ?>
        <div class="alert err" style="margin:0 0 14px">
          <b>邮件服务未就绪，注册入口已自动关闭。</b><br>
          <?= hnim_admin_e($smtpWhy) ?>，请到「邮件设置」里填写。
        </div>
      <?php endif; ?>
      <div class="kv"><div class="k">发信服务器</div><div class="v mono"><?= $smtpConf['host'] !== '' ? hnim_admin_e($smtpConf['host'] . ':' . $smtpConf['port'] . ' (' . $smtpConf['secure'] . ')') : '—' ?></div></div>
      <div class="kv"><div class="k">发件邮箱</div><div class="v mono"><?= $smtpConf['from'] !== '' ? hnim_admin_e($smtpConf['from']) : '—' ?></div></div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-hd">
    <h2>最近注册</h2>
    <a class="btn sm" href="<?= hnim_url('admin.php?p=users') ?>">全部用户</a>
  </div>
  <table class="tbl">
    <thead><tr><th>ID</th><th>账号</th><th>昵称</th><th>邮箱</th><th>状态</th><th>注册时间</th></tr></thead>
    <tbody>
    <?php if (!$recent): ?>
      <tr><td colspan="6" class="empty">还没有用户</td></tr>
    <?php else: foreach ($recent as $r): ?>
      <tr>
        <td class="mono"><?= (int) $r['id'] ?></td>
        <td><?= hnim_admin_e($r['username']) ?></td>
        <td><?= hnim_admin_e($r['nickname']) ?></td>
        <td class="mono"><?= $r['email'] !== '' ? hnim_admin_e($r['email']) : '<span class="muted">未绑定</span>' ?></td>
        <td><?= (int) $r['banned'] === 1 ? '<span class="badge red">已封禁</span>' : '<span class="badge green">正常</span>' ?></td>
        <td class="muted"><?= hnim_admin_time($r['created_at']) ?></td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
