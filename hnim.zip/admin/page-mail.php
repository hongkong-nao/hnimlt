<?php
/** HNIM 后台 · 邮件设置（SMTP） */
declare(strict_types=1);

$msg = '';
$msgType = 'ok';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = hnim_str(hnim_input('do', ''), '', 20);
    if (!hnim_csrf_check(hnim_input('csrf'))) {
        $msg = '页面已过期，请刷新后重试。';
        $msgType = 'err';
    } elseif ($do === 'save') {
        $secure = (string) hnim_input('secure', 'ssl');
        if (!in_array($secure, ['none', 'ssl', 'tls'], true)) {
            $secure = 'ssl';
        }
        hnim_smtp_save([
            'enabled'   => (string) hnim_input('enabled', '') === '1',
            'host'      => (string) hnim_input('host', ''),
            'port'      => (int) hnim_input('port', 465),
            'secure'    => $secure,
            'user'      => (string) hnim_input('user', ''),
            'pass'      => (string) hnim_input('pass', ''),
            'from'      => (string) hnim_input('from', ''),
            'from_name' => (string) hnim_input('from_name', ''),
        ]);
        hnim_admin_log('保存邮件设置', (string) hnim_input('host', ''));
        $msg = '邮件设置已保存。建议点下面的「发送测试邮件」验证一下。';
    } elseif ($do === 'test') {
        $to = hnim_str(hnim_input('test_to', ''), '', 128);
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            $msg = '请填写一个用来接收测试邮件的邮箱。';
            $msgType = 'err';
        } else {
            $r = hnim_smtp_test($to);
            if ($r['ok']) {
                $msg = '测试邮件已发出，请到 ' . $to . ' 的收件箱（和垃圾箱）里查收。';
            } else {
                $msg = '发送失败：' . (string) ($r['error'] ?? '未知错误');
                $msgType = 'err';
            }
            hnim_admin_log('邮件测试', $to . ' ' . ($r['ok'] ? '成功' : '失败'));
        }
    }
}

$c    = hnim_smtp_conf();
$why  = hnim_smtp_ready();
$passSet = $c['pass'] !== '';
?>

<?php if ($msg !== ''): ?>
  <div class="alert <?= $msgType ?>"><?= hnim_admin_e($msg) ?></div>
<?php endif; ?>

<?php if ($why === null): ?>
  <div class="alert ok"><b>邮件服务已就绪</b>：用户注册时会收到邮箱验证码。</div>
<?php else: ?>
  <div class="alert err"><b>邮件服务还没就绪</b>（<?= hnim_admin_e($why) ?>）：现在注册入口是关闭的，填好下面这些并保存即可开放。</div>
<?php endif; ?>

<div class="card">
  <div class="card-hd">
    <h2>SMTP 发信设置</h2>
    <span class="sub">注册验证码、测试邮件都通过这里发出</span>
  </div>
  <div class="card-bd">
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $csrf ?>">
      <input type="hidden" name="do" value="save">

      <div class="form-row">
        <label class="check">
          <input type="checkbox" name="enabled" value="1" <?= $c['enabled'] ? 'checked' : '' ?>>
          <span>启用邮件服务（关闭后注册入口也会一起关闭）</span>
        </label>
      </div>

      <div class="form-grid">
        <div class="form-row">
          <label class="f"><i>*</i>SMTP 服务器地址</label>
          <input type="text" name="host" value="<?= hnim_admin_e($c['host']) ?>" placeholder="smtp.qq.com">
          <span class="hint">QQ 邮箱 smtp.qq.com；163 邮箱 smtp.163.com；阿里云 smtp.mxhichina.com</span>
        </div>
        <div class="form-row">
          <label class="f">端口</label>
          <input type="number" name="port" value="<?= (int) $c['port'] ?>" placeholder="465">
          <span class="hint">465（SSL）或 587（TLS）最常用</span>
        </div>
        <div class="form-row">
          <label class="f">加密方式</label>
          <select name="secure">
            <option value="ssl"  <?= $c['secure'] === 'ssl'  ? 'selected' : '' ?>>SSL（端口一般 465）</option>
            <option value="tls"  <?= $c['secure'] === 'tls'  ? 'selected' : '' ?>>STARTTLS（端口一般 587）</option>
            <option value="none" <?= $c['secure'] === 'none' ? 'selected' : '' ?>>不加密（内网服务器 25）</option>
          </select>
        </div>
        <div class="form-row">
          <label class="f"><i>*</i>发信邮箱账号</label>
          <input type="text" name="user" value="<?= hnim_admin_e($c['user']) ?>" placeholder="noreply@example.com">
        </div>
        <div class="form-row">
          <label class="f"><i>*</i>邮箱授权码 / 密码</label>
          <input type="password" name="pass" value=""
                 placeholder="<?= $passSet ? '已保存，留空表示不修改' : 'QQ/163 邮箱请填「授权码」，不是登录密码' ?>">
          <span class="hint">出于安全考虑不回显；要更换时直接填新的。</span>
        </div>
        <div class="form-row">
          <label class="f">发件人邮箱</label>
          <input type="text" name="from" value="<?= hnim_admin_e($c['from']) ?>" placeholder="留空则用上面的发信邮箱账号">
        </div>
        <div class="form-row">
          <label class="f">发件人名称</label>
          <input type="text" name="from_name" value="<?= hnim_admin_e($c['from_name']) ?>" placeholder="<?= hnim_admin_e(hnim_app_name()) ?>">
        </div>
      </div>

      <div class="btn-row">
        <button class="btn primary" type="submit">保存设置</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-hd"><h2>发送测试邮件</h2></div>
  <div class="card-bd">
    <form method="post" class="btn-row" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $csrf ?>">
      <input type="hidden" name="do" value="test">
      <input type="text" name="test_to" style="max-width:300px"
             value="<?= hnim_admin_e($c['from'] !== '' ? $c['from'] : $c['user']) ?>"
             placeholder="接收测试邮件的邮箱">
      <button class="btn" type="submit">发送测试邮件</button>
    </form>
    <p class="hint" style="margin-top:10px">
      小提示：QQ / 163 邮箱要先去邮箱网页版「设置 → 账户」里开启 SMTP 服务，拿到一串授权码，填到上面的密码框里。
      如果一直失败，先确认服务器地址、端口、加密方式三者是否配套。
    </p>
  </div>
</div>
