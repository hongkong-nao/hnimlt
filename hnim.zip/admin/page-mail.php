<?php
/** HNIM 后台 · 邮件设置（SMTP） */
declare(strict_types=1);

$msg = '';
$msgType = 'ok';
$diag   = null;   // 分阶段自检的结果，null 表示还没点过

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = hnim_str(hnim_input('do', ''), '', 20);
    if (!hnim_csrf_check(hnim_input('csrf'))) {
        $msg = '页面已过期，请刷新后重试。';
        $msgType = 'err';
    } elseif ($do === 'save') {
        $secure = (string) hnim_input('secure', 'ssl');
        if (!in_array($secure, ['none', 'ssl', 'tls'], true)) {
            $secure = 'ssl';
        }
        hnim_smtp_save([
            'enabled'   => (string) hnim_input('enabled', '') === '1',
            'host'      => (string) hnim_input('host', ''),
            'port'      => (int) hnim_input('port', 465),
            'secure'    => $secure,
            // 复选框不勾 = 校验证书（默认）。勾上才允许自签证书。
            'verify'    => hnim_input('insecure') !== '1',
            'user'      => (string) hnim_input('user', ''),
            'pass'      => (string) hnim_input('pass', ''),
            'from'      => (string) hnim_input('from', ''),
            'from_name' => (string) hnim_input('from_name', ''),
            // 明文逃生舱，默认关。勾上后即使加密方式是「不加密」也会照发授权码。
            'allow_insecure' => hnim_input('plain_ok') === '1',
        ]);
        hnim_admin_log('保存邮件设置', (string) hnim_input('host', ''));
        $msg = '邮件设置已保存。建议点下面的「发送测试邮件」验证一下。';
    } elseif ($do === 'test') {
        $to = hnim_str(hnim_input('test_to', ''), '', 128);
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            $msg = '请填写一个用来接收测试邮件的邮箱。';
            $msgType = 'err';
        } else {
            $r = hnim_smtp_test($to);
            if ($r['ok']) {
                $msg = '测试邮件已发出，请到 ' . $to . ' 的收件箱（和垃圾箱）里查收。';
            } else {
                $msg = '发送失败：' . (string) ($r['error'] ?? '未知错误');
                $msgType = 'err';
            }
            hnim_admin_log('邮件测试', $to . ' ' . ($r['ok'] ? '成功' : '失败'));
        }
    } elseif ($do === 'diag') {
        // 分阶段自检：不发邮件，只把每一环的结果摊开
        $diag = hnim_smtp_diag();
        hnim_admin_log('SMTP 自检', (string) ($diag['ok'] ? '全部通过' : $diag['stage']));
    }
}

$c    = hnim_smtp_conf();
$why  = hnim_smtp_ready();
$passSet = $c['pass'] !== '';
?>

<?php if ($msg !== ''): ?>
  <div class="alert <?= $msgType ?>"><?= hnim_admin_e($msg) ?></div>
<?php endif; ?>

<?php if ($why === null): ?>
  <div class="alert ok"><b>邮件服务已就绪</b>：用户注册时会收到邮箱验证码。</div>
<?php else: ?>
  <div class="alert err"><b>邮件服务还没就绪</b>（<?= hnim_admin_e($why) ?>）：现在注册入口是关闭的，填好下面这些并保存即可开放。</div>
<?php endif; ?>

<div class="card">
  <div class="card-hd">
    <h2>SMTP 发信设置</h2>
    <span class="sub">注册验证码、测试邮件都通过这里发出</span>
  </div>
  <div class="card-bd">
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $csrf ?>">
      <input type="hidden" name="do" value="save">

      <div class="form-row">
        <label class="check">
          <input type="checkbox" name="enabled" value="1" <?= $c['enabled'] ? 'checked' : '' ?>>
          <span>启用邮件服务（关闭后注册入口也会一起关闭）</span>
        </label>
      </div>

      <div class="form-grid">
        <div class="form-row">
          <label class="f"><i>*</i>SMTP 服务器地址</label>
          <input type="text" name="host" value="<?= hnim_admin_e($c['host']) ?>" placeholder="smtp.qq.com">
          <span class="hint">QQ 邮箱 smtp.qq.com；163 邮箱 smtp.163.com；阿里云 smtp.mxhichina.com</span>
        </div>
        <div class="form-row">
          <label class="f">端口</label>
          <input type="number" name="port" id="smtpPort" value="<?= (int) $c['port'] ?>" placeholder="465">
          <span class="hint">切换加密方式时，这个端口会自动跟着变</span>
        </div>
        <div class="form-row">
          <label class="f">加密方式</label>
          <select name="secure" id="smtpSecure">
            <option value="ssl"  <?= $c['secure'] === 'ssl'  ? 'selected' : '' ?>>SSL — 一上来就加密，一般配 465</option>
            <option value="tls"  <?= $c['secure'] === 'tls'  ? 'selected' : '' ?>>STARTTLS — 先明文握手再升级，一般配 587</option>
            <option value="none" <?= $c['secure'] === 'none' ? 'selected' : '' ?>>不加密 — 仅内网邮件服务器（25）</option>
          </select>
          <span class="hint">QQ / 163 邮箱用 SSL 465 或 STARTTLS 587 都行</span>
        </div>
        <div class="form-row">
          <label class="f">证书校验</label>
          <label class="check">
            <input type="checkbox" name="insecure" value="1"
                   <?= $c['verify'] ? '' : 'checked' ?>>
            允许自签证书（不校验服务器证书）
          </label>
          <span class="hint">
            默认<b>校验</b>证书，保持勾选状态才是安全的。关掉之后虽然流量是加密的，
            但中间人仍能冒充服务器拿走授权码。仅当你的邮件服务器用自签证书、
            并且日志提示证书校验失败时才勾。
          </span>
        </div>
        <div class="form-row">
          <label class="f">明文登录</label>
          <label class="check">
            <input type="checkbox" name="plain_ok" value="1"
                   <?= $c['allow_insecure'] ? 'checked' : '' ?>>
            允许在完全没有加密的连接上发送授权码
          </label>
          <span class="hint">
            <b>默认禁止。</b>只有当「加密方式」选「不加密」时才会拒绝发送——
            授权码只是 base64 编码，明文发出去等于把密钥贴在网络上。
            上面的「允许自签证书」只影响验证书这一步，本项影响的是「要不要加密」，
            两者不同：前者在加密但不验身份，后者在彻底不加密。
            仅内网自建邮件服务器才需要勾。
          </span>
        </div>
        <div class="form-row">
          <label class="f"><i>*</i>发信邮箱账号</label>
          <input type="text" name="user" value="<?= hnim_admin_e($c['user']) ?>" placeholder="noreply@example.com">
        </div>
        <div class="form-row">
          <label class="f"><i>*</i>邮箱授权码 / 密码</label>
          <input type="password" name="pass" value=""
                 placeholder="<?= $passSet ? '已保存，留空表示不修改' : 'QQ/163 邮箱请填「授权码」，不是登录密码' ?>">
          <span class="hint">
  <?php if ($passSet) { ?>
    当前已保存：<b><?= strlen((string) $c['pass']) ?> 位</b>（不回显内容）。
    换新码要重新填并点保存，留空表示沿用旧的。
  <?php } else { ?>
    还没保存过。QQ / 163 邮箱请填网页版生成的「授权码」，不是登录密码。
  <?php } ?>
</span>
        </div>
        <div class="form-row">
          <label class="f">发件人邮箱</label>
          <input type="text" name="from" value="<?= hnim_admin_e($c['from']) ?>" placeholder="留空则用上面的发信邮箱账号">
        </div>
        <div class="form-row">
          <label class="f">发件人名称</label>
          <input type="text" name="from_name" value="<?= hnim_admin_e($c['from_name']) ?>" placeholder="<?= hnim_admin_e(hnim_app_name()) ?>">
        </div>
      </div>

      <div class="btn-row">
        <button class="btn primary" type="submit">保存设置</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-hd"><h2>SMTP 自检（不发邮件）</h2></div>
  <div class="card-bd">
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $csrf ?>">
      <input type="hidden" name="do" value="diag">
      <div class="btn-row">
        <button class="btn primary" type="submit">开始自检</button>
      </div>
    </form>

    <?php if (is_array($diag)) { ?>
      <div class="alert <?= $diag['ok'] ? 'ok' : 'err' ?>" style="margin-top:14px">
        <b><?= $diag['ok'] ? '全部通过' : '卡在：' . hnim_admin_e((string) $diag['stage']) ?></b>
        <div style="margin-top:6px"><?= nl2br(hnim_admin_e((string) $diag['msg'])) ?></div>
      </div>
      <?php if (!empty($diag['detail'])) { ?>
        <ul class="hint" style="margin:10px 0 0 18px;line-height:1.9">
          <?php foreach ((array) $diag['detail'] as $d) { ?>
            <li><?= hnim_admin_e((string) $d) ?></li>
          <?php } ?>
        </ul>
      <?php } ?>
    <?php } ?>

    <p class="hint" style="margin-top:12px">
      自检会依次连接并检查五个环节，<b>不会发出任何邮件</b>：
      ① TCP 连接 → ② 加密与证书 → ③ EHLO → ④ STARTTLS → ⑤ 账号密码认证。
      它只报结果和服务器的原话，不显示授权码内容（只报位数）。
    </p>
    <p class="hint" style="margin-top:6px">
      排障时用这个比「发送测试邮件」有用：发信失败只会得到一句笼统的错误，
      而自检能直接告诉你卡在哪一环。
    </p>
  </div>
</div>

<div class="card">
  <div class="card-hd"><h2>发送测试邮件</h2></div>
  <div class="card-bd">
    <form method="post" class="btn-row" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $csrf ?>">
      <input type="hidden" name="do" value="test">
      <input type="text" name="test_to" style="max-width:300px"
             value="<?= hnim_admin_e($c['from'] !== '' ? $c['from'] : $c['user']) ?>"
             placeholder="接收测试邮件的邮箱">
      <button class="btn" type="submit">发送测试邮件</button>
    </form>
    <p class="hint" style="margin-top:10px">
      <b>先点上面「保存设置」，再点这里发测试邮件</b> —— 这个按钮只提交收件人，
      它用的是数据库里<b>已经存好</b>的那份配置；没保存就等于拿旧配置去测。
    </p>
    <p class="hint" style="margin-top:6px">
      QQ 邮箱要先在网页版「设置 → 账户」开启 SMTP 服务并拿到授权码。
      若报 535：先确认填的是授权码而非登录密码；连续失败多次会被限频，等 10~30 分钟再试。
    </p>
  </div>
</div>

<script>
/* 加密方式和端口必须配套：SSL↔465、STARTTLS↔587。
   以前这两个框各填各的，很容易出现「选了 STARTTLS 但端口还留在 465」，
   结果连不上却看不出是哪错了。所以在页面上直接联动。 */
(function () {
  var sel = document.getElementById('smtpSecure');
  var port = document.getElementById('smtpPort');
  if (!sel || !port) return;

  var paired = { ssl: '465', tls: '587', none: '25' };

  function sync(fromUser) {
    var want = paired[sel.value];
    if (!want) return;
    // 只有当端口还是「上一步自动填的」或「压根没动过」时才替换，
    // 不然会把管理员特意改过的自定义端口冲掉。
    if (fromUser || !port.dataset.touched) {
      port.value = want;
      port.dataset.touched = '';
    }
  }

  sel.addEventListener('change', function () { sync(true); });
  port.addEventListener('input', function () { port.dataset.touched = '1'; });

  // 进页面先纠正一次：存的配置若是「选了 tls 却留着 465」，当场拉回配套值
  sync(false);
}());
</script>
