<?php
/**
 * HNIM 后台 · 数据清理
 * ------------------------------------------------------------------
 * 超管用来删除「太久以前」的聊天记录（默认半年，即 6 个月以前的全部删掉），
 * 主要是给长期运行的站点控制数据库体积用的。
 *
 * 三重保险，缺一不可：
 *   1. 走后台登录态 —— 只有能登进 admin.php 的超管够得着
 *   2. CSRF 校验 —— 防止别人拿你浏览器里存着的 cookie 偷偷发这个请求
 *   3. 勾选确认框 + 手打截止日期 —— 手滑点不进来
 * 删完一定写操作日志，谁在什么时候删了多少，一清二楚。
 *
 * 删除是「按批」进行的：一条 DELETE 扫全表会把 InnoDB 表锁住好几分钟，
 * 线上聊天全卡住。详见 core.php 的 hnim_purge_messages_before()。
 */
declare(strict_types=1);

$msg = '';
$msgType = 'ok';

/* 保留多久。默认半年。 */
$months = hnim_int(hnim_input('months', 6), 6);
if (!in_array($months, [1, 3, 6, 12, 24], true)) {
    $months = 6;
}
$cutoff = strtotime('-' . $months . ' months');
$cutoff = $cutoff === false ? time() - 180 * 86400 : $cutoff;
$cutoffText = date('Y-m-d H:i', $cutoff);

/* ---------------- 处理动作 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = hnim_str(hnim_input('do', ''), '', 20);

    if (!hnim_csrf_check(hnim_input('csrf'))) {
        $msg = '页面已过期，请刷新后重试。';
        $msgType = 'err';
    } elseif ($do !== 'purge') {
        $msg = '未知操作。';
        $msgType = 'err';
    } elseif (hnim_input('confirm') !== 'yes') {
        $msg = '请先勾选下面的确认框。';
        $msgType = 'err';
    } elseif (hnim_str(hnim_input('confirm_text', ''), '', 32) !== date('Y-m-d', $cutoff)) {
        $msg = '确认文字不对。请原样输入 ' . date('Y-m-d', $cutoff) . ' 再提交。';
        $msgType = 'err';
    } else {
        try {
            $before = hnim_count_messages_before($cutoff);
            $r = hnim_purge_messages_before($cutoff);

            $detail = '删除 ' . date('Y-m-d H:i', $cutoff) . ' 之前的聊天记录：'
                . $r['messages'] . ' 条消息、' . $r['favorites'] . ' 条收藏（涉及会话约 ' . $before['conversations'] . ' 个）';
            hnim_admin_log('清理聊天记录', $detail);

            $msg = '已删除 ' . number_format($r['messages']) . ' 条消息、'
                 . number_format($r['favorites']) . ' 条收藏（分 ' . $r['batches'] . ' 批完成）。';
            if ($r['more']) {
                $msg .= ' 数据量太大没删完，请再点一次「开始清理」继续。';
            }
        } catch (Throwable $e) {
            error_log('[hnim] purge failed: ' . $e->getMessage());
            $msg = '清理失败：' . $e->getMessage();
            $msgType = 'err';
        }
    }
}

/* ---------------- 统计预览 ---------------- */
$stat = ['messages' => 0, 'conversations' => 0, 'from' => 0, 'to' => 0];
$statErr = '';
try {
    $stat = hnim_count_messages_before($cutoff);
} catch (Throwable $e) {
    $statErr = $e->getMessage();
}
?>

<?php if ($msg !== ''): ?>
  <div class="alert <?= hnim_admin_e($msgType) ?>"><?= hnim_admin_e($msg) ?></div>
<?php endif; ?>

<?php if ($statErr !== ''): ?>
  <div class="alert err">读不到聊天库，没法统计：<?= hnim_admin_e($statErr) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-hd">
    <h2>清理过期聊天记录</h2>
    <span class="sub">只删聊天内容，不删账号、不删好友</span>
  </div>

  <div class="card-bd">
    <div class="alert info" style="margin-bottom:18px">
      这里删的是 <b>聊天库里 messages 表的记录</b>：文字、图片、文件消息，以及指向它们的收藏。
      半年以前的记录删掉后 <b>无法恢复</b>，会话列表和好友关系都还在，只是翻不到旧消息了。
      对话双方、各群成员都会同时受影响 —— 谁也看不到自己以前的记录。
    </div>

    <div class="tbl" style="border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;margin-bottom:18px">
      <table class="tbl">
        <tbody>
          <tr><td style="width:190px;color:var(--muted)">保留时长</td>
              <td>
                <form method="get" action="<?= hnim_admin_e(hnim_url('admin.php')) ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
                  <input type="hidden" name="p" value="data">
                  <select name="months" onchange="this.form.submit()" style="width:auto">
                    <?php foreach ([1, 3, 6, 12, 24] as $mo): ?>
                      <option value="<?= $mo ?>" <?= $mo === $months ? 'selected' : '' ?>>
                        <?= $mo === 6 ? '半年（6 个月）' : $mo . ' 个月' ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                  <span class="hint">切换后自动刷新统计</span>
                </form>
              </td></tr>

          <tr><td style="color:var(--muted)">截止时间</td>
              <td class="mono"><?= hnim_admin_e($cutoffText) ?> 之前</td></tr>

          <tr><td style="color:var(--muted)">涉及消息</td>
              <td><b style="font-size:16px"><?= number_format($stat['messages']) ?></b> 条
                  <?php if ($stat['from'] > 0): ?>
                    <span class="hint">（<?= hnim_admin_e(hnim_admin_time($stat['from'])) ?> 至 <?= hnim_admin_e(hnim_admin_time($stat['to'])) ?>）</span>
                  <?php endif; ?>
              </td></tr>

          <tr><td style="color:var(--muted)">涉及会话</td>
              <td>约 <?= number_format($stat['conversations']) ?> 个（私聊 + 群聊）</td></tr>
        </tbody>
      </table>
    </div>

    <?php if ($statErr !== ''): ?>
      <div class="hint">聊天库连不上，下面这个按钮先别用。</div>
    <?php elseif ($stat['messages'] <= 0): ?>
      <div class="alert ok" style="margin:0">
        很好，<?= $months ?> 个月以内没有需要清理的记录 —— 说明这个站点还很新，或者上次刚清过。
      </div>
    <?php else: ?>
      <form method="post" onsubmit="return confirm('确定要删除 <?= number_format($stat['messages']) ?> 条历史消息吗？\n\n删除后无法恢复，聊天双方都看不到这些旧记录了。');">
        <input type="hidden" name="do" value="purge">
        <input type="hidden" name="csrf" value="<?= hnim_csrf() ?>">
        <input type="hidden" name="months" value="<?= $months ?>">

        <div class="form-row">
          <label class="check">
            <input type="checkbox" name="confirm" value="yes">
            <span>我知道这些记录删掉后 <b>无法恢复</b>，确定要清理</span>
          </label>
        </div>

        <div class="form-row">
          <label class="hint" for="confirm_text" style="margin-bottom:2px">
            请原样输入 <b class="mono"><?= hnim_admin_e(date('Y-m-d', $cutoff)) ?></b> 以确认（防止手滑点错）
          </label>
          <input type="text" name="confirm_text" id="confirm_text" placeholder="<?= hnim_admin_e(date('Y-m-d', $cutoff)) ?>"
                 autocomplete="off" style="max-width:260px">
        </div>

        <div class="btn-row">
          <button class="btn danger" type="submit">开始清理</button>
          <span class="hint">数据量大时分几批删，可能需要几秒到几十秒，别重复点。</span>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="card-hd"><h2>说明</h2></div>
  <div class="card-bd">
    <div class="hint" style="line-height:2">
      · <b>不会</b>删除：用户账号、好友关系、群成员、群资料、后台设置<br>
      · <b>会</b>删除：文字 / 图片 / 文件消息、引用关系、@提醒、以及指向这些消息的收藏<br>
      · 删完后会话列表照常显示，只是往前翻没有旧消息了<br>
      · 每次清理都会写进「操作日志」，可以查到是谁在什么时候删了多少条
    </div>
  </div>
</div>
