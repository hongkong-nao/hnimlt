<?php
/**
 * HNIM 后台版面：左侧导航 + 顶栏
 */
declare(strict_types=1);

if (!function_exists('hnim_admin_doc')) {
    /**
     * 输出后台的 <head>。
     *
     * 登录页和内页必须走同一个函数 —— 两边各写一份的话，
     * 改主题变量时很容易只改一处，登录页就变成白的了。
     *
     * @param string $title 页面标题（不含「· HNIM 管理后台」后缀）
     */
    function hnim_admin_doc(string $title): void
    {
        $full = $title === '' ? 'HNIM 管理后台' : $title . ' · HNIM 管理后台';
        ?>
<!DOCTYPE html>
<html lang="zh-CN" data-theme="sky">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($full, ENT_QUOTES) ?></title>
<?php /* 两套主题一起加载，切换时只换 <html> 上的 class/data-theme，不会有闪白 */ ?>
<link rel="stylesheet" href="<?= hnim_asset('css/theme-sky.css') ?>">
<link rel="stylesheet" href="<?= hnim_asset('css/theme-sakura.css') ?>">
<link rel="stylesheet" href="<?= hnim_asset_rel('admin/style.css') ?>">
<script>
/* 防闪白：必须在第一帧之前把配色定下来，所以内联在 <head> 里。
   跟前台用同一套 localStorage 键，两边颜色始终一致。 */
(function(){
  try{
    var d=document.documentElement;
    var t=localStorage.getItem('hnim.theme')||'sky';
    if(t!=='sky'&&t!=='sakura'){t='sky';}
    d.setAttribute('data-theme',t);
    var s=localStorage.getItem('hnim.scheme')||'auto';
    if(s!=='light'&&s!=='dark'){s='auto';}
    var dark=(s==='dark')||(s==='auto'&&window.matchMedia&&window.matchMedia('(prefers-color-scheme:dark)').matches);
    d.classList.toggle('dark',dark);
  }catch(e){}
})();
</script>
</head>
        <?php
    }

    /**
     * 输出内页的 <body>：左侧导航 + 顶栏。
     * @param string $title 页面标题
     */
    function hnim_admin_head(string $title): void
    {
        global $adminUser, $p;
        $nav = [
            'dashboard' => ['概览', '🏠'],
            'users'     => ['用户管理', '👥'],
            'data'      => ['数据清理', '🧹'],
            'mail'      => ['邮件设置', '✉'],
            'logs'      => ['操作日志', '📋'],
        ];
        hnim_admin_doc($title);
        ?>
<body class="admin-body">
<div class="admin-shell">

  <aside class="admin-side">
    <div class="brand"><span class="brand-logo">H</span><b>HNIM 后台</b></div>
    <nav>
      <?php foreach ($nav as $key => $item): ?>
        <a class="nav-item <?= $key === $p ? 'on' : '' ?>" href="<?= hnim_url('admin.php?p=' . $key) ?>">
          <span class="ico"><?= $item[1] ?></span><?= htmlspecialchars($item[0], ENT_QUOTES) ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="side-foot">
      <a href="<?= hnim_url('index.php') ?>" target="_blank">打开聊天 ↗</a>
      <a href="<?= hnim_url('admin.php?p=logout') ?>" onclick="return confirm('确定退出后台？')">退出登录</a>
    </div>
  </aside>

  <main class="admin-main">
    <header class="admin-top">
      <h1><?= htmlspecialchars($title, ENT_QUOTES) ?></h1>
      <div class="admin-who">当前后台账号：<b><?= htmlspecialchars((string) $adminUser, ENT_QUOTES) ?></b></div>
    </header>
    <div class="admin-content">
        <?php
    }

    /** 输出后台页脚 */
    function hnim_admin_foot(): void
    {
        ?>
    </div>
    <footer class="admin-foot"><?= htmlspecialchars(hnim_app_name(), ENT_QUOTES) ?> · HNIM v<?= HNIM_VERSION ?> · 管理后台</footer>
    <?= hnim_credit_html() ?>
  </main>
</div>
</body>
</html>
        <?php
    }

    /** 小工具：把时间戳显示成人能看懂的样子 */
    function hnim_admin_time($ts): string
    {
        $ts = (int) $ts;
        return $ts > 0 ? date('Y-m-d H:i', $ts) : '—';
    }

    /** 小工具：安全取值 */
    function hnim_admin_e($v): string
    {
        return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
    }
}
