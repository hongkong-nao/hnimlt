<?php
/**
 * HNIM 后台版面：左侧导航 + 顶栏
 */
declare(strict_types=1);

if (!function_exists('hnim_admin_head')) {
    /**
     * 输出后台页头。
     * @param string $title 页面标题
     */
    function hnim_admin_head(string $title): void
    {
        global $adminUser, $p;
        $nav = [
            'dashboard' => ['概览', '🏠'],
            'users'     => ['用户管理', '👥'],
            'data'      => ['数据清理', '🧹'],
            'mail'      => ['邮件设置', '✉'],
            'logs'      => ['操作日志', '📋'],
        ];
        $site = hnim_app_name();
        $csrf = hnim_csrf();
        ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title, ENT_QUOTES) ?> · HNIM 管理后台</title>
<link rel="stylesheet" href="<?= hnim_url('admin/style.css') ?>">
</head>
<body class="admin-body">
<div class="admin-shell">

  <aside class="admin-side">
    <div class="brand"><span class="brand-logo">H</span><b>HNIM 后台</b></div>
    <nav>
      <?php foreach ($nav as $key => $item): ?>
        <a class="nav-item <?= $key === $p ? 'on' : '' ?>" href="<?= hnim_url('admin.php?p=' . $key) ?>">
          <span class="ico"><?= $item[1] ?></span><?= htmlspecialchars($item[0], ENT_QUOTES) ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="side-foot">
      <a href="<?= hnim_url('index.php') ?>" target="_blank">打开聊天 ↗</a>
      <a href="<?= hnim_url('admin.php?p=logout') ?>" onclick="return confirm('确定退出后台？')">退出登录</a>
    </div>
  </aside>

  <main class="admin-main">
    <header class="admin-top">
      <h1><?= htmlspecialchars($title, ENT_QUOTES) ?></h1>
      <div class="admin-who">当前后台账号：<b><?= htmlspecialchars((string) $adminUser, ENT_QUOTES) ?></b></div>
    </header>
    <div class="admin-content">
        <?php
    }

    /** 输出后台页脚 */
    function hnim_admin_foot(): void
    {
        ?>
    </div>
    <footer class="admin-foot"><?= htmlspecialchars(hnim_app_name(), ENT_QUOTES) ?> · HNIM v<?= HNIM_VERSION ?> · 管理后台</footer>
    <?= hnim_credit_html() ?>
  </main>
</div>
</body>
</html>
        <?php
    }

    /** 小工具：把时间戳显示成人能看懂的样子 */
    function hnim_admin_time($ts): string
    {
        $ts = (int) $ts;
        return $ts > 0 ? date('Y-m-d H:i', $ts) : '—';
    }

    /** 小工具：安全取值 */
    function hnim_admin_e($v): string
    {
        return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
    }
}
