<?php
/** HNIM 后台 · 操作日志（后台操作 + 用户登录记录） */
declare(strict_types=1);

$acc = hnim_db();

$tab   = hnim_input('tab') === 'login' ? 'login' : 'admin';
$page  = max(1, hnim_int(hnim_input('page', 1), 1));
$per   = 30;
$off   = ($page - 1) * $per;
$total = 0;
$rows  = [];

try {
    if ($tab === 'login') {
        $total = (int) $acc->query('SELECT COUNT(*) FROM login_log')->fetchColumn();
        $st = $acc->prepare(
            'SELECT l.*, u.username, u.nickname
             FROM login_log l
             LEFT JOIN users u ON u.id = l.user_id
             ORDER BY l.id DESC LIMIT ' . $per . ' OFFSET ' . $off
        );
        $st->execute();
        $rows = $st->fetchAll();
    } else {
        $total = (int) $acc->query('SELECT COUNT(*) FROM admin_log')->fetchColumn();
        $st = $acc->prepare('SELECT * FROM admin_log ORDER BY id DESC LIMIT ' . $per . ' OFFSET ' . $off);
        $st->execute();
        $rows = $st->fetchAll();
    }
} catch (Throwable $e) {
    $rows = [];
}

$pages = max(1, (int) ceil($total / $per));
$base  = hnim_url('admin.php?p=logs&tab=' . $tab);
?>

<div class="card">
  <div class="card-hd">
    <h2><?= $tab === 'login' ? '用户登录记录' : '后台操作记录' ?></h2>
    <span class="sub">共 <?= $total ?> 条，最新的在最上面</span>
  </div>

  <div class="filter">
    <a class="btn sm <?= $tab === 'admin' ? 'primary' : '' ?>" href="<?= hnim_url('admin.php?p=logs&tab=admin') ?>">后台操作</a>
    <a class="btn sm <?= $tab === 'login' ? 'primary' : '' ?>" href="<?= hnim_url('admin.php?p=logs&tab=login') ?>">用户登录</a>
    <span class="hint">登录记录只保留最近 500 条，超出会自动清理</span>
  </div>

  <div class="card-bd" style="padding:0">
    <?php if ($tab === 'login'): ?>
      <table class="tbl">
        <thead><tr><th>时间</th><th>账号</th><th>昵称</th><th>结果</th><th>IP</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?>
          <tr><td colspan="5" class="empty">还没有登录记录</td></tr>
        <?php else: foreach ($rows as $r): ?>
          <tr>
            <td class="muted"><?= hnim_admin_time($r['created_at']) ?></td>
            <td><?= $r['username'] !== null ? hnim_admin_e($r['username']) : '<span class="muted">已删除用户</span>' ?></td>
            <td><?= hnim_admin_e($r['nickname'] ?? '') ?></td>
            <td><?= (int) $r['ok'] === 1 ? '<span class="badge green">成功</span>' : '<span class="badge red">失败</span>' ?></td>
            <td class="mono muted"><?= hnim_admin_e($r['ip']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    <?php else: ?>
      <table class="tbl">
        <thead><tr><th>时间</th><th>操作人</th><th>动作</th><th>详情</th><th>IP</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?>
          <tr><td colspan="5" class="empty">还没有后台操作记录</td></tr>
        <?php else: foreach ($rows as $r): ?>
          <tr>
            <td class="muted"><?= hnim_admin_time($r['created_at']) ?></td>
            <td><b><?= hnim_admin_e($r['admin']) ?></b></td>
            <td><span class="badge blue"><?= hnim_admin_e($r['action']) ?></span></td>
            <td><?= hnim_admin_e($r['detail']) ?></td>
            <td class="mono muted"><?= hnim_admin_e($r['ip']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <?php if ($pages > 1): ?>
  <div class="pager">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <?php if ($i === $page): ?>
        <span class="on"><?= $i ?></span>
      <?php else: ?>
        <a href="<?= $base . '&page=' . $i ?>"><?= $i ?></a>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
